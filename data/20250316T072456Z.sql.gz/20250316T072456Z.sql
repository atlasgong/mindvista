--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12
-- Dumped by pg_dump version 16.8 (Ubuntu 16.8-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum__legal_v_version_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.enum__legal_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__legal_v_version_status OWNER TO neondb_owner;

--
-- Name: enum__sponsor_v_version_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.enum__sponsor_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__sponsor_v_version_status OWNER TO neondb_owner;

--
-- Name: enum_legal_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.enum_legal_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_legal_status OWNER TO neondb_owner;

--
-- Name: enum_sponsor_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.enum_sponsor_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_sponsor_status OWNER TO neondb_owner;

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.enum_users_role AS ENUM (
    'admin',
    'contentEditor',
    'contentEditorFr'
);


ALTER TYPE public.enum_users_role OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _holistic_wellness_v; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._holistic_wellness_v (
    id integer NOT NULL,
    version_page_id integer NOT NULL,
    version_hero_content jsonb NOT NULL,
    version_hero_content_fr jsonb,
    version_wellness_wheel_top_content jsonb NOT NULL,
    version_wellness_wheel_top_content_fr jsonb,
    version_wellness_wheel_bottom_content jsonb NOT NULL,
    version_wellness_wheel_bottom_content_fr jsonb,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public._holistic_wellness_v OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._holistic_wellness_page_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._holistic_wellness_page_v_id_seq OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._holistic_wellness_page_v_id_seq OWNED BY public._holistic_wellness_v.id;


--
-- Name: _holistic_wellness_v_version_sections; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._holistic_wellness_v_version_sections (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    content jsonb NOT NULL,
    content_fr jsonb,
    _uuid character varying
);


ALTER TABLE public._holistic_wellness_v_version_sections OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_version_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._holistic_wellness_page_v_version_sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._holistic_wellness_page_v_version_sections_id_seq OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_version_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._holistic_wellness_page_v_version_sections_id_seq OWNED BY public._holistic_wellness_v_version_sections.id;


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._holistic_wellness_v_version_wellness_wheel_dimensions (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    name character varying NOT NULL,
    name_fr character varying,
    description character varying NOT NULL,
    description_fr character varying,
    color character varying NOT NULL,
    _uuid character varying
);


ALTER TABLE public._holistic_wellness_v_version_wellness_wheel_dimensions OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq OWNER TO neondb_owner;

--
-- Name: _holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq OWNED BY public._holistic_wellness_v_version_wellness_wheel_dimensions.id;


--
-- Name: _legal_v; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._legal_v (
    id integer NOT NULL,
    parent_id integer,
    version_page_id integer,
    version_content jsonb,
    version_content_fr jsonb,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__legal_v_version_status DEFAULT 'draft'::public.enum__legal_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean
);


ALTER TABLE public._legal_v OWNER TO neondb_owner;

--
-- Name: _legal_v_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._legal_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._legal_v_id_seq OWNER TO neondb_owner;

--
-- Name: _legal_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._legal_v_id_seq OWNED BY public._legal_v.id;


--
-- Name: _sponsor_v; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._sponsor_v (
    id integer NOT NULL,
    version_page_id integer,
    version_our_sponsors_section character varying,
    version_our_sponsors_section_fr character varying,
    version_callout character varying,
    version_callout_fr character varying,
    version_sponsor_us_section character varying,
    version_sponsor_us_section_fr character varying,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    version__status public.enum__sponsor_v_version_status DEFAULT 'draft'::public.enum__sponsor_v_version_status,
    latest boolean
);


ALTER TABLE public._sponsor_v OWNER TO neondb_owner;

--
-- Name: _sponsor_v_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._sponsor_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._sponsor_v_id_seq OWNER TO neondb_owner;

--
-- Name: _sponsor_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._sponsor_v_id_seq OWNED BY public._sponsor_v.id;


--
-- Name: _sponsor_v_version_sponsors; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._sponsor_v_version_sponsors (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    url character varying,
    logo_id integer,
    _uuid character varying
);


ALTER TABLE public._sponsor_v_version_sponsors OWNER TO neondb_owner;

--
-- Name: _sponsor_v_version_sponsors_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public._sponsor_v_version_sponsors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._sponsor_v_version_sponsors_id_seq OWNER TO neondb_owner;

--
-- Name: _sponsor_v_version_sponsors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public._sponsor_v_version_sponsors_id_seq OWNED BY public._sponsor_v_version_sponsors.id;


--
-- Name: club_tag_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.club_tag_categories (
    id integer NOT NULL,
    name character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.club_tag_categories OWNER TO neondb_owner;

--
-- Name: club_tag_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.club_tag_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.club_tag_categories_id_seq OWNER TO neondb_owner;

--
-- Name: club_tag_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.club_tag_categories_id_seq OWNED BY public.club_tag_categories.id;


--
-- Name: club_tags; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.club_tags (
    id integer NOT NULL,
    name character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.club_tags OWNER TO neondb_owner;

--
-- Name: club_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.club_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.club_tags_id_seq OWNER TO neondb_owner;

--
-- Name: club_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.club_tags_id_seq OWNED BY public.club_tags.id;


--
-- Name: clubs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clubs (
    id integer NOT NULL,
    slug character varying NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    website character varying,
    email character varying,
    phone_number character varying,
    facebook character varying,
    instagram character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    currently_active boolean,
    newsletter character varying,
    title_fr character varying,
    description_fr character varying,
    graphic_id integer,
    graphic_title character varying,
    graphic_title_fr character varying
);


ALTER TABLE public.clubs OWNER TO neondb_owner;

--
-- Name: clubs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.clubs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clubs_id_seq OWNER TO neondb_owner;

--
-- Name: clubs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.clubs_id_seq OWNED BY public.clubs.id;


--
-- Name: clubs_other_socials; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clubs_other_socials (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    link character varying NOT NULL
);


ALTER TABLE public.clubs_other_socials OWNER TO neondb_owner;

--
-- Name: clubs_rels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clubs_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    club_tags_id integer
);


ALTER TABLE public.clubs_rels OWNER TO neondb_owner;

--
-- Name: clubs_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.clubs_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clubs_rels_id_seq OWNER TO neondb_owner;

--
-- Name: clubs_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.clubs_rels_id_seq OWNED BY public.clubs_rels.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.events (
    id integer NOT NULL,
    slug character varying NOT NULL,
    description character varying NOT NULL,
    location character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    location_link character varying,
    incentive character varying,
    is_chance boolean,
    limited_availability boolean,
    sign_up_link character varying,
    instagram_post character varying,
    graphic_id integer,
    title character varying NOT NULL,
    title_fr character varying,
    description_fr character varying,
    incentive_fr character varying,
    location_fr character varying
);


ALTER TABLE public.events OWNER TO neondb_owner;

--
-- Name: events_date_ranges; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.events_date_ranges (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    start_date timestamp(3) with time zone NOT NULL,
    end_date timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.events_date_ranges OWNER TO neondb_owner;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq OWNER TO neondb_owner;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: holistic_wellness; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.holistic_wellness (
    id integer NOT NULL,
    page_id integer NOT NULL,
    hero_content jsonb NOT NULL,
    hero_content_fr jsonb,
    wellness_wheel_top_content jsonb NOT NULL,
    wellness_wheel_top_content_fr jsonb,
    wellness_wheel_bottom_content jsonb NOT NULL,
    wellness_wheel_bottom_content_fr jsonb,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone
);


ALTER TABLE public.holistic_wellness OWNER TO neondb_owner;

--
-- Name: holistic_wellness_page_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.holistic_wellness_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.holistic_wellness_page_id_seq OWNER TO neondb_owner;

--
-- Name: holistic_wellness_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.holistic_wellness_page_id_seq OWNED BY public.holistic_wellness.id;


--
-- Name: holistic_wellness_sections; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.holistic_wellness_sections (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    content jsonb NOT NULL,
    content_fr jsonb
);


ALTER TABLE public.holistic_wellness_sections OWNER TO neondb_owner;

--
-- Name: holistic_wellness_wellness_wheel_dimensions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.holistic_wellness_wellness_wheel_dimensions (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    name_fr character varying,
    description character varying NOT NULL,
    description_fr character varying,
    color character varying NOT NULL
);


ALTER TABLE public.holistic_wellness_wellness_wheel_dimensions OWNER TO neondb_owner;

--
-- Name: legal; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.legal (
    id integer NOT NULL,
    page_id integer,
    content jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    content_fr jsonb,
    _status public.enum_legal_status DEFAULT 'draft'::public.enum_legal_status
);


ALTER TABLE public.legal OWNER TO neondb_owner;

--
-- Name: legal_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.legal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_id_seq OWNER TO neondb_owner;

--
-- Name: legal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.legal_id_seq OWNED BY public.legal.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.media (
    id integer NOT NULL,
    alt character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    prefix character varying DEFAULT 'media'::character varying,
    purpose character varying NOT NULL,
    alt_fr character varying
);


ALTER TABLE public.media OWNER TO neondb_owner;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_id_seq OWNER TO neondb_owner;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    slug character varying NOT NULL,
    title character varying NOT NULL,
    seo_description character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    title_fr character varying,
    seo_description_fr character varying
);


ALTER TABLE public.pages OWNER TO neondb_owner;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pages_id_seq OWNER TO neondb_owner;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payload_locked_documents (
    id integer NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO neondb_owner;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payload_locked_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_id_seq OWNER TO neondb_owner;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payload_locked_documents_id_seq OWNED BY public.payload_locked_documents.id;


--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer,
    media_id integer,
    pages_id integer,
    legal_id integer,
    clubs_id integer,
    resources_id integer,
    club_tag_categories_id integer,
    resource_tag_categories_id integer,
    club_tags_id integer,
    resource_tags_id integer,
    events_id integer
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO neondb_owner;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO neondb_owner;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payload_migrations (
    id integer NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO neondb_owner;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payload_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_migrations_id_seq OWNER TO neondb_owner;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payload_migrations_id_seq OWNED BY public.payload_migrations.id;


--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payload_preferences (
    id integer NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO neondb_owner;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payload_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_id_seq OWNER TO neondb_owner;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payload_preferences_id_seq OWNED BY public.payload_preferences.id;


--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer
);


ALTER TABLE public.payload_preferences_rels OWNER TO neondb_owner;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO neondb_owner;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: resource_tag_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resource_tag_categories (
    id integer NOT NULL,
    name character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.resource_tag_categories OWNER TO neondb_owner;

--
-- Name: resource_tag_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.resource_tag_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resource_tag_categories_id_seq OWNER TO neondb_owner;

--
-- Name: resource_tag_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.resource_tag_categories_id_seq OWNED BY public.resource_tag_categories.id;


--
-- Name: resource_tags; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resource_tags (
    id integer NOT NULL,
    name character varying NOT NULL,
    category_id integer NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.resource_tags OWNER TO neondb_owner;

--
-- Name: resource_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.resource_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resource_tags_id_seq OWNER TO neondb_owner;

--
-- Name: resource_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.resource_tags_id_seq OWNED BY public.resource_tags.id;


--
-- Name: resources; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resources (
    id integer NOT NULL,
    slug character varying NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    website character varying,
    insurance_details character varying,
    email character varying,
    phone_number character varying,
    location character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    currently_active boolean,
    on_campus boolean,
    channel_online boolean,
    channel_telephone boolean,
    channel_in_person boolean,
    newsletter character varying,
    title_fr character varying,
    description_fr character varying,
    insurance_detail_fr character varying,
    location_fr character varying,
    graphic_id integer,
    graphic_title character varying,
    graphic_title_fr character varying
);


ALTER TABLE public.resources OWNER TO neondb_owner;

--
-- Name: resources_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resources_id_seq OWNER TO neondb_owner;

--
-- Name: resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.resources_id_seq OWNED BY public.resources.id;


--
-- Name: resources_insurance_providers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resources_insurance_providers (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL
);


ALTER TABLE public.resources_insurance_providers OWNER TO neondb_owner;

--
-- Name: resources_insurance_providers_insurance_provider; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resources_insurance_providers_insurance_provider (
    _order integer NOT NULL,
    _parent_id character varying NOT NULL,
    id character varying NOT NULL,
    name character varying NOT NULL,
    description character varying,
    name_fr character varying,
    description_fr character varying
);


ALTER TABLE public.resources_insurance_providers_insurance_provider OWNER TO neondb_owner;

--
-- Name: resources_rels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.resources_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    resource_tags_id integer
);


ALTER TABLE public.resources_rels OWNER TO neondb_owner;

--
-- Name: resources_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.resources_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resources_rels_id_seq OWNER TO neondb_owner;

--
-- Name: resources_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.resources_rels_id_seq OWNED BY public.resources_rels.id;


--
-- Name: sponsor; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sponsor (
    id integer NOT NULL,
    page_id integer,
    our_sponsors_section character varying,
    our_sponsors_section_fr character varying,
    callout character varying,
    callout_fr character varying,
    sponsor_us_section character varying,
    sponsor_us_section_fr character varying,
    updated_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone,
    _status public.enum_sponsor_status DEFAULT 'draft'::public.enum_sponsor_status
);


ALTER TABLE public.sponsor OWNER TO neondb_owner;

--
-- Name: sponsor_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sponsor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sponsor_id_seq OWNER TO neondb_owner;

--
-- Name: sponsor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sponsor_id_seq OWNED BY public.sponsor.id;


--
-- Name: sponsor_sponsors; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sponsor_sponsors (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    url character varying,
    logo_id integer
);


ALTER TABLE public.sponsor_sponsors OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone,
    full_name character varying NOT NULL,
    role public.enum_users_role DEFAULT 'contentEditor'::public.enum_users_role NOT NULL
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: _holistic_wellness_v id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v ALTER COLUMN id SET DEFAULT nextval('public._holistic_wellness_page_v_id_seq'::regclass);


--
-- Name: _holistic_wellness_v_version_sections id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_sections ALTER COLUMN id SET DEFAULT nextval('public._holistic_wellness_page_v_version_sections_id_seq'::regclass);


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_wellness_wheel_dimensions ALTER COLUMN id SET DEFAULT nextval('public._holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq'::regclass);


--
-- Name: _legal_v id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._legal_v ALTER COLUMN id SET DEFAULT nextval('public._legal_v_id_seq'::regclass);


--
-- Name: _sponsor_v id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v ALTER COLUMN id SET DEFAULT nextval('public._sponsor_v_id_seq'::regclass);


--
-- Name: _sponsor_v_version_sponsors id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v_version_sponsors ALTER COLUMN id SET DEFAULT nextval('public._sponsor_v_version_sponsors_id_seq'::regclass);


--
-- Name: club_tag_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.club_tag_categories ALTER COLUMN id SET DEFAULT nextval('public.club_tag_categories_id_seq'::regclass);


--
-- Name: club_tags id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.club_tags ALTER COLUMN id SET DEFAULT nextval('public.club_tags_id_seq'::regclass);


--
-- Name: clubs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs ALTER COLUMN id SET DEFAULT nextval('public.clubs_id_seq'::regclass);


--
-- Name: clubs_rels id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_rels ALTER COLUMN id SET DEFAULT nextval('public.clubs_rels_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: holistic_wellness id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness ALTER COLUMN id SET DEFAULT nextval('public.holistic_wellness_page_id_seq'::regclass);


--
-- Name: legal id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.legal ALTER COLUMN id SET DEFAULT nextval('public.legal_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: payload_locked_documents id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_migrations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_migrations ALTER COLUMN id SET DEFAULT nextval('public.payload_migrations_id_seq'::regclass);


--
-- Name: payload_preferences id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Name: resource_tag_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resource_tag_categories ALTER COLUMN id SET DEFAULT nextval('public.resource_tag_categories_id_seq'::regclass);


--
-- Name: resource_tags id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resource_tags ALTER COLUMN id SET DEFAULT nextval('public.resource_tags_id_seq'::regclass);


--
-- Name: resources id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources ALTER COLUMN id SET DEFAULT nextval('public.resources_id_seq'::regclass);


--
-- Name: resources_rels id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_rels ALTER COLUMN id SET DEFAULT nextval('public.resources_rels_id_seq'::regclass);


--
-- Name: sponsor id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor ALTER COLUMN id SET DEFAULT nextval('public.sponsor_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _holistic_wellness_v; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._holistic_wellness_v (id, version_page_id, version_hero_content, version_hero_content_fr, version_wellness_wheel_top_content, version_wellness_wheel_top_content_fr, version_wellness_wheel_bottom_content, version_wellness_wheel_bottom_content_fr, version_updated_at, version_created_at, created_at, updated_at) FROM stdin;
20	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-22 19:53:13.99+00	2025-02-21 20:12:07.332+00	2025-02-22 19:53:14.239+00	2025-02-22 19:53:14.24+00
21	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-22 19:53:18.76+00	2025-02-21 20:12:07.332+00	2025-02-22 19:53:18.977+00	2025-02-22 19:53:18.977+00
3	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconncted dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:13:02.827+00	2025-02-21 20:13:02.864+00
2	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:12:07.507+00	2025-02-21 20:12:07.508+00
5	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconncted dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:13:12.474+00	2025-02-21 20:13:12.474+00
4	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconncted dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:13:09.146+00	2025-02-21 20:13:09.147+00
7	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:36:34.001+00	2025-02-21 20:36:34.036+00
6	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:13:14.548+00	2025-02-21 20:13:14.549+00
9	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:16.435+00	2025-02-21 20:12:07.332+00	2025-02-21 20:37:16.622+00	2025-02-21 20:37:16.622+00
8	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:36:37.05+00	2025-02-21 20:12:07.332+00	2025-02-21 20:36:37.32+00	2025-02-21 20:36:37.321+00
11	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:37:54.395+00	2025-02-21 20:37:54.395+00
1	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	\N	\N	2025-02-21 19:25:17.076+00	2025-02-21 20:08:21.189+00
14	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellnes", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:20.276+00	2025-02-21 20:42:20.276+00
13	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellnes", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:15.963+00	2025-02-21 20:42:15.999+00
15	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellnes", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:21.571+00	2025-02-21 20:42:21.571+00
16	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellnes", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:22.716+00	2025-02-21 20:42:22.716+00
12	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellnes", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:15.701+00	2025-02-21 20:42:15.701+00
18	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contibute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:43:40.853+00	2025-02-21 20:43:40.853+00
17	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:42:29.923+00	2025-02-21 20:42:29.923+00
19	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:37:54.193+00	2025-02-21 20:12:07.332+00	2025-02-21 20:43:46.716+00	2025-02-21 20:43:46.716+00
10	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 20:12:07.361+00	2025-02-21 20:12:07.332+00	2025-02-21 20:37:41.911+00	2025-02-21 20:37:47.46+00
\.


--
-- Data for Name: _holistic_wellness_v_version_sections; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._holistic_wellness_v_version_sections (_order, _parent_id, id, content, content_fr, _uuid) FROM stdin;
2	8	87	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	9	88	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	9	89	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	10	92	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
1	1	72	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	1	73	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	3	76	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	3	77	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	4	78	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
1	2	74	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	2	75	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
2	10	93	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	11	94	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	4	79	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	5	80	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	5	81	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	6	82	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	6	83	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
2	11	95	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	12	96	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	12	97	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	7	84	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	7	85	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	8	86	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
1	13	98	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	13	99	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	15	102	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	15	103	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	14	100	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	14	101	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	16	104	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	16	105	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	17	106	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	17	107	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	18	108	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	18	109	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	19	110	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	19	111	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	20	112	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	20	113	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
1	21	114	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d36375f2c0657b93e0a7
2	21	115	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	67b8d3e075f2c0657b93e0a9
\.


--
-- Data for Name: _holistic_wellness_v_version_wellness_wheel_dimensions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._holistic_wellness_v_version_wellness_wheel_dimensions (_order, _parent_id, id, name, name_fr, description, description_fr, color, _uuid) FROM stdin;
1	1	163	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	1	164	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	1	165	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	1	166	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	1	167	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	1	168	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	1	169	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	1	170	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	2	171	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	2	172	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	2	173	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	2	174	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	2	175	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	2	176	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	2	177	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	2	178	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	3	179	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	3	180	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	3	181	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	3	182	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	3	183	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	3	184	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	3	185	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	3	186	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	4	187	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	4	188	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	4	189	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	4	190	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	4	191	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	4	192	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	4	193	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	4	194	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	5	195	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	5	196	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	5	197	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	5	198	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	5	199	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	5	200	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	5	201	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	5	202	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	6	203	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	6	204	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	6	205	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	6	206	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	6	207	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	6	208	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	6	209	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	6	210	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	7	211	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	7	212	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	7	213	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	7	214	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	7	215	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	7	216	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	7	217	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	7	218	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	8	219	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	8	220	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	8	221	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	8	222	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	8	223	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	8	224	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	8	225	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	8	226	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	9	227	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	9	228	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	9	229	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	9	230	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	9	231	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	9	232	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	9	233	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	9	234	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	10	243	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	10	244	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	10	245	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	10	246	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	10	247	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	10	248	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	10	249	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	10	250	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	11	251	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	11	252	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	11	253	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	11	254	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	11	255	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	11	256	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	11	257	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	11	258	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	12	259	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	12	260	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	12	261	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	12	262	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	12	263	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	12	264	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	12	265	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	12	266	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	13	267	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	13	268	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	13	269	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	13	270	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	13	271	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
1	14	275	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	14	276	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	14	277	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	14	278	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	14	279	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	14	280	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
6	13	272	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	13	273	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	13	274	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	15	283	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	15	284	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	15	285	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	15	286	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	15	287	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	15	288	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	15	289	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	15	290	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	16	291	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	16	292	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	16	293	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	16	294	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	16	295	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	16	296	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	16	297	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	16	298	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	17	299	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	17	300	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	17	301	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	17	302	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	17	303	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	17	304	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	17	305	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	17	306	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	18	307	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	18	308	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	18	309	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	18	310	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	18	311	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	18	312	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	18	313	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	18	314	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
7	14	281	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	14	282	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	19	315	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	19	316	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	19	317	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	19	318	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	19	319	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	19	320	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	19	321	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	19	322	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	20	323	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	20	324	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	20	325	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	20	326	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	20	327	Financial	\N	finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	20	328	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	20	329	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	20	330	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
1	21	331	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500	67b8d33475f2c0657b93e0a3
2	21	332	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500	67b8d35b75f2c0657b93e0a5
3	21	333	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500	67b8d56467ccd8052fc497ee
4	21	334	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500	67b8d57767ccd8052fc497f0
5	21	335	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500	67b8d58d67ccd8052fc497f2
6	21	336	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500	67b8d59d67ccd8052fc497f4
7	21	337	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600	67b8d5b233636dbefec7998a
8	21	338	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500	67b8d5ae67ccd8052fc497f8
\.


--
-- Data for Name: _legal_v; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._legal_v (id, parent_id, version_page_id, version_content, version_content_fr, version_updated_at, version_created_at, version__status, created_at, updated_at, latest) FROM stdin;
9	5	2	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-02-06", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista (\\"we,\\" \\"our,\\" or \\"us\\") values your privacy. This Privacy Policy outlines how we collect, use, and protect your information when you use our website (mindvista.ca). This Privacy Policy is intended to be easy to understand, and we avoid legal jargon whenever possible. However, to ensure transparency and protection, we provide links detailing how third-party services handle your information. Below, you'll find a complete list of the data we collect and how we use it.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies and Local Storage", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not use cookies on our website. We use local storage to remember your preferences, such as your choice of dark or light theme. This data is stored on your device only and is not transmitted to our servers. You can manage or clear this data at any time through your browser settings.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information We Collect", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We collect only the following information:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Contact Form Submissions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "When you fill out a contact form on our website, we use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Web3Forms", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to process your submission. The information you provide, such as your name, email address, and message, is used solely for responding to your inquiry. Contact form submissions may be retained indefinitely unless a deletion request is made. Web3Forms' privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://web3forms.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://web3forms.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use hCaptcha to prevent spam and ensure user actions on our online service (such as submitting a contact form) meet our security requirements. To do this, hCaptcha analyzes the behavior of the website or mobile app visitor based on various characteristics. This analysis starts automatically as soon as the website or mobile app visitor enters a part of the website or app with hCaptcha enabled. For the analysis, hCaptcha evaluates various information (e.g. IP address, how long the visitor has been on the website or app, or mouse movements made by the user). The data collected during the analysis will be forwarded to IMI. hCaptcha analysis in the \\"invisible mode\\" may take place completely in the background. Website or app visitors are not advised that such an analysis is taking place if the user is not shown a challenge. For more information on this process, hCaptcha's privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://www.hcaptcha.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://www.hcaptcha.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Newsletter Subscriptions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you subscribe to our newsletter, we collect your email address via ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Mailchimp", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to send you updates and news. While you can unsubscribe at any time by clicking the unsubscribe link in any email, we may retain your email address and subscription data in an archive for record-keeping purposes. Mailchimp's policies may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://mailchimp.com/legal/", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://mailchimp.com/legal/", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Website Analytics", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Web Analytics", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Speed Insights", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to collect anonymous website usage data. This data helps us understand website performance and improve user experience. No personally identifiable information (PII) is collected through analytics, and we retain this data in accordance with Vercel’s retention policies. Vercel's privacy policy for Web Analytics and Speed Insights may be found at: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/analytics/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/analytics/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/speed-insights/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/speed-insights/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " respectively.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "How We Use Your Information", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use the information we collect for the following purposes:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To respond to your inquiries submitted through the contact form.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To send newsletters to subscribers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To analyze website performance and improve functionality.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information Sharing", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not sell, trade, or share your information with third parties, except as necessary to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Provide the services mentioned above (e.g., Web3Forms, Mailchimp, Vercel Web Analytics).", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Comply with legal obligations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Data Retention", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We retain your information only as long as necessary to fulfill the purposes outlined in this policy:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact form submissions are retained indefinitely unless you specifically request deletion.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Newsletter subscription data is retained indefinitely for record-keeping purposes, even after you unsubscribe.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Anonymous analytics data is retained according to Vercel’s retention policies.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Your Rights", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You have the following rights regarding your data:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Access: ", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": "Request access to the data we have about you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Correction:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request correction of any inaccurate information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Deletion:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request deletion of your data, subject to legal and contractual limitations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 4, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Unsubscribe:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Opt-out of our newsletter at any time. Your data is not deleted when you unsubscribe, and you must submit a request of deletion to have your information removed.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You do not have the right to access, modify, or request the removal of non-personally identifiable information, as it is fully anonymized. Since we have no way to track this data, we cannot delete it, nor can we request its removal from any third parties.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To exercise these rights, please contact us at ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Security", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We take reasonable measures to protect your data from unauthorized access, alteration, or disclosure. However, no system is completely secure, and we cannot guarantee absolute security.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Changes to This Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update this Privacy Policy from time to time. Changes will be posted on this page with an updated effective date. It is your responsibility to remain updated with said changes.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have questions or concerns about this Privacy Policy, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for trusting MindVista with your information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:57:12.748+00	2025-01-18 04:00:44.589+00	published	2025-02-21 23:57:12.88+00	2025-02-21 23:57:12.88+00	t
3	5	2	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-02-06", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista (\\"we,\\" \\"our,\\" or \\"us\\") values your privacy. This Privacy Policy outlines how we collect, use, and protect your information when you use our website (mindvista.ca). This Privacy Policy is intended to be easy to understand, and we avoid legal jargon whenever possible. However, to ensure transparency and protection, we provide links detailing how third-party services handle your information. Below, you'll find a complete list of the data we collect and how we use it.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies and Local Storage", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not use cookies on our website. We use local storage to remember your preferences, such as your choice of dark or light theme. This data is stored on your device only and is not transmitted to our servers. You can manage or clear this data at any time through your browser settings.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information We Collect", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We collect only the following information:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Contact Form Submissions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "When you fill out a contact form on our website, we use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Web3Forms", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to process your submission. The information you provide, such as your name, email address, and message, is used solely for responding to your inquiry. Contact form submissions may be retained indefinitely unless a deletion request is made. Web3Forms' privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://web3forms.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://web3forms.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use hCaptcha to prevent spam and ensure user actions on our online service (such as submitting a contact form) meet our security requirements. To do this, hCaptcha analyzes the behavior of the website or mobile app visitor based on various characteristics. This analysis starts automatically as soon as the website or mobile app visitor enters a part of the website or app with hCaptcha enabled. For the analysis, hCaptcha evaluates various information (e.g. IP address, how long the visitor has been on the website or app, or mouse movements made by the user). The data collected during the analysis will be forwarded to IMI. hCaptcha analysis in the \\"invisible mode\\" may take place completely in the background. Website or app visitors are not advised that such an analysis is taking place if the user is not shown a challenge. For more information on this process, hCaptcha's privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://www.hcaptcha.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://www.hcaptcha.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Newsletter Subscriptions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you subscribe to our newsletter, we collect your email address via ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Mailchimp", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to send you updates and news. While you can unsubscribe at any time by clicking the unsubscribe link in any email, we may retain your email address and subscription data in an archive for record-keeping purposes. Mailchimp's policies may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://mailchimp.com/legal/", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://mailchimp.com/legal/", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Website Analytics", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Web Analytics", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Speed Insights", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to collect anonymous website usage data. This data helps us understand website performance and improve user experience. No personally identifiable information (PII) is collected through analytics, and we retain this data in accordance with Vercel’s retention policies. Vercel's privacy policy for Web Analytics and Speed Insights may be found at: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/analytics/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/analytics/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/speed-insights/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/speed-insights/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " respectively.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "How We Use Your Information", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use the information we collect for the following purposes:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To respond to your inquiries submitted through the contact form.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To send newsletters to subscribers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To analyze website performance and improve functionality.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information Sharing", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not sell, trade, or share your information with third parties, except as necessary to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Provide the services mentioned above (e.g., Web3Forms, Mailchimp, Vercel Web Analytics).", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Comply with legal obligations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Data Retention", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We retain your information only as long as necessary to fulfill the purposes outlined in this policy:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact form submissions are retained indefinitely unless you specifically request deletion.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Newsletter subscription data is retained indefinitely for record-keeping purposes, even after you unsubscribe.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Anonymous analytics data is retained according to Vercel’s retention policies.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Your Rights", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You have the following rights regarding your data:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Access: ", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": "Request access to the data we have about you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Correction:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request correction of any inaccurate information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Deletion:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request deletion of your data, subject to legal and contractual limitations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 4, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Unsubscribe:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Opt-out of our newsletter at any time. Your data is not deleted when you unsubscribe, and you must submit a request of deletion to have your information removed.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You do not have the right to access, modify, or request the removal of non-personally identifiable information, as it is fully anonymized. Since we have no way to track this data, we cannot delete it, nor can we request its removal from any third parties.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To exercise these rights, please contact us at ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Security", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We take reasonable measures to protect your data from unauthorized access, alteration, or disclosure. However, no system is completely secure, and we cannot guarantee absolute security.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Changes to This Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update this Privacy Policy from time to time. Changes will be posted on this page with an updated effective date. It is your responsibility to remain updated with said changes.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have questions or concerns about this Privacy Policy, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for trusting MindVista with your information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:54:16.56+00	2025-01-18 04:00:44.589+00	draft	2025-02-21 23:54:16.707+00	2025-02-21 23:54:16.708+00	f
2	5	2	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-02-06", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista (\\"we,\\" \\"our,\\" or \\"us\\") values your privacy. This Privacy Policy outlines how we collect, use, and protect your information when you use our website (mindvista.ca). This Privacy Policy is intended to be easy to understand, and we avoid legal jargon whenever possible. However, to ensure transparency and protection, we provide links detailing how third-party services handle your information. Below, you'll find a complete list of the data we collect and how we use it.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies and Local Storage", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not use cookies on our website. We use local storage to remember your preferences, such as your choice of dark or light theme. This data is stored on your device only and is not transmitted to our servers. You can manage or clear this data at any time through your browser settings.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information We Collect", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We collect only the following information:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Contact Form Submissions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "When you fill out a contact form on our website, we use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Web3Forms", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to process your submission. The information you provide, such as your name, email address, and message, is used solely for responding to your inquiry. Contact form submissions may be retained indefinitely unless a deletion request is made. Web3Forms' privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://web3forms.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://web3forms.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use hCaptcha to prevent spam and ensure user actions on our online service (such as submitting a contact form) meet our security requirements. To do this, hCaptcha analyzes the behavior of the website or mobile app visitor based on various characteristics. This analysis starts automatically as soon as the website or mobile app visitor enters a part of the website or app with hCaptcha enabled. For the analysis, hCaptcha evaluates various information (e.g. IP address, how long the visitor has been on the website or app, or mouse movements made by the user). The data collected during the analysis will be forwarded to IMI. hCaptcha analysis in the \\"invisible mode\\" may take place completely in the background. Website or app visitors are not advised that such an analysis is taking place if the user is not shown a challenge. For more information on this process, hCaptcha's privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://www.hcaptcha.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://www.hcaptcha.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Newsletter Subscriptions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you subscribe to our newsletter, we collect your email address via ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Mailchimp", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to send you updates and news. While you can unsubscribe at any time by clicking the unsubscribe link in any email, we may retain your email address and subscription data in an archive for record-keeping purposes. Mailchimp's policies may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://mailchimp.com/legal/", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://mailchimp.com/legal/", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Website Analytics", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Web Analytics", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Speed Insights", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to collect anonymous website usage data. This data helps us understand website performance and improve user experience. No personally identifiable information (PII) is collected through analytics, and we retain this data in accordance with Vercel’s retention policies. Vercel's privacy policy for Web Analytics and Speed Insights may be found at: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/analytics/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/analytics/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/speed-insights/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/speed-insights/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " respectively.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "How We Use Your Information", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use the information we collect for the following purposes:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To respond to your inquiries submitted through the contact form.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To send newsletters to subscribers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To analyze website performance and improve functionality.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information Sharing", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not sell, trade, or share your information with third parties, except as necessary to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Provide the services mentioned above (e.g., Web3Forms, Mailchimp, Vercel Web Analytics).", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Comply with legal obligations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Data Retention", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We retain your information only as long as necessary to fulfill the purposes outlined in this policy:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact form submissions are retained indefinitely unless you specifically request deletion.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Newsletter subscription data is retained indefinitely for record-keeping purposes, even after you unsubscribe.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Anonymous analytics data is retained according to Vercel’s retention policies.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Your Rights", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You have the following rights regarding your data:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Access: ", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": "Request access to the data we have about you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Correction:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request correction of any inaccurate information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Deletion:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request deletion of your data, subject to legal and contractual limitations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 4, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Unsubscribe:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Opt-out of our newsletter at any time. Your data is not deleted when you unsubscribe, and you must submit a request of deletion to have your information removed.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You do not have the right to access, modify, or request the removal of non-personally identifiable information, as it is fully anonymized. Since we have no way to track this data, we cannot delete it, nor can we request its removal from any third parties.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To exercise these rights, please contact us at ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Security", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We take reasonable measures to protect your data from unauthorized access, alteration, or disclosure. However, no system is completely secure, and we cannot guarantee absolute security.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Changes to This Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update this Privacy Policy from time to time. Changes will be posted on this page with an updated effective date. It is your responsibility to remain updated with said changes.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have questions or concerns about this Privacy Policy, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for trusting MindVista with your information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:53:17.355+00	2025-01-18 04:00:44.589+00	draft	2025-02-21 23:53:17.547+00	2025-02-21 23:53:17.548+00	f
11	6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:57:28.411+00	2025-01-18 04:24:58.484+00	published	2025-02-21 23:57:28.489+00	2025-02-21 23:57:28.489+00	t
5	6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:56:21.052+00	2025-01-18 04:24:58.484+00	draft	2025-02-21 23:56:21.154+00	2025-02-21 23:56:21.155+00	f
6	6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:56:22.757+00	2025-01-18 04:24:58.484+00	published	2025-02-21 23:56:22.83+00	2025-02-21 23:56:22.83+00	f
8	6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:56:48.229+00	2025-01-18 04:24:58.484+00	draft	2025-02-21 23:56:48.229+00	2025-02-21 23:56:48.229+00	f
7	6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Condition", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-21 23:56:45.426+00	2025-01-18 04:24:58.484+00	draft	2025-02-21 23:56:45.426+00	2025-02-21 23:56:45.427+00	f
\.


--
-- Data for Name: _sponsor_v; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._sponsor_v (id, version_page_id, version_our_sponsors_section, version_our_sponsors_section_fr, version_callout, version_callout_fr, version_sponsor_us_section, version_sponsor_us_section_fr, version_updated_at, version_created_at, created_at, updated_at, version__status, latest) FROM stdin;
7	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:52:57.547+00	2025-02-22 17:52:57.547+00	draft	f
2	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	\N	\N	We&apos;d love to partner with like-minded organizations and individuals to help spread mental wellness. If you&apos;re passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:28:42.531+00	2025-02-22 17:28:42.531+00	draft	f
9	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 18:56:47.659+00	2025-02-22 17:53:17.579+00	2025-02-22 18:56:47.838+00	2025-02-22 18:56:47.838+00	published	f
6	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:51:31.118+00	2025-02-22 17:51:31.118+00	draft	f
11	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:16:28.839+00	2025-02-22 17:53:17.579+00	2025-02-22 19:16:28.974+00	2025-02-22 19:16:28.974+00	published	f
10	12	We are incredibly grateful  the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:16:19.529+00	2025-02-22 17:53:17.579+00	2025-02-22 19:16:19.655+00	2025-02-22 19:16:19.656+00	published	f
5	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:51:00.406+00	2025-02-22 17:51:00.407+00	draft	f
8	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 17:53:17.613+00	2025-02-22 17:53:17.579+00	2025-02-22 17:53:17.719+00	2025-02-22 17:53:17.72+00	published	f
4	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:29:19.034+00	2025-02-22 17:29:19.034+00	draft	f
3	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	\N	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	\N	\N	2025-02-22 17:28:56.877+00	2025-02-22 17:28:56.877+00	draft	f
15	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:32:23.601+00	2025-02-22 17:53:17.579+00	2025-02-22 19:32:23.724+00	2025-02-22 19:32:23.725+00	published	t
14	12	We are incredibly grateful for the suppor and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:32:20.194+00	2025-02-22 17:53:17.579+00	2025-02-22 19:32:20.321+00	2025-02-22 19:32:20.321+00	published	f
13	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:26:15.46+00	2025-02-22 17:53:17.579+00	2025-02-22 19:26:15.597+00	2025-02-22 19:26:15.598+00	published	f
1	\N	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	\N	\N	\N	\N	\N	\N	2025-02-22 17:27:15.849+00	2025-02-22 17:27:15.849+00	draft	f
12	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive chang	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:26:06.724+00	2025-02-22 17:53:17.579+00	2025-02-22 19:26:06.864+00	2025-02-22 19:26:06.865+00	published	f
\.


--
-- Data for Name: _sponsor_v_version_sponsors; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._sponsor_v_version_sponsors (_order, _parent_id, id, url, logo_id, _uuid) FROM stdin;
1	5	1	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	5	2	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	6	3	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	6	4	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	7	5	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	7	6	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	8	7	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	8	8	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	9	9	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	9	10	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	10	11	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	10	12	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	11	13	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	11	14	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	12	15	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	12	16	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	13	17	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	13	18	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	14	19	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	14	20	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
1	15	21	https://www.caffettiera.ca/	13	67ba0e553edd3b18dd28ceb4
2	15	22	https://www.ashtangamontreal.com/	14	67ba0e643edd3b18dd28ceb6
\.


--
-- Data for Name: club_tag_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.club_tag_categories (id, name, updated_at, created_at) FROM stdin;
13	Arts	2025-01-04 22:12:51.83+00	2025-01-04 22:12:51.83+00
14	Athletics	2025-01-04 22:12:52.524+00	2025-01-04 22:12:52.524+00
15	Career	2025-01-04 22:12:53.201+00	2025-01-04 22:12:53.201+00
16	Community Support	2025-01-04 22:12:55.796+00	2025-01-04 22:12:55.796+00
17	Culture	2025-01-04 22:12:56.925+00	2025-01-04 22:12:56.925+00
18	Faculty Specific	2025-01-04 22:12:58.315+00	2025-01-04 22:12:58.315+00
\.


--
-- Data for Name: club_tags; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.club_tags (id, name, updated_at, created_at, category_id) FROM stdin;
106	Fine Art	2025-01-04 22:12:52.043+00	2025-01-04 22:12:52.043+00	13
107	Performance	2025-01-04 22:12:52.281+00	2025-01-04 22:12:52.281+00	13
108	Athletics	2025-01-04 22:12:52.73+00	2025-01-04 22:12:52.73+00	14
109	Dance	2025-01-04 22:12:52.961+00	2025-01-04 22:12:52.961+00	14
110	Consulting	2025-01-04 22:12:53.398+00	2025-01-04 22:12:53.398+00	15
111	Entrepreneurship	2025-01-04 22:12:53.657+00	2025-01-04 22:12:53.657+00	15
112	Finance	2025-01-04 22:12:53.907+00	2025-01-04 22:12:53.907+00	15
113	Healthcare	2025-01-04 22:12:54.137+00	2025-01-04 22:12:54.137+00	15
114	Marketing	2025-01-04 22:12:54.414+00	2025-01-04 22:12:54.414+00	15
115	Networking	2025-01-04 22:12:54.648+00	2025-01-04 22:12:54.648+00	15
116	Politics	2025-01-04 22:12:54.88+00	2025-01-04 22:12:54.88+00	15
117	Professional Development	2025-01-04 22:12:55.111+00	2025-01-04 22:12:55.111+00	15
118	Real Estate	2025-01-04 22:12:55.339+00	2025-01-04 22:12:55.339+00	15
119	Technology	2025-01-04 22:12:55.567+00	2025-01-04 22:12:55.567+00	15
120	Community Outreach	2025-01-04 22:12:55.999+00	2025-01-04 22:12:55.999+00	16
121	Service	2025-01-04 22:12:56.223+00	2025-01-04 22:12:56.223+00	16
122	Social Activism	2025-01-04 22:12:56.459+00	2025-01-04 22:12:56.459+00	16
123	Sustainability	2025-01-04 22:12:56.695+00	2025-01-04 22:12:56.695+00	16
124	Leisure & Hobbies	2025-01-04 22:12:57.127+00	2025-01-04 22:12:57.127+00	17
125	Publication & Writing	2025-01-04 22:12:57.362+00	2025-01-04 22:12:57.362+00	17
126	Religion & Cultural	2025-01-04 22:12:57.603+00	2025-01-04 22:12:57.603+00	17
127	Spiritual	2025-01-04 22:12:57.834+00	2025-01-04 22:12:57.834+00	17
128	Student Society	2025-01-04 22:12:58.078+00	2025-01-04 22:12:58.078+00	17
129	Arts	2025-01-04 22:12:58.508+00	2025-01-04 22:12:58.508+00	18
130	Dentistry	2025-01-04 22:12:58.749+00	2025-01-04 22:12:58.749+00	18
131	Education	2025-01-04 22:12:58.981+00	2025-01-04 22:12:58.981+00	18
132	Engineering	2025-01-04 22:12:59.217+00	2025-01-04 22:12:59.217+00	18
133	Law	2025-01-04 22:12:59.448+00	2025-01-04 22:12:59.448+00	18
134	Management	2025-01-04 22:12:59.688+00	2025-01-04 22:12:59.688+00	18
135	Medicine	2025-01-04 22:12:59.917+00	2025-01-04 22:12:59.917+00	18
136	Music	2025-01-04 22:13:00.149+00	2025-01-04 22:13:00.149+00	18
137	Nursing	2025-01-04 22:13:00.383+00	2025-01-04 22:13:00.383+00	18
138	Physical Therapy	2025-01-04 22:13:00.615+00	2025-01-04 22:13:00.615+00	18
139	Science	2025-01-04 22:13:00.889+00	2025-01-04 22:13:00.889+00	18
140	Social Work	2025-01-04 22:13:01.127+00	2025-01-04 22:13:01.127+00	18
\.


--
-- Data for Name: clubs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clubs (id, slug, title, description, website, email, phone_number, facebook, instagram, updated_at, created_at, currently_active, newsletter, title_fr, description_fr, graphic_id, graphic_title, graphic_title_fr) FROM stdin;
4	mcgill-karateka	McGill Karateka	McGill Karateka was created to facilitate McGill students’ access to Shotokan-style karate training. Through safe and inclusive trainings focused on katas (forms), kumite (sparring), and kihon (techniques), as well as karate related social events, the Club has the goal to encourage student networking as well as to improve physical and mental health.	\N	karatekamcgill@ssmu.ca	\N	https://www.facebook.com/McGillKarateka	\N	2025-01-05 17:39:00.369+00	2025-01-05 17:39:00.369+00	t	\N	\N	\N	\N	\N	\N
3	eus	Engineering Undergraduate Society (EUS)	The Engineering Undergraduate Society (EUS) is the representative body of the undergraduate students of engineering at McGill University. The EUS is a full-fledged not-for-profit organization that is financially independent from McGill. 	https://mcgilleus.ca/	vpstudentlife@mcgilleus.ca	\N	https://www.facebook.com/mcgilleus	https://www.instagram.com/mcgilleus/	2025-01-24 15:34:29.83+00	2025-01-05 17:38:56.382+00	t	\N	\N	\N	\N	\N	\N
6	psa-philosophy-students-association	PSA – Philosophy Students’ Association	The Philosophy Students’ Association (PSA) at McGill University organizes philosophical activities, as well as social and fundraising events, throughout the year. It receives support from the Arts Undergraduate Society and the Department of Philosophy.	https://mcgillpsa.wixsite.com/website	mcgillpsa@gmail.com	\N	https://www.facebook.com/McGillPSA	https://www.instagram.com/mcgill.psa/	2025-01-24 15:38:09.732+00	2025-01-05 17:39:13.307+00	t	\N	\N	\N	\N	\N	\N
7	heal-and-hope	Heal and Hope	Heal and Hope is a recently founded club that works to host and coordinate events to simultaneously raise awareness for the overlooked cases of children with war-related injuries and fundraise for reconstructive surgeries that they require. They also aim to connect McGill students to volunteering opportunities through the Children of Water foundation’s global reach mission.	https://www.healandhope.net/	healandhope@ssmu.ca	\N	https://www.facebook.com/HealAndHopeMcGill	https://instagram.com/healandhopeclub	2025-01-24 15:38:56.658+00	2025-01-05 17:39:17.039+00	t	\N	\N	\N	\N	\N	\N
8	mcconnect	McConnect	McConnect is a club whose overarching purpose is to give students the resources to broaden their networks and acquire professional experience in multiple domains. They aim to supply students with workshops, opportunities, and support networks needed to prosper post-graduation. Throughout workshops, they uncover the secrets behind acing interviews in various fields and showcasing your best side in internship and grad school applications. 	https://www.mcconnectmcgill.ca/	mcconnect@ssmu.ca	\N	https://www.facebook.com/people/McConnect-McGill/100084661640248/?mibextid=LQQJ4d	https://www.instagram.com/mcconnect_mcgill?igshid=Zjc2ZTc4Nzk%3D	2025-01-24 15:47:29.129+00	2025-01-05 17:39:17.513+00	t	\N	\N	\N	\N	\N	\N
10	folio-magazine	Folio Magazine	Folio is a student-run visual art and design magazine that acts as an ongoing archive of McGill’s artistic community by providing a venue for student artists to showcase their work. It is published biannually.	https://www.foliomagazine.ca/	foliomag@gmail.com	\N	https://www.facebook.com/foliooo	https://www.instagram.com/foliomagazine/?hl=en	2025-01-24 15:49:57.934+00	2025-01-05 17:39:36.798+00	t	\N	\N	\N	\N	\N	\N
12	mcwics	McGill Women in Computer Science (McWiCS)	McWiCS seeks to cultivate a warm, open-minded community of techies dedicated to supporting and encouraging women in computer science. They work to expand the opportunities of women to explore all aspects of the technological world and to encouraging them to create a positive impact on it.	http://mcwics.com/	team@mcwics.com	\N	http://facebook.com/mcwics	https://www.instagram.com/mcgillwics/?hl=en	2025-01-24 15:53:04.655+00	2025-01-05 17:39:43.499+00	t	\N	\N	\N	\N	\N	\N
13	mchacks-hacks-at-students-society-of-mcgill-university	McHacks – Hacks at Students’ Society of McGill University	HackMcGill is the student-run group that organizes the premier annual hackathon, McHacks. They bring together a diverse group of over 500 students from across North America for 24 hours to build projects and applications that range from hardware to mobile to artificial intelligence. Whether you are a seasoned hacker or have never written a line of code, HackMcGill welcomes you to join their team.	https://mchacks.ca/	hackmcgill@ssmu.ca	\N	https://www.facebook.com/mcgillhacks	https://www.instagram.com/mcgillhacks	2025-01-24 15:54:28.544+00	2025-01-05 17:39:44.129+00	t	\N	\N	\N	\N	\N	\N
14	mass	McGill African Students Society (MASS)	The McGill African Students Society (MASS) is a full status club whose mandate is to promote and present the diverse and rich African cultures to the McGill community and the greater Montreal area. They are a diverse group of students who are not solely African but are passionate about African-oriented topics. They host a range of events each semester, each targeting different facets of African culture and life, and hope to spread knowledge and inspire passion about African culture and issues both on and off campus.	https://massmcgill.wixsite.com/mass	mass@ssmu.ca	\N	https://www.facebook.com/McGillMASS	http://www.instagram.com/McgillMASS	2025-01-24 15:55:32.612+00	2025-01-05 17:39:51.678+00	t	\N	\N	\N	\N	\N	\N
11	cnsa	Canadian Nursing Students Association (CNSA)	The Canadian Nursing Students’ Association (CNSA) is the national voice of Canadian nursing students with the goal is to increase the legal, ethical, professional, and educational aspects which are an integral part of nursing. CNSA is actively dedicated to the positive promotion of nurses and the nursing profession as a whole.	http://www.cnsa.ca/	mcgill@cnsa.ca	\N	https://www.facebook.com/CNSA.AEIC	\N	2025-01-25 22:51:45.167+00	2025-01-05 17:39:40.404+00	f	\N	\N	\N	\N	\N	\N
19	the-factory	The Factory	The Factory is a hardware design lab run by students, for students in the department of Electrical, Computer, and Software Engineering at McGill University. The Factory is a dedicated space in room 0080 of the Trottier building for developing personal projects, gaining experience with the latest hardware, or just brainstorming ideas with fellow students. The Factory aims to foster an environment of innovation and collaboration where the resources are provided to make your ideas become a reality.	https://factory.mcgilleus.ca/	http://mailto:thefactory@mcgilleus.ca/	\N	https://www.facebook.com/ecsessfactory	https://www.instagram.com/thefactory_mcgill	2025-01-05 17:40:13.497+00	2025-01-05 17:40:13.497+00	t	\N	\N	\N	\N	\N	\N
25	monty	The Monteregian Society (Monty)	The undergraduate society for Earth & Planetary Sciences and Earth System Science students at McGill University.	https://www.monteregiansociety.com/	monteregian@eps.mcgill.ca	\N	https://www.facebook.com/profile.php	https://www.instagram.com/montysociety	2025-01-05 17:42:46.029+00	2025-01-05 17:42:46.029+00	t	\N	\N	\N	\N	\N	\N
16	the-plate-club	The Plate Club	The Plate Club is a free dishware rental service dedicated to providing a sustainable alternative to disposable dishware for on- and off-campus events. They have everything you'd need to host any event, from plates, forks, wine glasses, pitchers and more.	http://theplateclub.wixsite.com/mcgill	theplateclub@ssmu.ca	\N	http://facebook.com/theplateclubmcgill	https://www.instagram.com/theplateclub/	2025-01-24 16:06:56.33+00	2025-01-05 17:39:59.167+00	f	\N	\N	\N	\N	\N	\N
17	aiesec-mcgill	AIESEC McGill	AIESEC is the largest student-run nonprofit organization in 127 countries. They aim to develop leadership by sending students abroad for international volunteer and internship programs.	http://aiesec.ca/	general@aiesecmcgill.ca	\N	https://www.facebook.com/AIESECCanada	https://www.instagram.com/aiesecinmcgill/?hl=en-gb	2025-01-24 16:07:50.318+00	2025-01-05 17:40:01.548+00	f	\N	\N	\N	\N	\N	\N
20	sus	Science Undergraduate Society (SUS)	The Science Undergraduate Society (SUS) of McGill University is a student-run organization located at 805 Sherbrooke St. W. in Burnside Hall Room 1B21. They support over 5000 undergraduate students and their respective departments pursuing their degrees in sciences and art sciences.	https://susmcgill.ca/	communications@susmcgill.ca	\N	https://www.facebook.com/susmcgill	https://www.instagram.com/mcgillsus	2025-01-24 16:13:21.34+00	2025-01-05 17:42:42.892+00	t	\N	\N	\N	\N	\N	\N
21	macss	The McGill Anatomy and Cell Biology Students’ Society (MACSS)	MACSS is the student council for Anatomy and Cell Biology. 	https://macssmcgill.com/	macss.officehours@gmail.com	\N	https://www.facebook.com/McGillAnat	https://www.instagram.com/macssmcgill	2025-01-24 16:17:30.419+00	2025-01-05 17:42:43.353+00	t	\N	\N	\N	\N	\N	\N
22	pils	Pharmacology Integrative League of Students (PILS)	PILS represents undergraduate students in the Department of Pharmacology and Therapeutics at McGill University. As the liaison between the department and students, PILS is the undergraduate voice within the department.	https://pils.sus.mcgill.ca/	pilsmcgill@gmail.com	\N	https://www.facebook.com/pilsmcgill	https://www.instagram.com/pils.mcgill	2025-01-24 16:18:37.598+00	2025-01-05 17:42:44.175+00	t	\N	\N	\N	\N	\N	\N
23	puls	Physiology Undergraduate League of Students (PULS)	PULS represents undergraduates in the Department of Physiology by advocating and connecting students to the physiology program, professors, and the greater McGill community. Located in McIntyre Medical Building Room 1017, PULS hosts daily office hours where students are welcome to study, hang out, and use the appliances we have to offer, such as a microwave, printer, and free lab coat rentals. PULS organizes academic initiatives in the form of class note resources, Journal Clubs, and the annual Wine and Cheese to inform undergraduate students about the physiology program at McGill. PULS also hosts many social events throughout the semester with the most popular being the biweekly PHGY Fridays at the campus bar and various formal and interdepartmental events throughout the year.	http://puls.sus.mcgill.ca/	puls@sus.mcgill.ca	\N	https://www.facebook.com/pulsmcgill	https://www.instagram.com/pulsmcgill	2025-01-24 16:20:04.091+00	2025-01-05 17:42:44.574+00	t	\N	\N	\N	\N	\N	\N
24	the-chemistry-undergraduate-students-society	The Chemistry Undergraduate Students’ Society	The Chemistry Undergraduate Students’ Society is a group of chemistry students elected by their peers with the goal of building a community for all undergraduates in the department of chemistry, by organizing both academic and social events and services. 	https://cussmcgill.ca/	mcgill.chemistry@gmail.com	\N	https://www.facebook.com/mcgilluCUSS	https://www.instagram.com/cuss_mcgill	2025-01-24 16:20:28.792+00	2025-01-05 17:42:45.459+00	t	\N	\N	\N	\N	\N	\N
26	msps	McGill Society of Physics Students (MSPS)	The McGill Society of Physics Students (MSPS) is McGill's official organisation representing the undergraduates in physics, including joint majors, and minors.	http://msps.sus.mcgill.ca/	mcgill.physics@gmail.com	\N	https://www.facebook.com/mcgillphysics	https://www.instagram.com/msps_mcgill	2025-01-24 16:21:32.17+00	2025-01-05 17:42:47.083+00	t	\N	\N	\N	\N	\N	\N
27	mpsa	McGill Psychology Students Association (MPSA)	MPSA is the McGill psychology undergraduate community's source of academic and social events and resources for students.	https://www.mpsamcgill.com/	mpsa.mcgill@gmail.com	\N	https://www.facebook.com/mcgillpsychology	https://www.instagram.com/msps_mcgill	2025-01-24 16:22:24.905+00	2025-01-05 17:42:47.484+00	t	\N	\N	\N	\N	\N	\N
58	mcgill-students-for-unicef	McGill Students for UNICEF	McGill Students for UNICEF (MSFU) is the McGill chapter for UNICEF.​ They work towards raising funds and awareness for a different crisis emergency fund every year.	https://unicefmcgill.weebly.com/	unicefmcgill@gmail.com	\N	https://www.facebook.com/McGillUNICEF	https://www.instagram.com/unicefmcgill	2025-01-24 17:18:01.09+00	2025-01-05 17:43:04.795+00	t	\N	\N	\N	\N	\N	\N
29	edus	Education Undergraduate Society (EdUS)	The Education Undergraduate Society represents the interests of all undergraduate students in the Faculty of Education to the university and various external organizations. Every Education undergraduate student (including Kin!) is automatically a member of the EdUS, which is funded by a $10-per-semester student fee. The EdUS also provides its students with a wide range of events and services that are designed to enhance their experience at McGill. 	https://www.edusmcgill.com/	admin.edus@mail.mcgill.ca	\N	https://www.facebook.com/EdUSMcGill	https://www.instagram.com/edusmcgill	2025-01-24 16:24:02.877+00	2025-01-05 17:42:48.523+00	t	\N	\N	\N	\N	\N	\N
30	sapek	Student Association of Physical Education & Kinesiology (SAPEK)	SAPEK is a student run organization made up of physical and health education and kinesiology undergraduate students at McGill University.​ They seek to promote the academic and social prosperity of the students in the Department of Physical Education and Kinesiology (DPEK). Throughout the year, SAPEK organizes various departmental and faculty social events that bring professionals and students together. 	https://www.sapekmcgill.com/	sapek.mcgill@gmail.com	\N	https://www.facebook.com/mcgillsapek	https://www.instagram.com/sapekmcgill	2025-01-24 16:25:16.826+00	2025-01-05 17:42:49.115+00	f	\N	\N	\N	\N	\N	\N
32	chess	Chemical Engineering Students' Society (ChESS)	ChESS provides events and services to all McGill Undergraduate Chemical Engineering Students! Their mission is to provide future engineers with the tools to succeed in their academics and career development.	https://chess.mcgilleus.ca/	chess.vpcomm@mcgilleus.ca	\N	https://www.facebook.com/mcgillchess	https://www.instagram.com/chessmcgill	2025-01-24 16:31:24.673+00	2025-01-05 17:42:50.168+00	t	\N	\N	\N	\N	\N	\N
33	ceus	Civil Engineering Undergraduate Society (CEUS)	CEUS is a student organization in the Department of Civil Engineering and Applied Mechanics. Their purpose is to organize activities to promote a sense of community among the undergraduate students in Civil Engineering.\n\nWe also collaborate closely with the Engineering Undergraduate Society of McGill, as well as the other Engineering departments, in planning and executing diverse events.  All undergraduate students automatically become members of the CEUS upon registration in the Civil Engineering program. Ultimately, our goal is to encourage civil engineering students to immerse themselves in the prosperous engineering community that McGill has to offer.	https://ceus.mcgilleus.ca/index.html	ceus.vpcomm@mcgilleus.ca	\N	https://www.facebook.com/ceusmcgill	https://www.instagram.com/ceusmcgill	2025-01-24 16:32:22.373+00	2025-01-05 17:42:50.551+00	t	\N	\N	\N	\N	\N	\N
34	mame	McGill Association of Mechanical Engineers (MAME)	The McGill Association of Mechanical Engineers (MAME) represents over 700 undergraduate mechanical engineering students at McGill University. The elected student council of the association provides yearlong services and events for all of the students within the mechanical engineering department. 	https://mame.mcgilleus.ca/	mame.vpcomm@mcgilleus.ca	\N	https://www.facebook.com/mamemcgill	https://www.instagram.com/mame_mcgill	2025-01-24 16:33:27.006+00	2025-01-05 17:42:51.405+00	t	\N	\N	\N	\N	\N	\N
35	cmeus	Co-Op Mining Engineering Undergraduate Society (CMEUS)	CMEUS is the undergraduate society (within EUS) for all mining students. They organize several events and fun opportunities for involvement throughout each academic year.  	https://www.mcgill.ca/mining/undergraduate/student-life/co-op-mining-engineering-undergraduate-society	cmeus.president@mcgilleus.ca	\N	https://www.facebook.com/cmeus.mcgill	https://www.instagram.com/mcgill.mining	2025-01-24 16:37:11.777+00	2025-01-05 17:42:51.983+00	t	\N	\N	\N	\N	\N	\N
31	asa	McGill Architecture Student Association (ASA)	The Architecture Students' Association (ASA) is the undergraduate student government of the School of Architecture at McGill University. It is a non-profit student-run society which serves as an organizational body for student activities and affairs - a way to voice academic and university issues, as well as a link to other architecture schools in Canada. 			\N	https://www.facebook.com/ASA.McGill	https://www.instagram.com/mcgill.asa	2025-01-25 22:52:18.369+00	2025-01-05 17:42:49.728+00	f	\N	\N	\N	\N	\N	\N
42	mcgill-student-boxing-club	McGill Student Boxing Club	This is a student-run club that aims to bring together both boxers and aspiring boxers of McGill University and provide trainings in a safe and social environment. The club is co-ed and people of all skill levels are welcome!	https://mcgillstudentboxingclub.ca/	mcgillboxingclub@ssmu.ca	\N	https://www.facebook.com/McGillBoxingClub	https://www.instagram.com/mcgillssmuboxing	2025-01-05 17:42:56.597+00	2025-01-05 17:42:56.597+00	t	\N	\N	\N	\N	\N	\N
83	csa-classics-students-association	CSA – Classics Students’ Association	The CSA allows students who love the Ancient Mediterranean World in all its aspects to come together	https://mcgillcsa.com/	classics.students.mcgill@gmail.com	\N	https://www.facebook.com/csamcgill	https://www.instagram.com/mcgillcsa	2025-01-05 17:43:18.427+00	2025-01-05 17:43:18.427+00	t	\N	\N	\N	\N	\N	\N
37	law-students-association	Law Students' Association	The Law Students' Association was created on March 12, 1912.  The LSA is the official student organization of the Faculty of Law of McGill University. They aim to represent your voice in the Faculty's administration as well as offering services, organizing events and supporting your projects. 	https://www.lsa-aed.ca/		\N	https://www.facebook.com/mcgillLSA	https://www.instagram.com/mcgilllsa	2025-01-24 16:39:45.463+00	2025-01-05 17:42:53.062+00	t	\N	\N	\N	\N	\N	\N
38	nus	Nursing Undergraduate Society (NUS)	The Nursing Undergraduate Society is the student-run representation of McGill’s Ingram School of Nursing. Their primary mandate is to act as a liaison between the staff and students and provide a means of contact with other organizations and groups on campus and throughout Canada. They organize all extracurricular activities for Nursing students in addition to their academic role. 	https://www.mcgillnus.ca/	nus.nursing@mail.mcgill.ca	\N	https://www.facebook.com/McGillNursing	https://www.instagram.com/mcgillnus	2025-01-24 16:45:49.792+00	2025-01-05 17:42:53.498+00	t	\N	\N	\N	\N	\N	\N
39	swsa	Social Work Students' Association (SWSA)	SWSA is a liaison between students and faculty at the School of Social Work and between the School of Social Work and the wider McGill University community. 	https://www.mcgill.ca/socialwork/students/swsa	internal.swsa@mail.mcgill.ca	\N	https://www.facebook.com/McGillSWSA	https://www.instagram.com/swsamcgill	2025-01-24 16:46:37.037+00	2025-01-05 17:42:53.995+00	t	\N	\N	\N	\N	\N	\N
40	mss	Medical Students' Society (MSS)	The mission of MSS is to represent its members and promote their views in all dealings with the Faculty of Medicine of McGill University, McGill University, professional organizations and the community at large; to promote activities encouraging interaction between its members; to facilitate and promote the formation and functioning of Society organizations, clubs, and committees; to disseminate information pertinent to the academic, professional, and cultural enrichment of all Society members; and to act as a positive leader in the McGill University community and the community at large.	https://mcgillmed.com/	vpinternal.mss@mail.mcgill.ca	\N	https://www.facebook.com/MSSmcgill	https://www.instagram.com/mcgillmss	2025-01-24 16:47:37.277+00	2025-01-05 17:42:54.379+00	t	\N	\N	\N	\N	\N	\N
41	mcgill-climbing-club	McGill Climbing Club	The McGill Climbing Club is a place where McGill students can try or develop their climbing! Ranging from beginners to national level climbers, the club has a spot for anyone who is interested in climbing. Each semester they run trips outdoors as well as weekly themed climbing sessions.	https://www.mcgilloutdoorsclub.ca/rock-climbing	mcgillclimbing@ssmu.ca	\N	https://www.facebook.com/p/McGill-Climbing-Club-100087166224542/?locale=en_GB	https://www.instagram.com/mcgillclimbing	2025-01-24 16:49:58.908+00	2025-01-05 17:42:55.776+00	t	\N	\N	\N	\N	\N	\N
43	mcgill-students-outdoors-club	McGill Student’s Outdoors Club	The MOC mission is to get you outside, no matter what your experience. They run trips, rent out gear at low prices, and provide a communal house in the foothills of the Shield. The MOC is one of the oldest Outdoors Clubs in Montreal, founded in 1936. If you love the outdoors and you live near Montreal, you can join the MOC!	https://mcgilloutdoorsclub.ca/	info@mcgilloutdoorsclub.ca	\N	https://www.facebook.com/mcgilloutdoorsclub	https://www.instagram.com/mcgilloutdoorsclub	2025-01-24 16:51:32.055+00	2025-01-05 17:42:56.995+00	t	\N	\N	\N	\N	\N	\N
44	mcgill-students-cricket-club	McGill Students Cricket Club	McGill Cricket Club constitutes cricket loving enthusiasts who aim to promote the beautiful game of cricket among the McGill population and attract cricketers from all the different fields at McGill to play and represent their prestigious University in local, national and international cricket tournaments. The McGill Cricket Club has been recognized by Cricket Canada, Quebec Cricket Federation (QCF) and American College Cricket.		mcgillcricket@ssmu.ca	\N	https://www.facebook.com/McGill-Cricket-Club-1966396963574279	https://www.instagram.com/mcgillcricketclub	2025-01-24 16:52:30.478+00	2025-01-05 17:42:57.479+00	t	\N	\N	\N	\N	\N	\N
45	mcgill-students-running-club-mcrun	McGill Students Running Club – McRun	McRUN is a recreational running club that meets every week to provide students the opportunity to get to know each other while going on short runs around Montreal. They welcome runners of all levels and host different paced runs multiple times a week. 	http://mcrunmcgill.com/	mcrunningclub@ssmu.ca	\N	https://www.facebook.com/mcrunmcgill	https://www.instagram.com/mcgillstudentsrunningclub	2025-01-24 16:53:11.963+00	2025-01-05 17:42:57.928+00	t	\N	\N	\N	\N	\N	\N
46	poseidon-water-polo	Poseidon Water Polo	Poseidon Water Polo student run club that aims to bring together water polo players of all experience levels. Poseidon plays in the University and Quebec Water Polo leagues. They practice are twice a week and it's a great to stay in shape and make new friends!	\N	poseidonwaterpolo@ssmu.ca	\N	https://www.facebook.com/mcgillwaterpolo	https://www.instagram.com/mcgillwaterpolo/	2025-01-24 16:54:47.154+00	2025-01-05 17:42:58.53+00	t	\N	\N	\N	\N	\N	\N
48	borderless-world-volunteers	Borderless World Volunteers	Borderless World Volunteers is a registered Canadian charity founded in 2003 with the goal of helping undergraduate university students lead development projects across the globe while contributing to the wellness of their own local communities. Borderless World Volunteers was founded to provide a link between university students and local development organizations in developing countries.	http://www.borderlessworld.org/	borderlessworldvolunteers@ssmu.ca	\N	https://www.facebook.com/BWVMcGill	https://www.instagram.com/bwvmcgill	2025-01-05 17:42:59.815+00	2025-01-05 17:42:59.815+00	t	\N	\N	\N	\N	\N	\N
55	mcgill-students-for-make-a-wish	McGill Students for Make-A-Wish	McGill Students for Make-a-Wish is a chapter of the Make A Wish Foundation located at McGill University. Throughout the year, we organize various events, both social and athletic to raise funds for Make-A-Wish Quebec. Our mission is to adopt one child’s wish every year as well as to raise awareness to the student body about this great cause. Last year we met this goal.	https://makeawish.ssmu.ca/	makeawish@ssmu.ca	\N	https://www.facebook.com/mcgillstudentsformakeawish	https://www.instagram.com/makeawishmcgill	2025-01-05 17:43:03.486+00	2025-01-05 17:43:03.486+00	f	\N	\N	\N	\N	\N	\N
49	energy-association	McGill Energy Association (MEA)	The MEA focuses on bringing the McGill community stimulating events regarding climate change and the energy transition to increase awareness and conversation.  The McGill Energy Journal is their editorial where a strong team of editors and writers produce content to provide further information and insight.		mcgillenergyassociation@ssmu.ca	\N	https://www.facebook.com/McGillEnergyAssociation	https://www.instagram.com/mcgillenergyassociation	2025-01-24 16:59:39.944+00	2025-01-05 17:43:00.294+00	t	\N	\N	\N	\N	\N	\N
50	environmental,-social,-governance	ESG (Environmental, Social, Governance) McGill	Open to all students, ESG (Environmental, Social, Governance) McGill is focused on improving members’ financial literacy skills while exploring how market-based solutions can help mitigate social and climate issues. They are an environmentally oriented business club seeking diverse points of view from all perspectives. Through educational reporting, networking opportunities, and speaker events, ESG McGill seeks to promote the emerging sphere of ESG on campus.	http://esg.ssmu.ca/	esg@ssmu.ca	\N	https://www.facebook.com/esgmcgill	https://www.instagram.com/esg_mcgill	2025-01-24 17:01:19.692+00	2025-01-05 17:43:00.77+00	t	\N	\N	\N	\N	\N	\N
52	mcgill-students-chapter-of-the-canadian-red-cross	McGill Students Chapter of the Canadian Red Cross	The McGill Students Chapter of the Canadian Red Cross is an officially-affiliated student chapter of the Canadian Red Cross. The objectives of the club are to hold events to raise awareness of the humanitarian and charitable initiative of the Canadian Red Cross, to raise funds in support of the Canadian Red Cross, and to provide interested students with information about how they can get involved with Canadian Red Cross initiative.	https://redcross.ssmu.ca/	redcrossmcgill@gmail.com	\N	https://www.facebook.com/mcgillredcross	https://www.instagram.com/mcgillstudentsforrc/	2025-01-24 17:06:10.675+00	2025-01-05 17:43:01.711+00	t	\N	\N	\N	\N	\N	\N
53	mcgill-students-for-concussion-legacy-foundation	McGill Students for Concussion Legacy Foundation	This group works on educating and spreading awareness about concussions within the Montreal community as well as providing support for those recovering from mild traumatic brain injuries and concussions. They educate through workshops and presentations and provide support through providing resources as well as offering a support group that meets twice a week.		concussionmtl@gmail.com	\N	https://www.facebook.com/concussionmtl	https://www.instagram.com/concussion.can.umcgill/	2025-01-24 17:09:24.332+00	2025-01-05 17:43:02.155+00	t	\N	\N	\N	\N	\N	\N
54	mcgill-students-for-heart-4-heart	McGill Students for Heart 4 Heart	Heart4Heart is a non-profit organization that raises money to fund surgeries for children born with congenital heart disease (CHD) in developing countries. Heart4Heart works on a one-child basis to fund one surgery at a time. They aim to raise awareness in the McGill community about CHD and the social disparity in healthcare, hoping to bridge the gap in access to medical treatment.	https://www.heart4heart.ca/mcgill-chapter	heart4heart@ssmu.ca	\N	https://www.facebook.com/heart4heartmcgill	https://www.instagram.com/heart4heart_mcgill	2025-01-24 17:11:19.64+00	2025-01-05 17:43:02.979+00	t	\N	\N	\N	\N	\N	\N
56	mcgill-students-for-right-to-play	McGill Students for Right to Play	McGill Students for Right To Play works within the student community to fundraise and spread awareness of the foundation. They plan athletic as well as social events in order to raise money for the international Right To Play organization and to expose the McGill community to a worthy cause. 	https://righttoplay.ca/en-ca	rtpmcgill@ssmu.ca	\N	https://www.facebook.com/rtpmcgill	https://www.instagram.com/rtpmcgill	2025-01-24 17:14:20.962+00	2025-01-05 17:43:03.919+00	t	\N	\N	\N	\N	\N	\N
57	mcgill-students-for-think-pink	McGill Students for Think Pink	Think Pink aims to raise awareness and funds for breast cancer research by hosting informative workshops and fun events.	https://involvement.mcgill.ca/organization/McGillThinkPink	president.thinkpink.mcgill@gmail.com	\N	https://www.facebook.com/McGillThinkPink	https://www.instagram.com/thinkpink.mcgill	2025-01-24 17:15:12.385+00	2025-01-05 17:43:04.391+00	t	\N	\N	\N	\N	\N	\N
51	fit-for-a-cause	Fit For a Cause	Fit For A Cause (FFAC) is a student-run charity fitness program in which fitness instructors volunteer their services teaching fitness classes whilst collecting donations for charity.  All proceeds that FFAC raises will be donated to an organization of choice, determined by the end of each semester.	http://contactffac.wixsite.com/ffacmcgill	contact.ffac@gmail.com	\N	https://www.facebook.com/FFACpage	https://www.instagram.com/fit_for_a_cause	2025-01-28 03:46:35.608+00	2025-01-05 17:43:01.247+00	f	\N	\N	\N	\N	\N	\N
69	desautels-exchange-network	Desautels Exchange Network	The DEN (Desautels Exchange Network) is a student-run organization whose mandate is to welcome and fully integrate exchange students into the student body. Through ongoing communication and regular social & cultural gatherings, DEN allows students to feel home away from home. Going on exchange opens a new world of experiences and the DEN is here to ensure a smooth, fun, and easy transition into life in Montreal. DEN also provides students with a link to other international associations in Montreal, such as MESA (McGill Exchange Students Association), IMA (International Management Association), and groups at Concordia and UQAM.	\N	den@musonline.com	\N	https://www.facebook.com/desautels.exchange.network	https://www.instagram.com/desautels.exchange.network	2025-01-05 17:43:10.555+00	2025-01-05 17:43:10.555+00	f	\N	\N	\N	\N	\N	\N
60	challah-for-hunger	Nazun (Challah for Hunger)	Nazun (formerly Challah for Hunger) is a student-run initiative that fundraises for food insecurity causes through selling challah on campus. Their events raise awareness of various social action causes, educate on Jewish events, and make food in a supportive and energetic environment.		challah4hungermtl@gmail.com	\N	https://www.facebook.com/cfhmtl	https://www.instagram.com/nazunmtl/	2025-01-24 17:21:17.396+00	2025-01-05 17:43:05.695+00	t	\N	\N	\N	\N	\N	\N
61	simplydonate	SimplyDonate	SimplyDonate is a non profit organization that aims to facilitate the collection of items to be delivered to shelters and people in need. We have collected over 11,000 pounds of clothing since the organization’s founding in June 2016! By conducting clothing drives throughout the year, raising awareness on campus about reducing clothing waste, and delivering donations to charities and local donation centres, they seek to institute positive change within our community, as well as provide opportunities to McGill students to volunteer with us and make a difference.	https://simplydonatecanada.wixsite.com/website	simplydonate@ssmu.ca	\N	https://www.facebook.com/SimplyDonate	https://www.instagram.com/simplydonatessmu	2025-01-24 17:22:08.236+00	2025-01-05 17:43:06.275+00	t	\N	\N	\N	\N	\N	\N
62	students-association-for-multiple-sclerosis	Student’s Association for Multiple Sclerosis (SAMS)	SAMS aims to increase awareness and fundraising for Multiple Sclerosis (MS) through various events and programs. Canada has one of the highest prevalence rates of MS, which mostly affects the young adult demographic. This same age group is the one that is found in the McGill student community.		sams@ssmu.ca	\N	https://www.facebook.com/samsmcgill	https://www.instagram.com/samsmcgill	2025-01-24 17:23:25.771+00	2025-01-05 17:43:06.707+00	f	\N	\N	\N	\N	\N	\N
63	synesthesia	Synesthesia	Synesthesia is a fashion for charity club based in Montreal and is inspired by its namesake – the neurological blending of cross-wired senses. In this regard, Synesthesia’s biggest fundraiser of the year, the Charity Fashion Show, stimulates the senses in a blend of charity, fashion, art, and music. Montreal’s up-and-coming multicultural creative scene inspires Synesthesia’s artistic vision. They aim to celebrate fashion by admiring the work of dedicated local designers that we feature in our annual Charity Fashion Show. Since its inception, Synesthesia has raised for $50,000 for multiple charities.	https://synesthesiamontreal.com/	synesthasiamcgill@gmail.com	\N	https://www.facebook.com/synesthesia.mtl	https://www.instagram.com/synesthesia.mtl/	2025-01-24 17:24:38.681+00	2025-01-05 17:43:07.135+00	t	\N	\N	\N	\N	\N	\N
64	through-their-eyes	Through Their Eyes	Through Their Eyes is a student organization on the McGill campus that is passionate about raising awareness about the plight of orphans all around the world. Over the past few years, they have focused on sponsoring children’s education and everyday living through both consistent regular donors as well as fundraising events. 	https://throughtheireyes.ssmu.ca/	throughtheireyes@ssmu.ca	\N	https://www.facebook.com/OSPMcGill	https://www.instagram.com/ttemcgill	2025-01-24 17:25:14.131+00	2025-01-05 17:43:07.887+00	f	\N	\N	\N	\N	\N	\N
66	desautels-tech-club	Desautels Tech Club	DTech organizes events that will help students gain exposure to the technology field in a manner that complements their studies. Whether that means meeting and learning from industry professionals, understanding the latest trends in technology for a specific industry or applying what they have learned in class in a real-world context, DTech bridges the gap between the classroom and industry.	https://www.dtechmcgill.ca/	dtech@mus.mcgill.ca	\N	https://www.facebook.com/dtechclub	https://www.instagram.com/dtech.mcgill	2025-01-24 17:26:53.701+00	2025-01-05 17:43:09.079+00	t	\N	\N	\N	\N	\N	\N
67	mcgill-sports-management-club	McGill Sports Management Club	The McGill Sports Management Club has tasked itself with providing opportunities to educate and inspire students, as well as provide them with opportunities to establish meaningful careers in the highly-competitive sports marketplace.	https://www.msmcgill.com/	msmc@musmcgill.ca	\N		https://www.instagram.com/mcgillsportsmanagement	2025-01-24 17:27:34.871+00	2025-01-05 17:43:09.48+00	t	\N	\N	\N	\N	\N	\N
65	beyond-me	Beyond Me	Beyond Me is a student-run non-profit organization in Montreal that provides one-on-one mentoring services for children and teenagers with special needs.	https://montrealbeyondme.wixsite.com/2023-2024	montrealbeyondme@gmail.com	\N	https://www.facebook.com/mtlbeyondme	https://www.instagram.com/beyondme_mcgill	2025-01-25 22:53:24.63+00	2025-01-05 17:43:08.323+00	f	\N	\N	\N	\N	\N	\N
68	mcgill-student-entrepreneurship-society	McGill Student Entrepreneurship Society	The McGill Student Entrepreneurship Society is a student-run group dedicated to promoting and celebrating the entrepreneurial spirit in McGill, Montreal, and beyond, through innovative student events and initiatives. They foster a community of students from all faculties dedicated to excellence and impact, offer unparalleled educational/career opportunities, and inspire by sharing success/alum stories.	https://entrepreneurship.ssmu.ca/	entrepreneurship@ssmu.ca	\N	https://www.facebook.com/mcgillentrepreneurship	https://www.instagram.com/mcgillentrepreneurship	2025-01-25 22:55:04.307+00	2025-01-05 17:43:10.087+00	t	\N	\N	\N	\N	\N	\N
75	mcgill-data-network	McGill Data Network	The McGill Data Network was created to prepare students for the ever-evolving data driven world by providing members with a platform to learn, develop and connect with data-related opportunities.	https://mcgilldatanetwork.weebly.com/	\N	\N	https://www.facebook.com/mcgilldatanetwork	https://www.instagram.com/mcgilldatanetwork	2025-01-05 17:43:13.737+00	2025-01-05 17:43:13.737+00	t	\N	\N	\N	\N	\N	\N
78	redpoint-capital	RedPoint Capital	RedPoint Capital (RPC) is McGill’s first and only finance club that focuses on alternative asset class investing and careers. The organization is structured as a multi-program investment fund covering 4 main themes: private equity, special situations, real assets, and global macro investing. Members of the club have the opportunity to gain exposure and develop deep expertise in their respective sectors through a three-part program consisting of research projects, educational training, and industry-related forums.	https://redpointcapital.ca/	redpointcapital.mus@mail.mcgill.ca	\N	https://www.facebook.com/RedPointCapital	https://www.instagram.com/redpointcapital	2025-01-05 17:43:15.466+00	2025-01-05 17:43:15.466+00	t	\N	\N	\N	\N	\N	\N
79	assa-african-studies-students-association	ASSA – African Studies Students’ Association	The African Studies Students' Association represents all students enrolled in the African Studies Joint Honours, Major and Minor programs at McGill!	\N	assa.mcgill@gmail.com	\N	https://www.facebook.com/assamcgill	https://www.instagram.com/assa.mcgill	2025-01-05 17:43:16.156+00	2025-01-05 17:43:16.156+00	t	\N	\N	\N	\N	\N	\N
82	clashsa-caribbean-latin-american-and-hispanic-studies-students-association	CLASHSA – Caribbean, Latin American, and Hispanic Studies Students’ Association	Student Association for Hispanic Studies and Latin American & Caribbean Studies at McGill University.	https://www.clashsa-mcgill.com/	clashsamcgill@gmail.com	\N	https://www.facebook.com/clashsamcgill	https://www.instagram.com/clashsa.mcgill	2025-01-05 17:43:18.03+00	2025-01-05 17:43:18.03+00	t	\N	\N	\N	\N	\N	\N
70	asia-business-association	Asia Business Association	The McGill Asia Business Association (ABA) is focused on promoting a better understanding of Asian business industries. 	\N	\N	\N		https://www.instagram.com/abamcgill/	2025-01-25 23:01:57.387+00	2025-01-05 17:43:11.032+00	t	\N	\N	\N	\N	\N	\N
71	mcgil-investment-club	McGill Investment Club	MIC is a comprehensive finance club, open to all students of McGill University in all faculties, with two main components: an Investment Management side and an Investment Banking side. The club plays a major role in bridging the gap between the classroom and the financial workplace, and supports the career preparation and development processes of McGill students. 	https://www.mcgillinvestmentclub.ca/	investmentclub@mail.mcgill.ca	\N	https://www.facebook.com/McgillInvestmentClub	https://www.instagram.com/mcgillinvestmentclub	2025-01-25 23:02:18.472+00	2025-01-05 17:43:11.713+00	t	\N	\N	\N	\N	\N	\N
72	jed-consulting	JED Consulting	Based out of McGill University, JED Consulting is Canada's premier student-run consulting firm. Each semester, the team of 30 student consultants tackles Gen Z-related business challenges of start-ups, nonprofits and Fortune 500 companies.	https://jed-consulting.com/	Juniorenterprise.desautels@gmail.com	\N	https://www.facebook.com/JEDmtl	https://www.instagram.com/jed.mcgill	2025-01-25 23:02:56.017+00	2025-01-05 17:43:12.205+00	t	\N	\N	\N	\N	\N	\N
73	mcgill-students-business-review	McGill Students Business Review	The McGill Students Business Review (MSBR) operates as both an online platform and a social hub for those with a passion for business affairs. The MSBR provides all undergraduates with the opportunity and resources to explore and learn about the business world. 	https://mcgillbusinessreview.com/	mcgillsbr@gmail.com	\N	https://www.facebook.com/McGillBR	https://www.instagram.com/mcgillbusinessreview	2025-01-25 23:03:17.238+00	2025-01-05 17:43:12.619+00	t	\N	\N	\N	\N	\N	\N
74	mcgill-consulting-association	McGill Consulting Association	The McGill Consulting Association (MCA) aims to help undergraduate students understand, prepare for, and develop careers in the consulting and related fields. By creating and fostering deep relationships with consulting firms and organizations, they hope to expose students to the nature and scope of consulting practices, as well as provide them with the appropriate opportunities and tools to succeed as a consultant.	https://www.mcgillconsultingassociation.com/	mca@mus.mcgill.ca	\N	https://www.facebook.com/McGillConsultingAssociation	https://www.instagram.com/mcgillconsultingassociation	2025-01-25 23:03:47.383+00	2025-01-05 17:43:13.062+00	t	\N	\N	\N	\N	\N	\N
76	desautels-sustainability-network	Desautels Sustainability Network	The Sustainability Network is a club for management students interested in pursuing careers in environmentally friendly businesses. The club aims to bring students together by hosting both professional and interactive events.	https://www.mcgilldsn.com/	ford@mcgilldsn.ca	\N	https://www.facebook.com/DesautelsSustainabilityNetwork	https://www.instagram.com/mcgilldsn	2025-01-25 23:06:03.54+00	2025-01-05 17:43:14.141+00	t	\N	\N	\N	\N	\N	\N
77	real-estate-club	Real Estate Club	Real Estate Club at McGill's mission is to expose students to various opportunities in the real estate industry and provide them with knowledge to successfully a career in this sector.	https://www.realestateclubmcgill.com/	rec.mus@mail.mcgill.ca	\N	https://www.facebook.com/realestateclubmcgill	https://www.instagram.com/realestateclubmcgill	2025-01-25 23:06:40.719+00	2025-01-05 17:43:15.026+00	t	\N	\N	\N	\N	\N	\N
80	asa-anthropology-students-association	ASA – Anthropology Students’ Association	The ASA represents all undergrad major, minor, honours, and joint-honours anthropology students.	https://www.asamcgill.net/	anthropology.asa.mcgill@gmail.com	\N	https://www.facebook.com/AnthroMcGill	https://www.instagram.com/mcgillanthropology	2025-01-25 23:09:01.489+00	2025-01-05 17:43:16.805+00	t	\N	\N	\N	\N	\N	\N
81	arts-and-science-undergraduate-society	Arts and Science Undergraduate Society	The Arts & Science Undergraduate Society of McGill University is a student organization that represents the students enrolled in the Faculty of Arts & Science.	https://www.mcgillbasic.com/	communications@mcgillasus.com	\N	https://www.facebook.com/mcgillasus	https://www.instagram.com/mcgillasus	2025-01-25 23:10:16.077+00	2025-01-05 17:43:17.423+00	t	\N	\N	\N	\N	\N	\N
87	pssa-political-science-students-association	PSSA – Political Science Students’ Association	The Political Science Students' Association (PSSA) represents the students enrolled in the program.	https://mcgillpssa.ca/	president@mcgillpssa.com	\N	https://www.facebook.com/McGill.PSSA	https://www.instagram.com/mcgillpssa	2025-01-05 17:43:21.645+00	2025-01-05 17:43:21.645+00	t	\N	\N	\N	\N	\N	\N
91	mcgill-muggle-quidditch-club	McGill Muggle Quidditch Club	McGill Quidditch is Canada’s first and most prestigious quidditch club. McQuid provides a fun, competitive, and inclusive environment for everyone who wants to play! Boasting first place at last year’s divisional championships, McGill is a front-runner on the Canadian quidditch scene. As a team, we travel across Canada and even to the US for tournaments against other universities and regional teams. McQuid provides a large network of diverse McGill students, with members in almost every faculty. By being on the team, you not only get to play a cool sport, but you also have an instant circle of close and caring friends and teammates who will stay with you for life. Find us practicing on Lower Field or on the McTavish Reservoir!	https://quidditch.ssmu.ca/	quidditch@ssmu.ca	\N	https://www.facebook.com/McGillQuidditch	https://www.instagram.com/mcgill_quidditch	2025-01-05 17:43:23.459+00	2025-01-05 17:43:23.459+00	t	\N	\N	\N	\N	\N	\N
85	lingua	LINGUA - McGill Linguistics Undergraduate Association	The association for McGill linguistics undergraduates (previously known as SLUM). 	\N	slum.linguistics@mail.mcgill.ca	\N	https://facebook.com/mcgillSLUM	https://www.instagram.com/linguamcgill/	2025-01-25 23:15:12.832+00	2025-01-05 17:43:20.659+00	t	\N	\N	\N	\N	\N	\N
86	wimessa---world-islamic-middle-east-studies-students-association	WIMESSA - World Islamic Middle East Studies Students’ Association	The World Islamic and Middle East Studies Students' Association at McGill University. 	\N	mcgillmessa@gmail.com	\N	https://www.facebook.com/WIMESSAMcGill?mibextid=LQQJ4d	https://www.instagram.com/wimessamcgill/	2025-01-25 23:16:09.927+00	2025-01-05 17:43:21.056+00	t	\N	\N	\N	\N	\N	\N
88	rsus-religious-studies-undergraduate-society	RSUS – Religious Studies Undergraduate Society	McGill's Religious Studies Undergraduate Society provides opportunities and resources for McGill students enrolled in Religious Studies as a major or a minor.	\N	rsusmcgill@gmail.com	\N	https://www.facebook.com/mcgillrsus	https://www.instagram.com/mcgill_rsus	2025-01-25 23:19:13.859+00	2025-01-05 17:43:22.057+00	t	\N	\N	\N	\N	\N	\N
89	ssa-sociology-students-association	SSA – Sociology Students’ Association	For all McGill undergraduate students studying sociology or just taking a sociology course for fun.	http://www.mcgillsociology.ca/	sociology.mcgill@gmail.com	\N	https://www.facebook.com/SSAMcGill	https://www.instagram.com/sociology.mcgill	2025-01-25 23:19:34.074+00	2025-01-05 17:43:22.646+00	t	\N	\N	\N	\N	\N	\N
90	gsdfssa---gender-sexual-diversity-and-feminist-studies-students-association	GSDFSSA - Gender, Sexual Diversity, and Feminist Studies Students’ Association	Student Association of the Gender, Sexuality, Feminist, and Social Justice Program at McGill.	https://gsfssamcgill.weebly.com/	gsdfssa.mcgill@gmail.com	\N	https://www.facebook.com/McGillGSFSSA	https://www.instagram.com/gsfssamcgill?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==	2025-01-25 23:20:32.695+00	2025-01-05 17:43:23.051+00	t	\N	\N	\N	\N	\N	\N
93	mcgill-tennis-club	McGill Tennis Club	The McGill Tennis Club is a recreational tennis club that serves players of all levels. The club organizes practices, tournaments, and leagues throughout the year.	https://mcgillathletics.ca/sports/2012/11/7/1107121039.aspx	tennis@ssmu.ca	\N	https://www.facebook.com/mcgilltennisclub	https://www.instagram.com/mcgilltennisclub	2025-01-25 23:22:57.408+00	2025-01-05 17:43:24.351+00	t	\N	\N	\N	\N	\N	\N
94	mcgill-ultimate-club	McGill Ultimate Club	The McGill Ultimate Club consists of four ultimate teams affiliated with McGill University: Men’s A and B, and Women’s A and B. Their A teams are competitive and consistently place top 5 at the Canadian University Ultimate Championships. The B teams are more developmental and are composed of players with less experience or those who would prefer a less competitive atmosphere. All members become part of a tight-knit community that hosts several events throughout the year, including an end-of-season banquet that recognizes the hard work and achievement of our members.	https://www.mcgillultimate.com/	mcgillultimate@ssmu.ca	\N	https://www.facebook.com/mcgillultimateteam	https://www.instagram.com/mcgillultimate	2025-01-25 23:23:18.977+00	2025-01-05 17:43:24.735+00	t	\N	\N	\N	\N	\N	\N
95	wusc	Local Committee for the World University Services of Canada (WUSC) at McGill University	World University Service of Canada (WUSC) is a non-profit international development organization that works to improve education, employment, and empowerment opportunities for youth around the world. Since 1986, McGill and the student-led Local Committee have welcomed more than 59 former refugees through WUSC with 15 scholars still present. 	https://mcgill.ca/studentaid/special-funding/wusc-student-refugee-program	wusc.mcgill@ssmu.ca	\N	https://www.facebook.com/wuscmcgill	https://www.instagram.com/wuscmcgill	2025-01-25 23:24:27.646+00	2025-01-05 17:43:25.447+00	t	\N	\N	\N	\N	\N	\N
96	mcgill-students-for-wildlife-conservation	McGill Students for Wildlife Conservation (MSWC)	McGill Students for Wildlife Conservation aims to create events, fundraising, and volunteer opportunities that provide McGill students with hands-on experience in local conservation efforts. It places an emphasis on localized conservation techniques to secure the future of healthy ecosystems. This involves working hand-in-hand with human lives that shape natural environments to create a thriving community for all plants and animals within these ecosystems. Canada has a unique set of environmental issues in the face of the unprecedented climate crisis; including arctic warming, marine and freshwater pollution, and threats to biodiversity. Our club has the opportunity to mobilize students to engage with our local urban ecology that serves our downtown campus. With this, McGill Students for Wildlife Conservation has a mandate to protect and conserve habitats and populations of the world’s vulnerable species, placing an emphasis on rectifying threats to our local environment.	\N	wildlifeconservation@ssmu.ca	\N	https://www.facebook.com/mcgillwildlifeconservation	https://www.instagram.com/mswcmcgill/	2025-01-25 23:25:40.174+00	2025-01-05 17:43:26.044+00	t	\N	\N	\N	\N	\N	\N
99	parks-canada-campus-club	Parks Canada Campus Club	Are you yearning explore National Parks inside and out of Montreal? Do you want to learn more about the history of Quebec and Canada? Are you passionate about wildlife conservation? Do you want to meet people who also love the outdoors? McGill Parks Canada Campus Club is a student-lead group that explores the National Parks and National Historic Sites the greater Quebec region has to offer! Our trips, events, and meetings focus on exploring outdoor and public spaces, conservation, and cultural excursions. We typically host weekend camping trips outside of Montreal each semester, as well as shorter day trips and meetings throughout the semester. If you have any questions or want to get involved, email us at mcgillcampusclub@gmail.com. We’d love to have you join us!	\N	mcgillparksclub@ssmu.ca	\N	https://www.facebook.com/Mcgillparkscanadacampusclub	\N	2025-01-05 17:43:27.355+00	2025-01-05 17:43:27.355+00	f	\N	\N	\N	\N	\N	\N
101	change-for-change-ssmu	Change for Change SSMU	Ever heard the expression “small change leads to a big difference?” Join us today and prepare to see these words in action. Change for Change is an international network of young adults who are improving communities one set of small change at a time. Through our Chapter at McGill, college students and young professionals are raising funds for community charities through the collection of loose change and larger donations.	\N	changeforchangemcgill@gmail.com	\N	https://www.facebook.com/CFCMcGill	\N	2025-01-05 17:43:28.243+00	2025-01-05 17:43:28.243+00	f	\N	\N	\N	\N	\N	\N
102	hack4impact	Hack4Impact	Hack4Impact McGill is a university initiative pairing students with non-profit organizations to design and develop socially impactful projects while gaining meaningful hands on experience.	https://mcgill.hack4impact.org/	hack4impact@ssmu.ca	\N	https://www.facebook.com/hack4impactmcgill	https://www.instagram.com/hack4impact	2025-01-05 17:43:28.875+00	2025-01-05 17:43:28.875+00	t	\N	\N	\N	\N	\N	\N
105	mcgill-students-for-best-buddies	McGill Students for Best Buddies	McGill Students for Best Buddies pairs McGill students with adults in the Montreal community with intellectual and/or developmental disabilities. Students develop 1-1 friendships with their buddies and also participate in monthly group events with other buddy pairings. Best Buddies fosters healthy and supportive friendships, and promotes inclusivity, community involvement and social awareness!	\N	bestbuddies@ssmu.ca	\N	https://www.facebook.com/mcgill.bestbuddies	https://www.instagram.com/bestbuddiesmcgill	2025-01-05 17:43:30.562+00	2025-01-05 17:43:30.562+00	t	\N	\N	\N	\N	\N	\N
98	mealcare	MealCare McGill	MealCare McGill is one of 7 of MealCare’s operating chapters across Canada. At McGill, MealCare involves the Executive Team as well as food donors, volunteers, and recipients. Beyond the Executive Team, MealCare includes cafeteria chefs, café employees, Drivesafe and student volunteers that work towards fulfilling our mission.	https://mealcare.org/	mealcare@ssmu.ca	\N	https://www.facebook.com/mealcaremcgill	https://www.instagram.com/mealcare_mcgill	2025-01-25 23:30:45.49+00	2025-01-05 17:43:26.919+00	t	\N	\N	\N	\N	\N	\N
100	cagh	Canadian Coalition for Global Health Research (CAGH) McGill Students Chapter	The Canadian Association for Global Health (CAGH) is a not-for-profit network of people committed to promoting better and more equitable health worldwide through the production and use of knowledge. As a student chapter, they aim to support and encourage the next generation of global health professionals at McGill University through the creation of a student network in which current topics and opportunities in ethical and sustainable global health research can be shared.	https://caghmcgill.wixsite.com/home	cagh@ssmu.ca	\N	https://www.facebook.com/CAGHMcGill	https://www.instagram.com/caghmcgill	2025-01-25 23:31:28.379+00	2025-01-05 17:43:27.796+00	t	\N	\N	\N	\N	\N	\N
103	mcgill-childrens-health-alliance-of-montreal	McGill Children’s Health Alliance of Montreal	The McGill Children's Health Alliance of Montreal is a dedicated student organization committed to raising funds for the Montreal Children’s Hospital and spreading awareness through volunteer opportunities in the Montreal health community. 		mcham@ssmu.ca	\N		https://www.instagram.com/mchamcgill	2025-01-25 23:33:13.353+00	2025-01-05 17:43:29.63+00	t	\N	\N	\N	\N	\N	\N
104	mcgill-students-chapter-of-jam-for-justice	McGill Students Chapter of Jam for Justice	Jam for Justice is a non-profit organization that supports social development and well-being through music. Their goal is to engage the McGill community by highlighting musical talent, and using music as a positive and powerful way to bring people together, while helping and fundraising for the community.	\N	jamforjustice@ssmu.ca	\N	https://www.facebook.com/jamforjusticemcgill	https://www.instagram.com/jam_for_justice	2025-01-25 23:34:21.81+00	2025-01-05 17:43:30.099+00	t	\N	\N	\N	\N	\N	\N
106	mcgill-students-for-santropol-roulant	McGill Students for Santropol Roulant	McGill Students for Santropol acts as an on-campus volunteer network that introduces students to the Santropol Roulant community and the volunteer opportunities offered within their Meals-on-Wheels program to prepare and deliver meals to people living with a loss of autonomy. Through McGill Students for Santropol, students can come together and engage in student events, fundraisers, and regular volunteer shifts all under the shared values of community, sustainability, and food security.	\N	studentsforsantropol@gmail.com	\N	https://www.facebook.com/mcgillstudentsforsantropol		2025-01-25 23:36:15.925+00	2025-01-05 17:43:31.185+00	f	\N	\N	\N	\N	\N	\N
117	chinese-brush-arts-club	Chinese Brush Arts Club	McGill Students Chinese Brush Arts Club (MSCBAC) is a student organization at McGill University, aiming to introduce Chinese painting and calligraphy cultures on campus, provide guidance and training in the practice of Chinese fine arts, and build up multicultural, communicative network for brush art lovers through various events.		mschinesebrushartsclub@gmail.com	\N	https://www.facebook.com/mscbac	https://www.instagram.com/mscbac	2025-01-25 23:48:45.544+00	2025-01-05 17:43:40.232+00	t	\N	\N	\N	\N	\N	\N
107	mcgill-students-for-the-open-door-montreal	McGill Students for The Open Door Montreal	McGill Students for The Open Door Montréal (MSTODM) acts as a liaison between McGill students and The Open Door Montréal shelter. The Open Door is a non-profit organization located minutes from campus which provides shelter, food, and amenities for those who are under-housed in Montreal. The organization relies heavily on volunteer support to operate. Through MTSODM, students have the opportunity to volunteer at The Open Door in a variety of roles: in the kitchen preparing and serving meals, in the cloakroom sorting clothing donations, or receiving visitors to the shelter at the front desk. MTSODM provides extensive training and support to all student volunteers at The Open Door. The community at The Open Door benefits greatly from student volunteers, and students in turn will have the opportunity to be involved in their local community.	https://mstodm.ssmu.ca/	mstodm@ssmu.ca	\N	https://www.facebook.com/McGillStudentsfortheOpenDoorMontreal	https://www.instagram.com/mstodm_mcgill	2025-01-05 17:43:31.645+00	2025-01-05 17:43:31.645+00	f	\N	\N	\N	\N	\N	\N
110	mhcpp	Montreal Heart of the City Piano Program (MHCPP)	The Montreal Heart of the City Piano Program (MHCPP) is a chapter of the national organization, founded in Saskatchewan in 1995. Since November 2007, the MHCPP has offered tuition-free piano lessons to at-risk children at English and French inner-city elementary schools in Montreal. Led by a team of dedicated volunteers through the Student Society of McGill University, the Montreal chapter has grown to include a total of four schools.	https://montrealheartofthecity.com/	montrealhcpp@ssmu.ca	\N	https://www.facebook.com/montrealheartofthecity	https://www.instagram.com/montrealheartofthecity	2025-01-05 17:43:37.192+00	2025-01-05 17:43:37.192+00	f	\N	\N	\N	\N	\N	\N
111	peace-by-peace-montreal	Peace by P.E.A.C.E. Montreal	Peace by P.E.A.C.E. is a McGill student-run organization that facilitates workshops on issues such as conflict resolution, inter-racial harmony, and inner power in elementary school classrooms around Montreal. Students are introduced to cooperative problem-solving skills through games, role-play, art projects, and discussions.	https://peacebypeacemontreal.weebly.com/	peacebypeace@ssmu.ca	\N	https://www.facebook.com/peacebypeacemcgill	https://www.instagram.com/peacebypeacemcgill	2025-01-05 17:43:37.679+00	2025-01-05 17:43:37.679+00	t	\N	\N	\N	\N	\N	\N
114	swam	Swimming With A Mission (SWAM) Montreal	Swimming With A Mission (SWAM) Montreal is a non-profit organization that provides affordable and accessible one-on-one swimming instruction to children with disabilities.	http://www.montreal.qc.swamcanada.ca/	montrealswamcanada@ssmu.ca	\N	https://www.facebook.com/SWAMMontreal	https://www.instagram.com/swammontreal	2025-01-05 17:43:38.961+00	2025-01-05 17:43:38.961+00	t	\N	\N	\N	\N	\N	\N
109	medlife-mcgill	MEDLIFE McGill	MEDLIFE is a non-profit student organization that was established with a view towards alleviating global poverty through the distribution and promotion of Medicine, Education, and Development. The McGill chapter was founded in 2010, giving Canadian students the opportunity to participate. They currently operate in Ecuador and Peru and hope to expand our reach in the near future. 	https://medlifemcgill.com/	medlife.mcgill@ssmu.ca	\N	https://www.facebook.com/MedlifeMcGill	https://www.instagram.com/medlifemcgill	2025-01-25 23:43:55.821+00	2025-01-05 17:43:36.453+00	t	\N	\N	\N	\N	\N	\N
112	projet-montral-mcgill-students-association	Projet Montréal McGill Students Association	Projet Montréal McGill Students Association seeks to promote and build upon, with the McGill student body, the mission of Projet Montréal as enumerated in section 2 of its statutes: “Projet Montréal offers Montrealers a way of life in the city on a human scale, respectful of its diversity and the identity and richness of each of its boroughs and each and every one of its residents. To do this, it puts forward an innovative urban, social and economic vision, on the lookout for good practices, centred on sustainable development, democracy, solidarity, equity, social justice, sound management and transparency. The Party aims for a better quality of life for all”.	http://en.projetmontreal.org/	projetmontrealmcgill@ssmu.ca	\N	https://www.facebook.com/ProjetMontrealJeunes	https://www.instagram.com/projetmontreal	2025-01-25 23:45:34.51+00	2025-01-05 17:43:38.079+00	f	\N	\N	\N	\N	\N	\N
113	rotaract-students-club	Rotaract Students’ Club	The Rotaract Students' Club is a youth division of Rotary International looking to help the local and international community through various projects.	http://rotaractdtmtl.weebly.com/	rotaractdtmtl@gmail.com	\N	https://www.facebook.com/Rotaractdtmtl	\N	2025-01-25 23:46:17.433+00	2025-01-05 17:43:38.542+00	t	\N	\N	\N	\N	\N	\N
115	youth-outreach-program	Youth Outreach Program	The Youth Outreach Program (YOP)’s goal is to reach out to youth at risk and develop positive relationships while emphasizing soft literacy skills such as creativity, communication, and self-expression. As a member, you will get to plan activities for your group, develop personal relationships with the youth and the other volunteers, and most of all, be a MENTOR. 	\N	youthoutreachprogram@ssmu.ca	\N	https://www.facebook.com/youthoutreachprogram	https://www.instagram.com/youthoutreachprogrammcgill	2025-01-25 23:47:16.132+00	2025-01-05 17:43:39.363+00	t	\N	\N	\N	\N	\N	\N
116	alegria-contemporary-ballet-company	Alegria Contemporary Ballet Company	Alegria is McGill’s first and only contemporary ballet company, founded on the goal of incorporating ballet technique into innovative contemporary dance. In addition to performing showcases throughout the year, Alegria offers drop-in classes in various styles of dance once a month as well as tickets to Les Grands Ballets Canadiens performances at a 40% discount. Our aim is to bring ballet culture to campus!		alegriacontemporaryballet@gmail.com	\N	https://www.facebook.com/alegriacontemporaryballet	https://www.instagram.com/alegriacontemporaryballet	2025-01-25 23:47:58.119+00	2025-01-05 17:43:39.8+00	t	\N	\N	\N	\N	\N	\N
123	franc-jeu	Franc-Jeu	We are a French theatre club that organizes weekly improv workshops and a play at the end of each semester. Join us to improve your improvisation and acting skills and to meet people with the same passion as yours! You don’t need to have acted before to come to our workshops, everyone is invited!	\N	francjeu@ssmu.ca	\N	https://www.facebook.com/francjeutheatre	https://www.instagram.com/francjeu	2025-01-05 17:43:43.095+00	2025-01-05 17:43:43.095+00	f	\N	\N	\N	\N	\N	\N
128	mcgill-students-comedy-club	McGill Students Comedy Club	The McGill Students Comedy club is the place for McGill comics or aspiring comedians or people who just love comedy to meet up, work together on projects, bounce ideas off one another, and organize/perform stand-up comedy shows. If you like comedy you found the right place.	\N	mcgillstudentscomedy@gmail.com	\N	https://www.facebook.com/mcgillcomedy	https://www.instagram.com/mcgillcomedy	2025-01-05 17:43:45.823+00	2025-01-05 17:43:45.823+00	t	\N	\N	\N	\N	\N	\N
277	mcgill-biomedical-engineering-club	McGill Biomedical Engineering Club	McGill Biomedical Engineering Club is a student run society with the objective of fostering and expanding interests in the Biomedical Engineering field among McGill student	https://eus.wiki/McGill_Biomedical_Engineering_Club	mbec.president@mcgilleus.ca	\N	https://www.facebook.com/MBEC.McGill	\N	2025-01-05 17:45:04.855+00	2025-01-05 17:45:04.855+00	f	\N	\N	\N	\N	\N	\N
119	circle-of-fashion	Circle of Fashion	Circle of Fashion is a club where students can express their fashion creativity	https://circleoffashion.ssmu.ca/	\N	\N	\N	https://www.instagram.com/circleoffashionmcgill	2025-01-25 23:51:48.531+00	2025-01-05 17:43:41.125+00	t	\N	\N	\N	\N	\N	\N
120	dance-pack	Dance Pack	Dance Pack is a collective of McGill students who share a passion in dance with a focus on hip hop. As a tight-knit team of 10-20 members, Dance Pack values fun and enthusiasm and encourage inclusivity and creativity on the dance floor. Performances include athletic events, faculty events, and more.	\N	dancepak@ssmu.ca	\N	https://www.facebook.com/mcgilldancepack		2025-01-25 23:52:08.453+00	2025-01-05 17:43:41.559+00	f	\N	\N	\N	\N	\N	\N
121	dsign-lab	Dsign Lab	Dsign Lab aims to spark discussions around the fashion industry and its future through its blog with an emphasis on sustainability and ethics. 	https://dsignlabmcgill.wixsite.com/monsite	dsignlab@ssmu.ca	\N	https://www.facebook.com/McGillDsignLab	https://www.instagram.com/dsignlabmcgill	2025-01-25 23:52:49.107+00	2025-01-05 17:43:41.971+00	t	\N	\N	\N	\N	\N	\N
122	effusion-a-cappella	Effusion a Cappella	Effusion a Capella is McGill’s premier a cappella ensemble. Effusion performs at events, soirees, dinners, festivals, and student functions in and around Montreal, QC. The group has also competed in many renowned competitions. They draw influence from across the musical spectrum, including R&B, soul, gospel, pop, folk, rock, and jazz.	http://www.effusion.ca/	info.effusion@gmail.com	\N	https://www.facebook.com/effusionacappella	https://www.instagram.com/effusionacappella	2025-01-25 23:53:53.676+00	2025-01-05 17:43:42.435+00	t	\N	\N	\N	\N	\N	\N
124	inertia-modern-dance-collective	Inertia Modern Dance Collective	Participating in rehearsals and workshops, members of Inertia seek to contribute to the expansion of this medium through experimentation with movement and choreographic development. They believe that the creative process is just as important as the final product.	\N	inertiadance.mcgill@gmail.com	\N	https://www.facebook.com/inertiamoderndancecollective	https://www.instagram.com/inertiagram	2025-01-25 23:54:56.799+00	2025-01-05 17:43:43.481+00	t	\N	\N	\N	\N	\N	\N
125	k-rave	K-RAVE	K-Rave is a club that aims to engage members in K-pop and Korean entertainment culture through events, performances, and more! The club consists of two sides: the performance team and regular K-Rave events.	https://k-rave.wixsite.com/krave	mcgillkrave@gmail.com	\N	https://www.facebook.com/kravemcgill	https://www.instagram.com/krave_mcgill	2025-01-25 23:55:29.949+00	2025-01-05 17:43:43.949+00	t	\N	\N	\N	\N	\N	\N
126	mcgill-arts-collective	McGill Arts Collective	The McGill Arts Collective is McGill’s first multimedia arts club.​ They are dedicated to forming a diverse community of artists of all skill levels and all disciplines—visual, written, and performance. The MAC is committed to filling the artistic gap on campus and providing opportunities for students to explore new arts, meet new people, and connect with the Montreal arts scene. 	https://mcgillartscollecti.wixsite.com/mcgill	mcgillartscollective@gmail.com	\N	https://www.facebook.com/mcgillartscollective	https://www.instagram.com/mcgill.arts.collective	2025-01-25 23:55:56.57+00	2025-01-05 17:43:44.589+00	t	\N	\N	\N	\N	\N	\N
127	mcgill-dj-society	McGill DJ Society	The McGill DJ Society was established to promote musical talent on campus. Through our network and events, we hope to create an interconnected community that shares their passion for Djing and music production. We welcome people of all experience levels with interests in all kinds of music! If you want to learn about how to DJ or connect with like-minded individuals, then the McGill DJ Society is the place for you!	\N	mdjs@ssmu.ca	\N	\N	https://www.instagram.com/mcgilldjsociety	2025-01-25 23:56:20.476+00	2025-01-05 17:43:45.23+00	f	\N	\N	\N	\N	\N	\N
129	mcgill-students-chinese-music-society	McGill Students’ Chinese Music Society	McGill Students Chinese Music Society (MSCMS) was formed in 2013 by McGill students with a vivid passion for traditional Chinese music culture with the goal of promoting various styles of traditional Chinese music and the exchange of occidental and oriental music within the McGill community.	https://mcgillchinesemusic.wixsite.com/mscms	mscms@ssmu.ca	\N	https://www.facebook.com/mcgillstudentschinesemusicsociety	https://www.instagram.com/mcgillchinesemusic2	2025-01-05 17:43:46.211+00	2025-01-05 17:43:46.211+00	f	\N	\N	\N	\N	\N	\N
132	mcgill-students-visual-arts-society	McGill Students’ Visual Arts Society	Whether you’re a beginner doodler or an expert artist, the McGill Students’ Visual Arts Society welcomes you! Events are hosted weekly and include live model drawing, tutorials, Open Sketch, watercolour and acrylic sessions, and the occasional field trip! An annual conference is held near the end of the Fall semester and our Year-End Art Show is held near the end of the Winter semester, where all members can submit and display their artwork. Art supplies and materials are provided by the club during in-person events.	https://mcgillvisualarts.wixsite.com/msvas	mcgillvisualarts@gmail.com	\N	https://www.facebook.com/mcgillstudentsvisualartssociety	https://www.instagram.com/mcgillvisualarts	2025-01-05 17:43:47.604+00	2025-01-05 17:43:47.604+00	t	\N	\N	\N	\N	\N	\N
137	players-theatre	Players’ Theatre	Players’ Theatre is committed to giving students the opportunity to create theatre. Under the guidance of our executive, students have the chance to put on a show in a variety of roles, including but not limited to: directing, stage management, performing, set design, costume design, lighting design, props design and more! They put on already published plays, as well as host the annual McGill Drama Festival, which produces six student-written plays.	https://www.playerstheatre.ca/	players@ssmu.ca	\N	https://www.facebook.com/PlayersTheatreMcGill	https://www.instagram.com/playerstheatremcgill	2025-02-18 06:48:36.546+00	2025-01-05 17:43:49.794+00	t	\N	\N	\N	\N	\N	\N
136	mosaica-dance-company	Mosaica Dance Company	Mosaica is one of the oldest dance companies at McGill! They are an egalitarian dance company, and welcome dancers with training in a variety of backgrounds. All company members have the opportunity to choreograph and perform in dances in our year-end showcase, as well as other performances throughout the school year!	\N	mosaicadance@ssmu.ca	\N	https://www.facebook.com/mosaicadancecompany	https://www.instagram.com/mosaicadancecompany	2025-02-18 06:48:54.196+00	2025-01-05 17:43:49.405+00	t	\N	\N	\N	\N	\N	\N
135	montreal-di-majesty	Montreal Di Majesty	Celebrating the culture of Punjab on McGill Campus, Montreal Di Majesty is McGill’s first and only competitive Bhangra dance team! They hold workshops, performances at events within the Montreal community and attend North American competitions.	\N	montrealdimajesty@gmail.com	\N	https://www.facebook.com/montrealdimajesty	\N	2025-02-18 06:49:10.976+00	2025-01-05 17:43:48.997+00	f	\N	\N	\N	\N	\N	\N
134	mupss	McGill University Photography Students’ Society (MUPSS)	The McGill University Photography Students Society (MUPSS), founded in 1978, is one of McGill’s oldest clubs. Today, the club offers a variety of services, events, and resources for McGill students and the greater Montréal photographic community. Every semester, the club hosts various events including: photo discussions, introductory workshops, and more. MUPSS also holds an annual photo exhibition to display the photography of members of the McGill community. An up to date schedule of these events can be found on the club Facebook, as well as by subscribing to their newsletter.	http://www.mupss.ca/	mupss.mcgill@gmail.com	\N	https://www.facebook.com/MUPSSMcGill	https://www.instagram.com/mupssmcgill	2025-02-18 06:49:33.646+00	2025-01-05 17:43:48.55+00	t	\N	\N	\N	\N	\N	\N
133	msk	McGill Swing Kids (MSK)	McGill Swing Kids (MSK) is a student-organized club that works to provide affordable swing-style dance lessons (such as Lindy Hop, Charleston, Jazz, Balboa – and everything in between!). Although the majority of our members are students, they welcome dancers of all ages and skill levels. They aim to share our passion for Swing by providing a fun, friendly, and lively approach to swing dancing. They also aim to provide a launchpad to the greater swing community in Montreal. Let them teach you all you need to swing like a jitterbug, join them for outings at the most swinging venues in town, and ask them for tips or school recommendations: that’s what we’re here for!	\N	msk.montreal@gmail.com	\N	https://www.facebook.com/mcgillswingkids	\N	2025-02-18 06:50:17.569+00	2025-01-05 17:43:48.051+00	t	\N	\N	\N	\N	\N	\N
131	mcgill-students-improv	McGill Students’ Improv	Social anxiety, lack of comedic ability, having too much sex, these are just a few of the things that McGill Improv can remedy for you. Come join McGill Improv with free workshops for any experience level and bi-weekly shows to get involved in the McGill comedy scene. They host workshops every Tuesday from 6-8pm in the SSMU ballroom and have shows on the 1st and 3rd Wednesday of every month in the McConnell Engineering Building basement at 8pm! They hope to see you there to learn how to act, love, laugh, and cry.	\N	mcgillimprov@gmail.com	\N	https://www.facebook.com/mcgillimprov	https://www.instagram.com/mcgillimprov	2025-02-18 06:51:13.628+00	2025-01-05 17:43:47.143+00	t	\N	\N	\N	\N	\N	\N
130	cmc	McGill Students’ Classical Music Club (CMC)	As the name implies, the Classical Music Club (CMC) brings together people who share a love for classical music! Whether you’re a lifelong musician or someone who just enjoys listening, their club has something for everyone. Some of their initiatives include providing affordable tickets for exciting concerts and grouping people to play chamber music together. Don’t hesitate to reach out to them, and they look forward to meeting you!	https://sites.google.com/site/mcgillcmc	mcgillcmc@gmail.com	\N	https://www.facebook.com/mcgillcmc	https://www.instagram.com/mcgillcmc	2025-02-18 06:51:44.383+00	2025-01-05 17:43:46.699+00	t	\N	\N	\N	\N	\N	\N
141	soulstice-a-cappella	Soulstice a Cappella	McGill’s finest a Cappella group. Performing a wide range of music from Top 40 hits to classic Jazz standards, Soulstice is a talented and welcoming group of singers that seeks to improve the McGill and Montreal communities by sharing their love of singing for all to hear!	https://soulsticeacappella23.wixsite.com/website	soulsticeacapella@ssmu.ca	\N	https://www.facebook.com/soulsticeacappella	https://www.instagram.com/soulsticeacappella	2025-01-05 17:43:51.625+00	2025-01-05 17:43:51.625+00	t	\N	\N	\N	\N	\N	\N
145	tonal-ecstasy-a-cappella	Tonal Ecstasy A Cappella	Tonal Ecstasy A Cappella is a fixture of the McGill and Montreal music scene. Founded in 1998 by a group of friends who loved to sing, TX has evolved and grown over the past two decades, and now performs not only at their biannual concerts, but also at various professional and personal events around Montreal. Composed of students in almost every faculty at McGill, Tonal Ecstasy’s members are incredibly talented when they perform individually, however, when they come together to perform as a group, their bond and collective love of music shines through their music. More than just being a joy to listen to, a TX performance is vibrant and energetic, and as much fun to watch. Although TX’s alumni are scattered around the world, they remain committed to and involved with the group. Whether they are creating arrangements for TX to perform, or travelling across the country for TX’s 20th anniversary (where over 40 alumni were present!), the alumni play a major role in helping TX be McGill’s greatest a cappella group.	https://www.tonalecstasy.com/	tonalecstasy@ssmu.ca	\N	https://www.facebook.com/txacappella	https://www.instagram.com/tonalecstasy	2025-01-05 17:43:53.447+00	2025-01-05 17:43:53.447+00	t	\N	\N	\N	\N	\N	\N
146	formerly-urban-groove	United Groove (formerly Urban Groove)	Formed in 2003 at McGill University, United Groove (UG) brings together students who share a love and passion for dance. Today, UG consists of dancers from many different backgrounds, mastering styles from hip-hop to contemporary to street-jazz, all while fostering a strong sense of artistry, family, and dedication. UG has come to establish a reputation that goes beyond McGill and into the greater Montreal community, performing at athletic events, competitions, fundraisers, and parties.	http://www.ugroove.ca/	urbangroove@ssmu.ca	\N	https://www.facebook.com/United-Groove-43950288647	https://www.instagram.com/united.groove	2025-01-05 17:43:53.919+00	2025-01-05 17:43:53.919+00	t	\N	\N	\N	\N	\N	\N
147	pcsn	McGill Pharmaceutical Career Student Network (PCSN)	The McGill Pharmaceutical Career Student Network (PCSN) is a student-run organization that facilitates interactions between key industry experts and McGill students seeking to explore and enter the pharmaceutical industry– a highly complex, competitive, and rewarding field. Through a variety of exciting and informative events, they aim to assist both undergraduate and graduate students in navigating their post-graduate career options. Ultimately, they hope that the new opportunities we create to network and connect with like-minded individuals and professionals will stimulate a strong desire to enter the pharmaceutical space whether it be in science or business. Whether you are a student interested in becoming a McGill PCSN member, or an industry professional excited by the opportunity to inspire students to pursue careers in industry at future events, do not hesitate to contact them!	https://pcsn-mcgill.com/	pcsn.mcgill@gmail.com	\N	https://www.facebook.com/pcsnmcgill	https://www.instagram.com/pcsn_mcgill	2025-02-18 06:44:31.414+00	2025-01-05 17:43:54.915+00	t	\N	\N	\N	\N	\N	\N
144	the-mcgill-savoy-society	The McGill Savoy Society	The McGill Savoy Society is a student theatre group specializing in the comic operas of Gilbert & Sullivan, the iconic Victorian dramatist-composer duo. Each winter they put on a spectacular show filled with fun songs, energetic dancing, and witty dialogue. They also produce a spring cabaret that showcases contemporary musical theatre pieces. They place a high priority on the “community” aspect of community theatre, welcoming all kinds of people and organizing great parties so that the cast, crew, and orchestra can truly come together at showtime.	https://mcgillsavoy.ca/	mcgillsavoy@ssmu.ca	\N	https://www.facebook.com/mcgillsavoy	https://www.instagram.com/mcgillsavoysociety	2025-02-18 06:45:30.707+00	2025-01-05 17:43:52.979+00	t	\N	\N	\N	\N	\N	\N
143	tashan-dance-company	Tashan Dance Company	The Tashan Dance Company is a Montreal-based South Asian Fusion dance company.	http://www.tashandancecompany.com/	tashandancecompany@ssmu.ca	\N	https://www.facebook.com/tashandancecompany	https://www.instagram.com/tashandancecompany	2025-02-18 06:45:47.657+00	2025-01-05 17:43:52.511+00	t	\N	\N	\N	\N	\N	\N
142	ssmu-symphonic-band-club	SSMU Symphonic Band Club	Symphonic Band is a concert band open to all McGill students who play traditional band instruments, no auditions required! They play medium difficulty band pieces and students are encouraged to set up their own small ensembles. Past repertoire has included everything from World of Warcraft to Wagner. They sharpen our pop culture knowledge with games during break time and have other non-music related activities throughout the year.	https://symphonicband.ssmu.ca/	symphonic.band.club@ssmu.ca	\N	https://www.facebook.com/symphonicclub	\N	2025-02-18 06:46:15.004+00	2025-01-05 17:43:52.067+00	f	\N	\N	\N	\N	\N	\N
153	the-meditation-club	The Meditation Club	The goal of The Meditation Club is to foster the practice of Meditation, and discuss the theory behind it.	\N	meditation@ssmu.ca	\N	https://www.facebook.com/themeditationclubmcgill	https://www.instagram.com/mcgillmeditation	2025-01-05 17:44:01.579+00	2025-01-05 17:44:01.579+00	t	\N	\N	\N	\N	\N	\N
155	mcgill-business-review	McGill Business Review	The McGill Business Review was founded in 2015 and is the first periodical at McGill University to be devoted solely to the publication of articles focusing on the global business community. The MBR, an online-only journal, serves as an outlet for McGill students to express their varied views and opinions on a range of business topics, including: economics, entrepreneurship, finance, technology, innovation, global politics, and government policy. Composed of a team of undergraduate student editors, writers and executives that each play an integral role individually in the production and publication process, the MBR is driven to produce excellent content and curate articles for a multifarious scholastic and professional audience.	https://mcgillbusinessreview.com/	mcgillbusinessreview@ssmu.ca	\N	https://www.facebook.com/McGillBR	https://www.instagram.com/mcgillbusinessreview	2025-01-05 17:44:02.991+00	2025-01-05 17:44:02.991+00	t	\N	\N	\N	\N	\N	\N
157	sign-language-club	Sign Language Club	McGill club dedicated to bringing D/deaf and Sign Language awareness, education and activities to the McGill community.	\N	signlanguageclub@ssmu.ca	\N	https://www.facebook.com/mcgillsignlanguage	https://www.instagram.com/mcgillsignlanguage_	2025-01-05 17:44:04.067+00	2025-01-05 17:44:04.067+00	t	\N	\N	\N	\N	\N	\N
159	lettuce-club	Lettuce Club	At Lettuce Club McGill, all members meet once a year and will have 10 minutes to eat an entire head of lettuce. Whoever eats the lettuce the fastest is dubbed the Head of Lettuce and organizes the meeting the following year.	\N	lettuceclub@ssmu.ca	\N	https://www.facebook.com/lettuceclubmcgill	\N	2025-01-05 17:44:05.055+00	2025-01-05 17:44:05.055+00	t	\N	\N	\N	\N	\N	\N
158	cocoa-cacao-ssmu	Cocoa & Cacao SSMU	Cocoa & Cacao is McGill’s one and only chocolate club‚ a group of chocolate lovers dedicated to bringing joy in the form of chocolate to our student body. They host chocolate-themed events throughout the academic year, such as our annual Cacao70 Factory Tour, our Homemade Truffle Sale for Valentine’s Day, and our Make-Your-Own Hot Chocolate Bar.	https://cocoaandcacao.wixsite.com/ssmu	cocoa.cacao@ssmu.ca	\N	https://www.facebook.com/cocoacacaomcgill	https://www.instagram.com/cocoacacaossmu	2025-02-18 06:38:56.72+00	2025-01-05 17:44:04.447+00	t	\N	\N	\N	\N	\N	\N
156	mcsway-poetry-collective	Mcsway Poetry Collective	Mcsway was founded with the mission to reintroduce spoken word poetry to the McGill community. They support artists of all levels and welcome everyone to our events, students and non-students alike. Their mission is to foster a safe(r), accessible, and inclusive space for writers and artists to build a creative community through the poetry writing, reading, and sharing/performance sessions we regularly host. They also run an online poetry journal, Snaps, on their website and accept submissions all year round!	https://www.mcswaypoetrycollective.com/	mcsway@ssmu.ca	\N	https://www.facebook.com/mcswaypoetry	https://www.instagram.com/mcswaypoetry	2025-02-18 06:39:45.957+00	2025-01-05 17:44:03.44+00	t	\N	\N	\N	\N	\N	\N
154	womens-health-advocacy-club	Women’s Health Advocacy Club	The Women’s Health Advocacy Club offers a unique opportunity to discuss and advocate for issues that fall in the intersection between gender and health. They aim to raise awareness, within the McGill community and beyond, about health issues affecting woman-identifying folk through discussion-based events and more. The Women’s Health Advocacy Club runs an annual speaker series as well as bi-monthly consciousness raising groups to discuss sub-topics of their theme: women’s sexual health. Additional fundraising events and other activities are organized in relation to the theme throughout the year.	\N	womenshealthadvocacyclub@ssmu.ca	\N	https://www.facebook.com/MWHAC	\N	2025-02-18 06:40:36.681+00	2025-01-05 17:44:02.015+00	f	\N	\N	\N	\N	\N	\N
152	femmedere	Student Nutrition Accessibility Club (Femmedere)	Femmedere is a SSMU club, focused on bringing food and nutrition to the McGill community in a sustainable way. Through three endeavours, their nutrition workshops, the Good Food Box, and their annual food conference, they aim to engage and encourage the McGill community to take part in sustainable food systems. They run a biweekly pickup for local produce that would have otherwise been thrown away in the University Centre. If you are interested in learning more, visit their website!	https://snacmcgill.wixsite.com/snac/about	snac.mcgill@gmail.com	\N	https://www.facebook.com/goodfoodboxmcgill	https://www.instagram.com/snac_mcgill	2025-02-18 06:41:27.515+00	2025-01-05 17:44:01.141+00	t	\N	\N	\N	\N	\N	\N
151	mcgill-students-supporting-the-heart-and-stroke-foundation	McGill Students Supporting the Heart and Stroke Foundation	We are a student organization that is dedicated in furthering the goals of the Heart and Stroke Foundation. Through collaboration with the foundation, they advocate healthy living, raise awareness for heart disease, and fundraise for research. Their hope is to educate and engage the McGill student community through events such as cooking workshops, physical activity, and seminars in order to make them more knowledgeable about the importance of a healthy heart. Furthermore, they strive to lead healthy lifestyles to be role models in their community. They aim to make the foundation’s vision come true: let people live healthy lives free of heart disease and stroke.	https://mcgillstudent.wixsite.com/mcgillhs	heartandstroke@ssmu.ca	\N	https://www.facebook.com/McGillHeartandStroke	\N	2025-02-18 06:42:29.93+00	2025-01-05 17:43:56.881+00	f	\N	\N	\N	\N	\N	\N
150	mssat	McGill Students for Science-based Addiction Treatment (MSSAT)	Addiction treatment is seriously outdated – even on campus! McGill Students for Science-based Addiction Treatment (MSSAT) is a student-led initiative dedicated to this continually overlooked issue. They are concerned by the lack of resources on campus, and the unscientific nature of current (outdated) standards in addiction treatment around the globe. They have lots of exciting projects and events planned, and they’re always looking for innovative + compassionate individuals to join the cause! Their priorities include: evidence-based support groups for students with behavioural and substance addictions, and curriculum changes for relevant programs (e.g. medicine, nursing, social work).	\N	mssat@ssmu.ca	\N	https://www.facebook.com/McGillSSAT	https://www.instagram.com/mcgillssat	2025-02-18 06:43:02.521+00	2025-01-05 17:43:56.407+00	f	\N	\N	\N	\N	\N	\N
163	mcgill-students-societea	McGill Students’ SocieTea	A fun club where tea drinkers can gather to study, socialize, and drink tea.	\N	McGillSocieTea@outlook.com	\N	https://www.facebook.com/McGillSocieTea	\N	2025-01-05 17:44:07.351+00	2025-01-05 17:44:07.351+00	f	\N	\N	\N	\N	\N	\N
171	junior-hong-kong-business-association	Junior Hong Kong Business Association	The Junior Hong Kong Canada Business Association (JHKCBA) is a student association in Canada that promotes the business collaboration between Canada and Hong Kong and fosters leadership and business skills among students. They are the junior chapter of the Hong Kong Canada Business Association (HKCBA), one of the largest bilateral trade associations in Canada.	https://www.hkcba.com/cpages/home	jhkcba@ssmu.ca	\N	https://www.facebook.com/JHKCBA	\N	2025-02-18 06:33:29.846+00	2025-01-05 17:44:11.307+00	t	\N	\N	\N	\N	\N	\N
170	igem	iGEM	McGill iGEM is a student-run organization dedicated to bringing forth innovative ideas from the lab to the marketplace, and was started to allow students to experience the entire research cycle from ideation to experimentation to commercialization. Their mission is simple: we want students at McGill University who are passionate about science and biotechnology to have an opportunity to work on cutting-edge projects that can have an impact on society.	https://igem.org.mcgill.ca/	igem@ssmu.ca	\N	https://www.facebook.com/igemmcgill	https://www.instagram.com/igem.mcgill	2025-02-18 06:33:48.983+00	2025-01-05 17:44:10.839+00	t	\N	\N	\N	\N	\N	\N
169	hosa	Health Occupation Students of America McGill (HOSA)	HOSA McGill provides an educational and interactive learning experience for students that are interested in health care professions. They help to provide students with the means to attend a Spring-Leadership Conference in Toronto as well as an International Conference (if student qualifies). The conference allows students to get hands-on experience in the profession they are interested in such as dentistry, laboratory science, forensic medicine, and more.	https://hosacanada.org/home	hosamcgill@ssmu.ca	\N	https://www.facebook.com/HOSAMcGill	https://www.instagram.com/hosamcgill	2025-02-18 06:34:11.475+00	2025-01-05 17:44:10.403+00	t	\N	\N	\N	\N	\N	\N
168	connectus-mcgill-students	ConnectUs McGill Students	ConnectUs McGill Students provides consulting services to under-resourced organizations seeking support. Their mission is to connect our team of McGill undergraduate students with local small businesses and nonprofits to help address their organizational challenges. By partnering with ConnectUs McGill Students, organizations are exposed to new and diverse perspectives, including suggestions on solutions to help solve ongoing issues and navigate their evolving operating environment.	\N	connectus@ssmu.ca	\N	https://www.facebook.com/mcgill.cu	https://www.instagram.com/mcgill.cu	2025-02-18 06:34:28.49+00	2025-01-05 17:44:09.803+00	t	\N	\N	\N	\N	\N	\N
167	club-de-dbat-francophone	Club de débat francophone	The Club de débat francophone is McGill’s francophone debate club. Their mission is to bring together French-speaking students through the art form of debating. Whether you want to practice your French, regularly compete in tournaments across Quebec, or make new friends, join them at one of their weekly practices, no experience required!	\N	clubdebatmcgill@ssmu.ca	\N	https://www.facebook.com/cdfmcgill	\N	2025-02-18 06:34:54.302+00	2025-01-05 17:44:09.407+00	t	\N	\N	\N	\N	\N	\N
165	peel-street-cinema	Peel Street Cinema	Peel Street Cinema hosts free screenings on campus during the semester. Check out their Instagram for more information!	\N	peelstreetcinema@ssmu.ca	\N	https://www.facebook.com/peelstreetcinema	https://www.instagram.com/peelstcinema	2025-02-18 06:35:41.364+00	2025-01-05 17:44:08.377+00	t	\N	\N	\N	\N	\N	\N
164	mcgill-wine-society	McGill Wine Society	The wine world is a complicated and daunting place for beginner wine drinkers. Do the words Chardonnay, Merlot or Pinot Noir sound too complex, so you keep reaching for that bottle of Barefoot or Yellow Tail? This is a problem that many university students face, but the McGill Wine Society is here to solve this issue on campus. Their club was founded to help the confused college student learn more about wine, the wine industry and expand their knowledge of the beverage in a safe and inclusive environment of fellow wine enthusiasts. Cheers!	\N	winesociety@ssmu.ca	\N	https://www.facebook.com/winesocietymcgill	\N	2025-02-18 06:36:16.475+00	2025-01-05 17:44:07.943+00	t	\N	\N	\N	\N	\N	\N
162	mcgill-students-anime-club	McGill Students’ Anime Club	The McGill Student’s Anime Club is a social club with the goal of bringing people together through a shared interest in anime and manga. They host weekly in-person and online events, ranging from screenings to games, workshops to outings. Above all, they want to make sure that everybody has a good time with us. Check out their Facebook page for details about upcoming events!	https://msac.ssmu.ca/	animeclub@ssmu.ca	\N	https://www.facebook.com/McGillAnime	https://www.instagram.com/mcgillanime	2025-02-18 06:36:38.602+00	2025-01-05 17:44:06.535+00	t	\N	\N	\N	\N	\N	\N
161	mcgill-students-knitting-club	McGill Students Knitting Club	Beginner knitter or an expert at crochet? Either way, McGill Students for Knitting Club is a relaxing space for knitters, crocheters and anyone interested in fibre arts to gather and explore the craft together! Club activities aim to be as stress/pressure free as possible, with weekly meetings that allow members to get together, chat and unwind from the daily grind while making progress to whatever project they happen to be working on at the moment. Attendance is not mandatory in the slightest, and members are free to attend every meeting or just one throughout the course of the semester. In addition to weekly meetings, the club also holds occasional beginner’s workshops for both knitting and crochet to teach members the basics so they have the tools to get started on their exploration of the world of fibre arts! So no experience is required at all – feel free to contact them if you have any questions!	\N	knittingclub@ssmu.ca	\N	https://www.facebook.com/mcgillknittingclub	https://www.instagram.com/mcgillknittingclub	2025-02-18 06:37:08.696+00	2025-01-05 17:44:06.095+00	t	\N	\N	\N	\N	\N	\N
185	women-in-international-security-canada-at-mcgill	Women in International Security Canada at McGill	Women In International Security at McGill is a SSMU affiliated chapter of the larger non-profit organization WIIS Canada, which aims to create a network for women in peace and security.	https://wiiscanada.org/	wiismcgill@ssmu.ca	\N	https://www.facebook.com/wiiscanadaatmcgill	https://www.instagram.com/wiismcgill	2025-01-05 17:44:18.135+00	2025-01-05 17:44:18.135+00	t	\N	\N	\N	\N	\N	\N
183	sri	Student Research Initiative	Student Research Initiative is a club at McGill with the goal of helping undergraduates get involved in research. Through informative seminars, networking events, their mentorship program and research database, and annual research award, they aim to lower the barrier into undergraduate, providing McGill students with the necessary resources to support their research endeavours.	https://srissmu.wixsite.com/srimcgill	Studentresearchinitiative@ssmu.ca	\N	https://www.facebook.com/StudentResearchInitiative	https://www.instagram.com/sri.mcgill	2025-02-07 15:48:17.772+00	2025-01-05 17:44:17.239+00	t	\N	\N	\N	\N	\N	\N
182	formerly-mcgill-students-for-lead-to-speak	Speak to Lead	Speak to Lead (Formerly McGill Students for Lead to Speak) aims to help fellow McGill Students improve their speaking and presentation while networking with likeminded leaders of tomorrow! Don’t miss out on ‘S2L’ workshops and events posted on Facebook and Instagram!	\N	speaktolead@ssmu.ca	\N	https://www.facebook.com/mcgillspeaktolead	https://www.instagram.com/s2l_mcgill	2025-02-07 15:49:38.787+00	2025-01-05 17:44:16.839+00	t	\N	\N	\N	\N	\N	\N
181	socratic-discussion-club	Socratic Discussion Club	The Socratic Discussion Club brings together McGill students who are interested in meeting people to discuss ideas, gain knowledge, and take part in thought-provoking events. They are the first and only student organization at McGill University that seeks to bring people of diverse views together to share ideas on various topics, ranging from philosophy to politics to economics and others. Join them at weekly discussion circles!	\N	socraticdiscussion@ssmu.ca	\N	https://www.facebook.com/McGill-Socratic-Discussion-Club-107741391444376	https://www.instagram.com/socratic_discussion_mcgill	2025-02-07 15:50:10.204+00	2025-01-05 17:44:16.403+00	t	\N	\N	\N	\N	\N	\N
180	research-and-sustainability-network	Research and Sustainability Network	The Research and Sustainability Network (RSN) seeks to inform and empower students at McGill, bridging the gap between researchers in sustainability and undergraduates interested in research. Through recurring conferences, speaker series, and networking events, they aim to connect like-minded individuals within a cross-faculty network, facilitating collaboration and increasing accessibility to undergraduate research positions.	https://rsn.ssmu.ca/	Rsnetwork@ssmu.ca	\N	https://www.facebook.com/RSNMcGill	https://www.instagram.com/rsn.mcgill	2025-02-07 15:51:23.016+00	2025-01-05 17:44:15.921+00	t	\N	\N	\N	\N	\N	\N
179	medspecs	Medical Perspectives	Medical Perspectives (MedSpecs) is a McGill undergraduate organization that maintains a supportive community for students who are curious about medical careers to access information, exchange ideas, and gain experience first-hand.	https://medspecs.ssmu.ca/	medspecs@ssmu.ca	\N	https://www.facebook.com/mcgillmedspecs	https://www.instagram.com/mcgillmedspecs	2025-02-07 15:51:37.741+00	2025-01-05 17:44:15.493+00	t	\N	\N	\N	\N	\N	\N
178	msaa	McGill Students’ Actuarial Association	The McGill Students’ Actuarial Association (MSAA) is a nascent SSMU student club looking to boost support for aspiring actuaries at McGill. They serve as a liaison between actuarial students and their goals, providing members with information on actuarial science to allow them to break into the actuarial world. They provide a place where students with similar interests can connect with one another and be represented for by a student association.	https://mcgillmsaa.wordpress.com/	msaa@ssmu.ca	\N	https://www.facebook.com/mcgill.msaa	\N	2025-02-07 15:52:36.76+00	2025-01-05 17:44:14.512+00	t	\N	\N	\N	\N	\N	\N
177	msts	McGill Students Trading Society (MSTS)	The McGill Students’ Trading Society seeks to promote advanced knowledge of the financial services industry and increase the understanding of financial markets for all its members. The society strives to host engaging events, workshops, and round-table discussions relating to a broad range of economics, finance, and business topics. Through their four pillars – education, engagement, advancement, and inclusivity – they aim to empower their student community and help bridge the gap between education and the field of finance.	https://tradingsociety.wixsite.com/msts	tradingsociety@ssmu.ca	\N	https://www.facebook.com/mcgillsts	https://www.instagram.com/mstsmcgill	2025-02-18 06:31:41.169+00	2025-01-05 17:44:14.043+00	t	\N	\N	\N	\N	\N	\N
176	mcgill-students-chapter-for-scientista	McGill Students Chapter for Scientista	A Chapter of the National Scientista Foundation (currently the largest network of campus women across STEM disciplines). Their all-female team is made up entirely of McGill University students studying various fields in science.	https://scientistamcgill.wordpress.com/	scientista.mcgill@ssmu.ca	\N	https://www.facebook.com/scientistamcgill	https://www.instagram.com/scientistamcgill	2025-02-18 06:31:54.423+00	2025-01-05 17:44:13.629+00	t	\N	\N	\N	\N	\N	\N
175	mpdss	McGill Pre-Dental Students’ Society (MPDSS)	McGill’s very own pre-dental student society is a club that welcomes all students interested in dentistry. They share resources, events, shadowing opportunities, and a network of support for pre-dental students.	https://mpdss.ssmu.ca/	mpdss@ssmu.ca	\N	https://www.facebook.com/mcgillpredent	https://www.instagram.com/mcgillpredentalsociety	2025-02-18 06:32:07.089+00	2025-01-05 17:44:13.237+00	t	\N	\N	\N	\N	\N	\N
174	misn	McGill International Students Network (MISN)	The McGill International Student Network is an orgaMcto Montreal and McGill! Their events allow students to take part in cultural activities, excursions in Quebec, Canada and other countries, as well as meet other fellow international students! They also provide language exchange services and free language classes. All students – both Canadian and international – are welcome to join!	https://misn.ssmu.ca/	misn@ssmu.ca	\N	https://www.facebook.com/mcgillisn	https://www.instagram.com/misnmcgill	2025-02-18 06:32:31.355+00	2025-01-05 17:44:12.811+00	t	\N	\N	\N	\N	\N	\N
173	mcgill-debating-union	McGill Debating Union	The McGill Debating Union is one of the oldest and top university debating societies in the world. They compete regularly at tournaments across Canada and the US! They’re always welcoming new members, no experience necessary.	https://debatingunion.ssmu.ca/	mcgill.debating@ssmu.ca	\N	https://www.facebook.com/mcgilldebate	https://www.instagram.com/mcgilldebatingunion	2025-02-18 06:32:48.783+00	2025-01-05 17:44:12.387+00	t	\N	\N	\N	\N	\N	\N
195	mcgill-students-chapter-of-war-child	McGill Students Chapter of War Child	The McGill Students Chapter of War Child aims to raise awareness and funds for the War Child NGO which provides assistance to children in areas experiencing conflict and the aftermath of conflict. War Child aims to provide aid amid crisis to improve children’s lives.	https://www.warchild.ca/	warchildatmcgill@gmail.com	\N	https://www.facebook.com/mcgillstudentschapterofwarchild	https://www.instagram.com/warchildmcgill	2025-02-07 15:38:36.095+00	2025-01-05 17:44:23.624+00	t	\N	\N	\N	\N	\N	\N
194	mcgill-model-parliament	McGill Model Parliament	The McGill Model Parliament is a Student Group of the Students’ Society of McGill University which aims to establish a model of Canadian parliamentary process which delegates can participate in.	\N	mcgillmodelparliament@ssmu.ca	\N	https://www.facebook.com/mcgillmodelparliament	https://www.instagram.com/mcgillmodelparliament	2025-02-07 15:38:46.838+00	2025-01-05 17:44:22.855+00	t	\N	\N	\N	\N	\N	\N
193	liberal-mcgill	Liberal McGill	Liberal McGill is accredited by the Young Liberals of Canada (Quebec) and is a student group of the Students’ Society of McGill University. Their page is a means to connect Liberals from across Canada with Liberals at McGill to discuss ideas, get information about upcoming events, and further theCanadian political dialogue.	http://www.liberal.ca/	liberalmcgill@gmail.com	\N	https://www.facebook.com/YLCatMcGill	https://www.instagram.com/liberalmcgill	2025-02-07 15:39:14.413+00	2025-01-05 17:44:21.839+00	t	\N	\N	\N	\N	\N	\N
192	journalists-for-human-rights-mcgill-university-student	Journalists for Human Rights McGill Chapter	The JHR McGill Chapter is an entirely student-run platform that seeks to cover human rights stories objectively and effectively. They operate through the use of numerous forms of media, including an online journal, podcasts, and video segments. They are affiliated with the larger JHR organization. To this end, JHR McGill is dedicated to promoting a unified campus on issues related to human rights and journalism. They strive to collaborate with other clubs and services on events and campaigns. Groups they have coordinated with in the past include TV McGill, CKUT, McGill Global AIDS Coalition, Cinema Politica, Arts Internship Office, among others. 	https://jhrmcgill.ssmu.ca/about-us	jhrmcgill@ssmu.ca	\N	https://www.facebook.com/JHRmcgill	https://www.instagram.com/jhr.mcgill	2025-02-07 15:41:39.379+00	2025-01-05 17:44:21.399+00	t	\N	\N	\N	\N	\N	\N
191	indigenous-student-alliance	Indigenous Student Alliance	The Indigenous Student Alliance is a community of Indigenous students and allies based at McGill University. The ISA aims to foster Indigenous community growth, unite Indigenous students and allies, and develop relationships with other marginalized communities. The ISA’s work is in constant conversation with the ideas and hopes of Indigenous students, with the goal of bringing them to life in our community.	http://indigsa-mcgill.weebly.com/	isa@ssmu.ca	\N	https://www.facebook.com/Indigenous.Student.Alliance	https://www.instagram.com/isamcgill	2025-02-07 15:42:02.365+00	2025-01-05 17:44:20.963+00	t	\N	\N	\N	\N	\N	\N
190	heforshe-mcgill	HeForShe McGill	HeForShe McGill is an SSMU club dedicated to raising awareness on campus about the importance of involving male-identifying and majority-gendered individuals in the movement for gender equality, and about gender issues, their causes, and their consequences on people of all genders. They seek to create a forum for discussion for those of all gender identities interested in gender issues, and encourage those who typically feel alienated from the movement to be a part of it, through interactive movie screenings, fundraisers, discussions, and educational events.	https://heforshe.ssmu.ca/	heforshemcgill@ssmu.ca	\N	https://www.facebook.com/heforshemcgill	https://www.instagram.com/heforshemcgill	2025-02-07 15:43:27.067+00	2025-01-05 17:44:20.531+00	f	\N	\N	\N	\N	\N	\N
189	msf	Friends of Médecins Sans Frontières	Friends of MSF groups are student societies in various Canadian Universities. Their McGill chapter is an official supporter of Médecins Sans Frontières (Doctors without Borders). Their goals are to increase awareness for MSF, to create fundraising activities, and to encourage aspiring humanitarians to consider working with MSF. They aim to accomplish these goals through guest speaker events, case competitions, and workshops.	https://www.facebook.com/FriendsofMSFMcGill	friendsofmsf@ssmu.ca	\N	https://www.facebook.com/FriendsofMSFMcGill	https://www.instagram.com/fomsfmcgill	2025-02-07 15:43:54.58+00	2025-01-05 17:44:20.067+00	t	\N	\N	\N	\N	\N	\N
188	expanding-economics	Expanding Economics	Expanding Economics is McGill University’s branch of a global network of groups called Rethinking Economics, which are united by the mission to practice and promote an economics that is open, relevant, and for everyone. To achieve this, they host various events on and off-campus and share resources on our social media that present new schools of economic thought and foster discussion on these perspectives. They also hope to create a stronger relationship with the Economics department at McGill in order to communicate our missions and have them incorporated into the curriculum at McGill.	https://www.expandingeconomics.com/	expanding.economics@ssmu.ca, expandingecon.mtl@rethinkingeconomics.org	\N	https://www.facebook.com/ExpandingEconomicsMcGill	https://www.instagram.com/expandingeconomics	2025-02-07 15:44:28.73+00	2025-01-05 17:44:19.601+00	t	\N	\N	\N	\N	\N	\N
187	diversity-in-math	Diversity In Math	The Diversity in Math club at McGill university is dedicated to inspire people from all backgrounds to explore and develop their passion for mathematics. They provide mentorship and networking opportunities to encourage students from underrepresented backgrounds to pursue mathematics-related careers. They host community-building events to foster an open learning environment in mathematics for underrepresented minorities and allies. They also push to raise awareness about the need for more diversity in mathematics.	https://diversityinmath.ssmu.ca/	diversityinmath@ssmu.ca	\N	https://www.facebook.com/mcgilldiversityinmath	https://www.instagram.com/mcgilldiversityinmath	2025-02-07 15:45:04.611+00	2025-01-05 17:44:19.167+00	t	\N	\N	\N	\N	\N	\N
186	wit	Women in Tech (WIT)	Women in Tech is a student-run club that aims to encourage more women to get involved in the world of technology. Whether it be through networking events, coding workshops, or company tours, they want to provide all women of varying backgrounds with opportunities and skills to be able to excel in the tech world.	https://womenintech.ssmu.ca/	womenintech@ssmu.ca	\N	https://www.facebook.com/witmcgill	https://www.instagram.com/witmcgill	2025-02-07 15:45:43.853+00	2025-01-05 17:44:18.559+00	t	\N	\N	\N	\N	\N	\N
202	chabad-house	Chabad at McGill (Chabad House)	Chabad at McGill aims to connect the McGill Jewish community with social programming, community building programming and opportunities to experience Jewish holidays and events.	https://ssmu.ca/clubs/religion-culture-clubs/www.chabadmcgill.com	chabad@ssmu.ca	\N	https://www.facebook.com/chabadatmcgill	https://www.instagram.com/mcgillchabad	2025-01-05 17:44:27.025+00	2025-01-05 17:44:27.025+00	t	\N	\N	\N	\N	\N	\N
261	blues-pub-committee	Blues Pub Committee	Blues Pub is a student run bar that occurs on a weekly basis in the McConnell Engineering Common Room. A long withstanding tradition in the faculty of engineering, Blues Pub is a place to gather, drink beverages, and relax from a long week of trying academics.	https://eus.wiki/Blues_Pub	blues.pub@mcgilleus.ca	\N	https://www.facebook.com/McGillBluesPub	https://www.instagram.com/mcgill.bluespub	2025-01-05 17:44:57.191+00	2025-01-05 17:44:57.191+00	t	\N	\N	\N	\N	\N	\N
206	hong-kong-student-network	Hong Kong Student Network	The Hong Kong Student Network strives to accommodate new students from all over the world and help them familiarize themselves with McGill and everything that is beautiful about it. They pride themselves on being a Home Away From Home for everybody, and whole-heartedly embrace the multiculturalism that Hong Kong is known for. They plan a wide variety of events, from singing competitions to ski trips, to get the student body involved. They hope that everyone who joins HKSN will have an awesome time and meet lots of new people!	https://hksn.medium.com/	mcgillhksn@ssmu.ca	\N	https://www.facebook.com/mcgillhksn	https://www.instagram.com/hksnmcgill	2025-02-07 15:27:18.785+00	2025-01-05 17:44:28.829+00	t	\N	\N	\N	\N	\N	\N
205	hillel-mcgill	Hillel McGill	Hillel McGill is your one-stop shop for Jewish life on campus. Representing the vast and diverse Jewish community here at McGill, they offer a wide variety of programs, events, internships, and connection opportunities for everyone to take part in. From socials to Shabbat services, fashion to politics, Hillel’s vision is that every student is inspired to take part in Jewish life on campus!	https://www.hillel.org/college-guide/list/record/mcgill-university	hillelmcgill@ssmu.ca	\N	https://www.facebook.com/HillelMTL	https://www.instagram.com/hillel.mcgill	2025-02-07 15:29:07.773+00	2025-01-05 17:44:28.381+00	t	\N	\N	\N	\N	\N	\N
203	chinese-students-and-scholars-association-at-mcgill-university	Chinese Students and Scholars Association at McGill University	CSSA aims to provide Chinese students overseas with useful assistance to help them quickly adapt to the new learning and the living environment, as well as organize a variety of amazing events to enhance their overall experience both on and off-campus. Visioning itself as a progressive student community, not only does CSSA seek to increase recognition within the university, but also to amplify broader influence through actively undertaking its social responsibilities. In order to attain this long-term objective, CSSA is devoted to bridging its members with multiple well-known enterprises, NPOs, and local businesses. Nonetheless, as an inheritor of Chinese culture, CSSA is committed to make the world aware of the richness and uniqueness of the thriving Chinese cultural heritage and innovation by fostering better cultural connection, interaction, and exchange with students from other countries.	https://www.mcgillcssa.com/	mcgillcssa@ssmu.ca	\N	https://www.facebook.com/cssa.mcgill	https://www.instagram.com/mcgill.cssa	2025-02-07 15:32:16.041+00	2025-01-05 17:44:27.467+00	t	\N	\N	\N	\N	\N	\N
201	css	Caribbean Students Society of McGill University	The Caribbean Students Society of McGill University is a culture club at McGill that seeks to promote, foster, encourage, share and celebrate Caribbean Culture in the McGill and Montreal communities.	\N	css@ssmu.ca	\N	https://www.facebook.com/mcgillcss	https://www.instagram.com/mcgillcss	2025-02-07 15:33:29.494+00	2025-01-05 17:44:26.603+00	t	\N	\N	\N	\N	\N	\N
200	britsoc	British Society McGill	The British Society is a student group of the SSMU whose purpose is to provide an atmosphere where British students can feel at home as well as to educate the wider Montreal community about Great Britain. This group is open to not just those who are British, but also to those that have a love and appreciation for the great country and would like to learn more about its culture. Various events and fundraisers shall be held throughout the year to promote BritSoc as well as to foster a vibrant British community on the McGill campus.	\N	\N	\N	https://www.facebook.com/bas.mcgill	\N	2025-02-07 15:34:54.922+00	2025-01-05 17:44:26.161+00	f	\N	\N	\N	\N	\N	\N
198	bsa	Bangladeshi Students Association (BSA)	The Bangladeshi Student Association is a student group of the SSMU committed to showcase the rich culture and history of Bangladesh both in McGill and to the Montreal community at large. This group is open to not just those who are Bengali, but also to those that have a love and appreciation for the country and it’s culture. Various events and activities shall be held throughout the year to promote BSA as well as to foster a vibrant Bangladeshi community on the McGill campus, leaving everyone involved with a plethora of fond memories.	\N	bsa@ssmu.ca	\N	https://www.facebook.com/bsamcgill	https://www.instagram.com/bsamcgill	2025-02-07 15:36:00.69+00	2025-01-05 17:44:25.299+00	t	\N	\N	\N	\N	\N	\N
197	socialist-fightback-club	Socialist Fightback Club	Fightback is a revolutionary organization fighting for the socialist transformation of society. They are the Canadian section of the International Marxist Tendency and actively seek to educate workers and youth in the genuine ideas of Marxism, in order to fight back against capitalist attacks and austerity.	https://www.marxist.ca/	mcgill.fightback@ssmu.ca	\N	https://www.facebook.com/FightbackCM	https://www.instagram.com/mcgillmarxists	2025-02-07 15:36:54.673+00	2025-01-05 17:44:24.701+00	t	\N	\N	\N	\N	\N	\N
199	bss-1	Belgian Students’ Society (BSS)	The McGill Belgian Student Society has a mission to reunite all these Belgians and individuals with European interests to build meaningful and insightful relations through Belgian-oriented diplomatic, economic and social education and events.	\N	belgiansociety@ssmu.ca	\N	\N	https://www.instagram.com/mcgillbelgiansociety	2025-02-18 06:04:52.467+00	2025-01-05 17:44:25.733+00	t	\N	\N	\N	\N	\N	\N
216	misa-1	McGill Iranian Student Association (MISA)	The McGill Iranian Student Association is a non-religious, non-political, and non-profit organization dedicated to hosting a variety of cultural and non-cultural events year-round and creating greater public awareness about the Iranian culture.	https://sites.google.com/view/mcgillmisa/home	misa@ssmu.ca	\N	https://www.facebook.com/mcgillmisa	https://www.instagram.com/mcgillmisa	2025-01-05 17:44:33.587+00	2025-01-05 17:44:33.587+00	t	\N	\N	\N	\N	\N	\N
217	isa-1	McGill Ismaili Students Association (ISA)	The McGill Ismaili Student Association is a club that helps welcome incoming Ismailis in Montreal to feel welcome and comfortable in the community. They have events to build and grow relationships within our religious community.	\N	ismaili@ssmu.ca	\N	https://www.facebook.com/isamtl	https://www.instagram.com/therealmisa514	2025-02-07 15:09:32.646+00	2025-01-05 17:44:34.018+00	f	\N	\N	\N	\N	\N	\N
214	mcgill-dharma-society	McGill Dharma Society	McGill Dharma Society (MDS) serves as the official campus representation for students belonging to Hindu and other Dharmic traditions. MDS provides community and resources for students of these faiths, as well as allows students of all backgrounds to collectively learn about and participate in their spiritual and cultural practices.	\N	dharmasociety@ssmu.ca	\N	https://www.facebook.com/mcgilldharmasociety	https://www.instagram.com/mcgilldharmasociety	2025-02-07 15:10:51.765+00	2025-01-05 17:44:32.541+00	t	\N	\N	\N	\N	\N	\N
212	mcss	McGill Chinese Students Society (MCSS)	MCSS, McGill Chinese Students’ Society is the largest and most influential cultural student organization in Eastern Canada. With over 15 events per year and 40 years of history, they provide a variety of events to our over 1,500 active members and help our members succeed in school and life. Their short-term goal is to provide students with valuable events to make their student life more meaningful, while their long-term goal is to motivate and encourage students to give back to their community and excel academically by providing them with helpful services including seminars, lessons, and talks.	https://mcss.ca/	mcss@ssmu.ca	\N	https://www.facebook.com/mcss.ca	https://www.instagram.com/mcssfam	2025-02-07 15:13:00.922+00	2025-01-05 17:44:31.643+00	t	\N	\N	\N	\N	\N	\N
209	massa	Malaysian and Singaporean Students’ Association (MASSA)	The Malaysian and Singaporean Students’ Association of McGill aims to celebrate their cultures, connect members of the community, and foster an inclusive environment for all during events.\n \nHistorically, their events are themed around local celebrations (e.g., Deepevali and Chinese New Year). They often incorporate activities that remind them of memories back home and try to recreate the same atmosphere of authentic home-cooked local cuisine. They also provide a warm and accessible platform where members can meet and interact whilst keeping in touch with their roots. MASSA continues to be an important avenue for students from their region to turn to when home is literally on the other side of the world. However, they are also open for anyone of any background to join!	\N	massa@ssmu.ca	\N	https://www.facebook.com/mcgill.massa888	https://www.instagram.com/massa_mcgill	2025-02-07 15:20:29.985+00	2025-01-05 17:44:30.179+00	t	\N	\N	\N	\N	\N	\N
208	jsa	Japanese Students Association (JSA)	The Japanese Students Association is a student association that intends to raise awareness of traditional and modern Japanese culture, create opportunities for both Japanese and non-Japanese students to practice and learn the language, aid students in finding opportunities to work or intern at Japanese companies or global companies based in Japan, raise funds for charities in Japan that support the well-being of the country, provide students with opportunities for socializing and involvement through social events and volunteering from which friendships and community are built, and create a local Japanese community and Japanese Alumni network for the purpose of sharing information and resources. They are a very diverse group of students and although some of our members are indeed Japanese, there are many non-Japanese members as well. Even though they have varying backgrounds, they all have a common interest in Japanese culture and language.	\N	jsa@ssmu.ca	\N	https://www.facebook.com/jsa.mcgill	https://www.instagram.com/jsamcgill	2025-02-07 15:23:04.037+00	2025-01-05 17:44:29.741+00	t	\N	\N	\N	\N	\N	\N
213	mcf	McGill Christian Fellowship (MCF)	All are welcome to McGill Christian Fellowship, a community where students are invited to love one another and be loved by God. Through weekly Bible studies and fellowship-wide events, they encourage students to uncover what it means to serve others and follow Jesus, both on campus and in the greater Montreal community. As part of InterVarsity Christian Fellowship of Canada, MCF gathers undergraduate and graduate students, in all their ethnic diversity, to grow in their relationship with God. Through prayer, worship, and fellowship, they are a community that walks by faith and seeks to make God known on campus. Their community is open to people of all faith backgrounds and those who are interested in exploring faith for the first time.	https://www.mcgillcf.com/	intervarsitymcf@ssmu.ca	\N	https://www.facebook.com/ivmcgillcf	\N	2025-02-14 15:50:05.812+00	2025-01-05 17:44:32.107+00	t	\N	\N	\N	\N	\N	\N
211	manaba	McGill Association of North American Born Asians	The McGill Association of North American Born Asians is a student-run organization that promotes and embraces Asian culture here at McGill. They are a diverse group of students with international backgrounds that host social events and create a welcoming sense of Asian heritage. They are a home away from home.	https://manaba.ca/	manaba@ssmu.ca	\N	https://www.facebook.com/manabamcgill	https://www.instagram.com/manaba.mcgill	2025-02-14 15:50:43.473+00	2025-01-05 17:44:31.219+00	t	\N	\N	\N	\N	\N	\N
210	masa	McGill Armenian Students Association (MASA)	McGill Armenian Students Association aims to unite McGill students and advance multiculturalism and academic progress by promoting Armenian culture, heritage, and history. Through engaging cultural events, historical presentations, and charitable promotions, they hope to extend their wonderful culture with fellow McGill students. MASA is not only for Armenians, and they welcome all students to join the club and take part in events!	\N	asa@ssmu.ca	\N	https://www.facebook.com/mcgillASA	\N	2025-02-14 15:51:04.772+00	2025-01-05 17:44:30.793+00	t	\N	\N	\N	\N	\N	\N
224	musa-1	McGill Ukrainian Students Association (MUSA)	The McGill Ukrainian Students’ Association represents a diverse group of students with a passion and interest in Ukrainian culture. They welcome students of all cultural and educational backgrounds. Each year they host a diverse number of events, from the traditional to the political, from cultural to the academic. At MUSA, they understand that youth has a key role in supporting the culture and sustaining the tradition. They are a group of individuals who cares about the past, present, and future of Ukraine and are passionate about their culture. They welcome any student or member of the community who shares their values, regardless of the motive.	\N	musa@ssmu.ca	\N	https://www.facebook.com/musamontreal	https://www.instagram.com/mcgill_ukies	2025-02-07 06:32:38.869+00	2025-01-05 17:44:37.305+00	t	\N	\N	\N	\N	\N	\N
220	mcgill-sikh-students-association	McGill Sikh Students’ Association	The McGill Sikh Students’ Association provides a positive and inclusive space for all Sikh students and organize events that are in line with Sikh spirituality and bring awareness around articles of faith, including turbans.	\N	mcgill.sikhs@ssmu.ca	\N	https://www.facebook.com/sikhsatmcgill	https://www.instagram.com/mcgill.sikhs	2025-02-07 15:09:07.598+00	2025-01-05 17:44:35.633+00	t	\N	\N	\N	\N	\N	\N
227	multi-ethnic-student-alliance	Multi-Ethnic Student Alliance	The Multi-Ethnic Student Alliance is a group of multi-ethnic students exploring identity through events, food, music, and friendly discussions! If you have to pull out a family tree when people ask where you’re from, had trouble filling out the Census, or have never really thought about your cultural identity before – you’ve come to the right place. Besides celebrating their diverse backgrounds, they are also here to be a safe space where everyone can feel comfortable being their unique selves.	\N	multi-ethnicalliance@ssmu.ca	\N	https://www.facebook.com/mesamtl	https://www.instagram.com/mesamtl	2025-02-14 15:44:46.655+00	2025-01-05 17:44:38.845+00	t	\N	\N	\N	\N	\N	\N
226	mvsa	McGill Vietnamese Students Association (MVSA)	MVSA was originally created to promote Vietnamese culture with fellow McGill students and the community at large. They also strive to share our wonderful food, values, and traditions with the McGill community and the population of Montreal. They hope to provide members with support, skills, and opportunities to make student life fun and rewarding at university. To achieve these goals, they offer multiple events throughout the year such as welcome back parties, bake sales, restaurant outings, cooking events, and their annual Tết in collaboration with the Montreal Vietnamese Community. In short, their mission is to build a strong community while having fun!	\N	mvsa@ssmu.ca	\N	https://www.facebook.com/mcgillvsa	\N	2025-02-14 15:45:59.463+00	2025-01-05 17:44:38.215+00	t	\N	\N	\N	\N	\N	\N
225	mufasa	McGill University Filipino Asian Students Association (MUFASA)	MUFASA stands for McGill University’s Filipino Asian Students’ Association. MUFASA is for Filipinos and Non-Filipinos alike! Their mission is to establish and create a network of Filipinos across McGill’s campus to educate and raise awareness of Filipino culture. They organize cultural fundraising events in support of different Filipino organizations, every little bit counts! Anyone can join: Filipinos, Non-Filipinos, Undergrad, Grad students!	https://mufasa.ssmu.ca/	mufasa@ssmu.ca	\N	https://www.facebook.com/MufasaMcgill	https://www.instagram.com/mufasamcgill	2025-02-14 15:46:31.861+00	2025-01-05 17:44:37.75+00	t	\N	\N	\N	\N	\N	\N
223	mcgill-thaqalayn-muslim-students-association	McGill Thaqalayn Muslim Students’ Association	The McGill Thaqalayn Muslim Students’ Association grew out of a desire to provide a space for Muslim students, especially those who identify as Shi’i, to practice their faith and rediscover their values. While they primarily are here to provide a space for Muslims, they are open to Muslims and non-Muslims of all backgrounds.	\N	tma@ssmu.ca	\N	https://www.facebook.com/McGillTMA	https://www.instagram.com/tmamcgill	2025-02-14 15:47:13.762+00	2025-01-05 17:44:36.903+00	t	\N	\N	\N	\N	\N	\N
222	mtsa	McGill Taiwanese Students’ Association (MTSA)	The McGill Taiwanese Students Association is the only Taiwanese student community at McGill University. Their main goal is to promote the most exciting and essential parts of Taiwanese culture and to forge a strong and open student society. While they take pride yearly in their past and continuing commitments to members and their interests, they hope to reinvent areas of this society by focusing on a unique, multicultural approach to their rich culture.	https://mtsa.netlify.app/	mtsa@ssmu.ca	\N	https://www.facebook.com/mcgill.mtsa	https://www.instagram.com/mtsalovesyou	2025-02-14 15:47:39.215+00	2025-01-05 17:44:36.456+00	t	\N	\N	\N	\N	\N	\N
221	ocf	McGill Students Orthodox Christian Fellowship	Orthodox Christian Fellowship is the official collegiate campus ministry program under SCOBA (the Standing Conference of Canonical Orthodox Bishops in the Americas). Their mission is to support fellowships on college campuses, whose members experience and witness to the Orthodox Christian Church through community life, prayer, service to others and study of the Faith. Join them for bi-weekly discussions and Bible studies and hangouts as well as other special events including retreats, monastery visits, and fellowship events! All are welcome!	\N	mcgillstudentsocf@ssmu.ca	\N	https://www.facebook.com/mcgillstudentsocf	\N	2025-02-14 15:48:00.571+00	2025-01-05 17:44:36.019+00	f	\N	\N	\N	\N	\N	\N
219	mpsa-1	McGill Polish Students’ Association (MPSA)	The McGill Polish Students’ Association is an initiative looking to provide a source of social and cultural contact for McGill Polish Students, and serve McGill students at large with a place to uncover more about Polonia or Polish language, culture, or history, and finally to connect the greater McGill community with the little known McGill affiliated Polish Institute of Arts and Sciences in Canada which has served the McGill and Polish-Canadian community since 1943.	\N	polishmcgill@gmail.com	\N	https://www.facebook.com/polishmcgill	https://www.instagram.com/mcgill.mpsa	2025-02-14 15:48:34.385+00	2025-01-05 17:44:35.184+00	t	\N	\N	\N	\N	\N	\N
236	tssmu	Turkish Students Society of McGill University (TSSMU)	Turkish Students’ Society of McGill University is one of the largest student organizations in Montreal area and represents all Turkish students enrolled at McGill University. TSSMU was founded in 1994 with the goal to improve the student experience of Turkish students. They aim to make a beneficial impact through our events by establishing and enhancing student relationships within the McGill community as well as by fundraising for various causes. Every semester they donate a portion of their proceedings to a different charity in Turkey.	\N	turkish@ssmu.ca	\N	https://www.facebook.com/tssmu.ca	https://www.instagram.com/turkishssmu	2025-02-07 06:23:50.635+00	2025-01-05 17:44:42.855+00	t	\N	\N	\N	\N	\N	\N
235	kss	The Korean Students Society (KSS)	McGill Korean Students Society (KSS) is the official student association dedicated to Korean students within McGill. They aim to assist Korean students in building connections and help integrate new students into the McGill community.	\N	kss@ssmu.ca	\N	https://www.facebook.com/mcgillkoreanstudentssociety	\N	2025-02-07 06:24:14.601+00	2025-01-05 17:44:42.463+00	t	\N	\N	\N	\N	\N	\N
234	tamill	Tamil Students’ Association of McGill (TAMill)	Tamil Students’ Association of McGill (TAMill)’s mandate is to promote Tamil culture, language, and customs! They strive to foster and strengthen unity and amity with other community organizations both within and exterior to McGill University.	\N	tamill@ssmu.ca	\N	https://www.facebook.com/Tamil-Association-of-McGill-TAMill-238815696194662	https://www.instagram.com/tamill.mcgill	2025-02-07 06:24:28.324+00	2025-01-05 17:44:42.065+00	t	\N	\N	\N	\N	\N	\N
232	slasa	Spanish and Latin American Students’ Association of McGill University (SLASA)	SLASA is a student-run organization based in Montreal, Canada since 1989. They serve as a social and professional network for the Spanish-Speaking and Latin students at McGill University.\n \n Throughout the year, we organize many events and activities to celebrate and share our culture, promote the academic success of Spanish-Speaking McGillians, and integrate our members into the greater Montreal community. SLASA is an inclusive organization, and all are welcome to attend our events and participate in our discussions regardless of language, cultural background, or citizenship.	https://slasa.ssmu.ca/	slasamcgill@ssmu.ca	\N	https://www.facebook.com/SLASA.Mcgill	\N	2025-02-07 06:25:21.061+00	2025-01-05 17:44:41.156+00	t	\N	\N	\N	\N	\N	\N
231	p2c	Power to Change (P2C)	Power to Change – Students is a Christian student ministry that desires to help students like you take their next step towards Jesus, wherever you are in your faith journey. They want to see every student walking closer to Jesus and experiencing life in him. As a SSMU club at McGill they meet on and off campus throughout the year, and are part of a bigger network of campus groups in Montreal. They continue to connect as a community and grow together through discipleship groups, prayer meetings, outreaches, socials, and weekly fellowship.	https://p2c.com/students/campuses/mcgill-university	p2c.mcgill@ssmu.ca	\N	https://www.facebook.com/p2cmcgill	https://www.instagram.com/p2cmcgill	2025-02-07 06:26:02.686+00	2025-01-05 17:44:40.607+00	t	\N	\N	\N	\N	\N	\N
233	ssa	Syrian Students’ Association (SSA)	The Syrian Students’ Association of McGill University is a non-profit student club under SSMU. They are a secular, apolitical club that is not affiliated with nor subsidized by any political party or religious group. Their events are open to everyone! Their club’s mission can be summarized in 4 main articles: social, humanitarian, educational, and cultural.	https://ssamcgill.ssmu.ca/	ssamcgill@ssmu.ca	\N	https://www.facebook.com/ssamcgillu	https://www.instagram.com/ssamcgill	2025-02-14 15:41:33.173+00	2025-01-05 17:44:41.595+00	t	\N	\N	\N	\N	\N	\N
230	psa	Pakistani Students Association (PSA)	For more than thirty years, the Pakistani Students’ Association has committed itself to bringing the vitality and vibrancy of Pakistani life to the McGill community. Today, the organization is still fundamentally dedicated to three main objectives: educating, establishing a forum for discussion, and creating a social fabric to connect students.	\N	psa@ssmu.ca	\N	https://www.facebook.com/psamcgill	https://www.instagram.com/psamcgillu	2025-02-14 15:43:16.982+00	2025-01-05 17:44:40.167+00	t	\N	\N	\N	\N	\N	\N
229	nordic-culture-club	Nordic Culture Club	The McGill Students’ Nordic Culture Club is a student group of the SSMU whose purpose is to provide opportunities for students of all backgrounds to explore an interest in Nordic (Danish, Finnish, Icelandic, Norwegian and Swedish) culture. In addition to providing a welcoming space for anyone to learn about Nordic art, languages, holidays, and more, their events help students with existing ties to the Nordic countries to connect on campus. Join them for casual fika or for any of their special events throughout the school year!	\N	nordicculture@ssmu.ca	\N	https://www.facebook.com/mcgill.ncc	https://www.instagram.com/mcgill_ncc	2025-02-14 15:43:45.66+00	2025-01-05 17:44:39.735+00	t	\N	\N	\N	\N	\N	\N
262	e-week-committee	E-Week Committee	Engineering Week, or E-Week, is a four to five day event in January organized by the E-Week Committee, which comprises the VP Internal, one or more E-Week Chiefs, and several E-Week Coordinators. E-Week takes place around mid March each year, and helps foster a stronger bond between Engineering students.	https://eus.wiki/E-Week	eweek.communications@gmail.com	\N	https://www.facebook.com/McGillEWeek	\N	2025-01-28 14:18:35.741+00	2025-01-05 17:44:57.743+00	t	\N	\N	\N	\N	\N	\N
246	ssmu-walksafe	SSMU WALKSAFE	SSMU WALKSAFE is a volunteer service run and supported by students at McGill University. Their mandate is to accompany clientele to and from any location in the City of Montreal. By using WALKSAFE, students can avoid having to walk alone at night. By providing this service, WALKSAFE is helping to establish a culture of safety in the McGill and Montreal communities.	https://walksafe.ca/	walksafe@ssmu.ca	\N	https://www.facebook.com/SSMUWalksafe	https://www.instagram.com/ssmu_walksafe	2025-02-07 06:15:47.388+00	2025-01-05 17:44:47.579+00	t	\N	\N	\N	\N	\N	\N
245	ssmu-drivesafe	SSMU Drivesafe	DriveSafe is a service run by the Student Society of McGill University. Their volunteers drive students home safely from anywhere on the Island of Montreal for free. They run regular shifts Thursday, Friday, and Saturday nights from 11:00 PM to 3:00 AM, and run at special events including Frosh, Carnival, Grad Ball, etc.	https://linktr.ee/ssmudrivesafe	drivesafe@ssmu.ca	\N	https://www.facebook.com/McGillSSMUDriveSafe	https://www.instagram.com/ssmudrivesafe	2025-02-07 06:16:15.253+00	2025-01-05 17:44:47.148+00	t	\N	\N	\N	\N	\N	\N
243	queer-mcgill	Queer McGill	Queer McGill, in adopting the mantra “For Queer Students, by Queer Students,” promotes and protects Queerness at McGill University and in the greater Montreal community. While Queer McGill is dedicated to serving all those who may face discrimination on the basis of their gender and/or sexuality, Queer McGill does not make determinations of eligibility but instead serves those who self-identify with this description. Queer McGill fulfills this mandate by providing both material and immaterial services including, but not limited to, maintaining a safer space and active presence on campus, participating in political action, representing and advocating for Queer students, and facilitating social activities to strengthen the Queer community. Queer McGill organizes educational campaigns and events while supporting a library and archives of Queer media and information and dispensing Queer-affirming and health-related products to those who want them. Queer McGill carries out its mandate with the utmost commitment to equity and anti-oppression and strives to continually improve itself and its views. 	http://www.twitter.com/queermcgill	admin.qm@gmail.com	\N	https://www.facebook.com/QueerMcGill	https://www.instagram.com/queermcgill	2025-02-07 06:17:57.938+00	2025-01-05 17:44:46.012+00	t	\N	\N	\N	\N	\N	\N
242	uge	Union for Gender Empowerment (UGE)	The Union for Gender Empowerment is a Referral Service of the Students’ Society of McGill University, though they open their doors to all and do not limit services to undergraduate McGill students.	https://theuge.org/	uge@ssmu.ca	\N	https://www.facebook.com/UGEMcGill	https://www.instagram.com/ugecollective	2025-02-07 06:18:32.472+00	2025-01-05 17:44:45.587+00	t	\N	\N	\N	\N	\N	\N
240	psc	Peer Support Centre (PSC)	The Peer Support Centre is a safe space for McGill students to receive support sessions from a peer who is trained in active listening. These sessions are available by drop-in or appointment through their website. Their mission is to provide a confidential, non-judgemental, and non-directional service to our community! We believe everyone deserves the chance to be heard and are privileged to empower our community through their support sessions, mental health advocacy, and education! Drop-in or make an appointment to chat one-on-one with a supporter about anything on your mind.	https://psc.ssmu.ca/	mcgill.psc@gmail.com	\N	https://www.facebook.com/peersupportmcgill	https://www.instagram.com/pscmcgill	2025-02-07 06:20:14.962+00	2025-01-05 17:44:44.612+00	t	\N	\N	\N	\N	\N	\N
251	msa	Muslim Students’ Association (MSA)	The Muslim Students Association brings together Muslim students to provide resources, essential services, and educational tools needed to enhance their university experience. Through the services and events provided, the MSA aims to facilitate the spiritual and social growth of its members, as well as the larger McGill community, supporting diverse student needs. Services provided include: weekly Jum’uah (Friday) prayers, a regularly maintained general prayer space, a student-run Islamic library, halaqas (religious knowledge gatherings), tajweed (Qur’an recitation) classes, social events, community and environmental activities. Past events include the annual MSA Frosh, Ramadan Iftars (dinners), Eid al Fitr & Eid al Adha celebrations, movie screenings, lecture series, information sessions, social awareness campaigns, fundraising dinners, Islam Awareness Week, annual inter-MSA Ski Trip, spoken-word, poetry, comedy, and game nights, as well as open photography exhibitions.	https://msamcgill.com/	msamcgill@ssmu.ca	\N	https://www.facebook.com/MSAMcGill	https://www.instagram.com/msamcgill	2025-02-06 03:31:03.615+00	2025-01-05 17:44:50.047+00	t	\N	\N	\N	\N	\N	\N
249	ssmu-musicians-collective	SSMU Musicians Collective	The Musicians Collective is a service which provides opportunities for musicians at McGill to meet each other. They organize a variety of events throughout the school year, including open mics, workshops, jam sessions, and end of year concerts. These events give students the opportunity to play music, to listen to other McGill students perform, to maybe learn a new instrument, and to meet other like-minded musicians. They also offer a student-teacher referral service, in which students seeking to learn a new instrument or to improve their skills of their current instrument, can reach out to a list of students who are willing to teach them.	\N	muscollective@gmail.com	\N	https://www.facebook.com/ssmumusicianscollective	https://www.instagram.com/ssmumusicianscollective	2025-02-07 06:12:53.4+00	2025-01-05 17:44:48.979+00	f	\N	\N	\N	\N	\N	\N
247	tvm-student-television-at-mcgill	TVM: Student Television at McGill	TVM provides training to learn the basics of filmmaking and media production, as well as video promotion and event coverage free of cost for the McGill and Montreal community. TVM also hopes to help these clubs and organizations promote their events or raise aware for important causes using our services. TVM aims to be a creative outlet for any and all SSMU and PGSS members who wish to express themselves and explore the medium of video production. Lastly, TVM provides its members with an enjoyable place to work, create and learn by encouraging and stimulating growth and professional development. 	https://tvmtelevision.com/	hello@tvmtelevision.com	\N	https://www.facebook.com/TVMTelevision	https://www.instagram.com/tvm.television	2025-02-07 06:15:21.064+00	2025-01-05 17:44:48.016+00	t	\N	\N	\N	\N	\N	\N
259	irsam	International Relations Students’ Association of McGill (IRSAM)	As a federally incorporated, not-for-profit corporation with special consultative status to the Economic and Social Council of the United Nations, IRSAM has something to offer to everyone within the McGill community. From their community outreach programs to Model UN conferences, they have a broad range of events and activities that focus on international relations, the United Nations and local volunteer work.	http://www.irsam.ca/home	internal@irsam.ca	\N	https://www.facebook.com/IRSAMinc	https://www.instagram.com/irsaminc	2025-01-28 14:20:53.916+00	2025-01-05 17:44:56.153+00	t	\N	\N	\N	\N	\N	\N
257	educational-community-living-environment	ECOLE Project	ECOLE (Educational Community Living Environment) is a model of urban sustainable living and a physical hub for the McGill and Montreal sustainability communities. Their mandate is to bring together McGill students, faculty and staff, and Montreal community members in the pursuit of sustainable living by means of applied student research, alternative education, and community building. ECOLE is an ongoing experiment that strives to be a model of urban sustainable living. ECOLE has ten facilitators that live in their physical building and host events and workshops for the greater McGill and Milton Parc communities.	https://www.ecoleproject.com/	ecoleproject@gmail.com	\N	https://www.facebook.com/ECOLEProject	https://www.instagram.com/ecoleproject	2025-02-06 03:19:04.864+00	2025-01-05 17:44:53.045+00	t	\N	\N	\N	\N	\N	\N
255	radio-ckut-903-fm	Radio CKUT 90.3 FM	CKUT 90.3 FM is a non-profit, campus-community radio station based at McGill University. They have been powered by McGill students since they began as the radio club in the 1940s, and a dedicated group of McGill students fought to get them on the FM airwaves in 1987 - and won! CKUT provides alternative music, news and spoken word programming to the city of Montreal, surrounding areas, & around the world 24 hours a day, 365 days a year. Hear them at 90.3 MHz on the FM dial, 91.7 by cable, or listen online at ckut.ca. CKUT is made up of over 200 student and community volunteers working with a staff of coordinators to make creative and insightful radio programming. As a campus-community radio station, CKUT’s mandate is to provide an essential service to those in the Montreal community whose needs are not met by mainstream commercial radio. CKUT functions not only as an alternative to the status quo, but also as a viable community resource. CKUT serves as a training ground for the community and student populations, and in doing so, provides an essential educational and information service to the greater Montreal community. Students can listen to CKUT at 90.3FM on the radio dial, online at ckut.ca or on the go with the free Tune-In App. To get involved, email volunteering@ckut.ca!	https://ckut.ca/	funding@ckut.ca	\N	https://www.facebook.com/RadioCKUT	https://www.instagram.com/ckutmtl	2025-02-06 03:21:46.763+00	2025-01-05 17:44:52.071+00	t	\N	\N	\N	\N	\N	\N
254	the-tribune	The Tribune	The McGill Tribune is an independently published weekly student newspaper. Any McGill student is encouraged to contribute to any of their sections: News, Opinion, SciTech, Sports, Arts & Entertainment, Student Life. Students can also join their Photography, Multimedia or Design sections.	https://www.thetribune.ca/	editor@thetribune.ca	\N	https://www.facebook.com/thetribuneca	\N	2025-02-06 03:22:23.345+00	2025-01-05 17:44:51.455+00	f	\N	\N	\N	\N	\N	\N
253	qpirg-m	Quebec Public Interest Research Group at McGill	The Quebec Public Interest Research Group at McGill is a student-initiated, student-funded, student-run organization that actively works towards social and environmental justice. Through socially-engaged research, popular education, action, advocacy, and their working groups, QPIRG connects McGill students with the greater Montreal community. Using a grassroots, solidarity-based model, QPIRG-McGill is committed to supporting and empowering marginalized communities. They strive to be inclusive and accessible to everyone. Their work is rooted in an anti-oppression analysis and practice. They seek to build campus-community alliances and inspire social change through inclusive and non-hierarchical approaches.	https://qpirgmcgill.org/	info@qpirgmcgill.org	\N	https://www.facebook.com/QPIRG.GRIP.McGill	https://www.instagram.com/qpirgmcgill	2025-02-06 03:23:52.653+00	2025-01-05 17:44:50.983+00	t	\N	\N	\N	\N	\N	\N
266	eus-ski-trip-committee	EUS Ski Trip Committee	EUS Ski Trip is the hottest event of the year. The trip usually takes place over the 3rd weekend in January. 50+ McGill Engineers hop on a coach bus and travel to Mount Saint Anne for 2 days and 2 nights of gnar skiing, snowboarding and fun party times. The EUS Ski Trip is a great opportunity to shred some pow and chill with new or old friends. The event is always a hit and sells out so make sure you buy your ticket early!	https://eus.wiki/EUS_Ski_Trip	ski.trip@mcgilleus.ca	\N	https://www.facebook.com/EUS.ski	\N	2025-01-05 17:44:59.516+00	2025-01-05 17:44:59.516+00	t	\N	\N	\N	\N	\N	\N
267	mec	McGill Engineering Competition (MEC) Committee	The McGill Engineering Competition (MEC) is an annual interdisciplinary event providing all McGill engineering students the opportunity to test their skills in varying competitions. The goal of MEC is to foster relationships between students by providing a setting for professional engineering practice as well as networking opportunities.	https://mec.mcgilleus.ca/	engineering.competition@mcgilleus.ca	\N	https://www.facebook.com/McGillEngComp	\N	2025-01-05 17:45:00.295+00	2025-01-05 17:45:00.295+00	t	\N	\N	\N	\N	\N	\N
270	the-plumbers-faucet	The Plumber's Faucet	The Plumber's Faucet is a satirical publication written by and for engineering students. The Faucet covers topics from on-campus events, the life of an engineering student, to the basic rigmarole of being a human bean. The Faucet is usually around 16 pages, published every 6 weeks or so, and can be found in the stands around engineering buildings and more.	https://faucet.mcgilleus.ca/	faucet@mcgilleus.ca	\N	https://www.facebook.com/ThePlumbersFaucet	\N	2025-01-05 17:45:01.916+00	2025-01-05 17:45:01.916+00	t	\N	\N	\N	\N	\N	\N
272	brewing-club	Brewing Club	The Brewing Club is a student organization within the EUS that focuses on the fermentation of various beverages and food. This club is meant to provide an interesting and enjoyable outlet for engineering students who want to explore process engineering and biologics manufacturing through the production of fermented beverages and foods, such as kombucha and ginger beer. Brewing club aims to provide members with opportunities to apply classroom knowledge, research methods, and practical learning to plan and record the steps for brewing drinks with certain desired characteristics. Detailed notes on production will be kept and organized by the club, and every batch will be tested for consistency and repeatability of results.	https://brewingclub.mcgilleus.ca/	brewingclub@mcgilleus.ca	\N	https://www.facebook.com/mcgillbrewing	\N	2025-01-05 17:45:02.743+00	2025-01-05 17:45:02.743+00	t	\N	\N	\N	\N	\N	\N
276	mcgill-artificial-intelligence-society	McGill Artificial Intelligence Society	McGill Artificial Intelligence Society, or McGill AI, aims to foster interest in AI through teaching, sharing, and competition, to connect with industry in a collaborative manner, and to provide a passionate AI community within McGill University that is accessible to all, regardless of background or experience.	https://mcgillai.com/	mcgillaicontact@gmail.com	\N	https://www.facebook.com/McGillAI	https://www.instagram.com/mcgillaisociety	2025-01-05 17:45:04.461+00	2025-01-05 17:45:04.461+00	t	\N	\N	\N	\N	\N	\N
274	engineering-investment-group	Engineering Investment Group	The Engineering Investment Group aims to bridge the gap between engineering and finance by providing opportunities for engineering students to learn about the ever-changing world of finance. They educate engineering students through real-life investment activities and events. They wish to create a community of finance oriented individuals to share their thoughts and challenge each other’s ideas. The key objectives of the group are to showcase the merit of McGill Engineering students to large financial institutions and for members to both gain and demonstrate investment skills and knowledge.	http://eig.mcgilleus.ca/	eig.president@mcgilleus.ca	\N	https://www.facebook.com/McGillEIG	\N	2025-01-28 06:56:25.867+00	2025-01-05 17:45:03.603+00	f	\N	\N	\N	\N	\N	\N
273	canadian-society-for-civil-engineering	Canadian Society for Civil Engineering	The Canadian Society for Civil Engineering is a national professional society whose membership is comprised of practicing civil engineers, corporations, professors, and students like you. The society promotes professional development, exchange of knowledge, public awareness, and networking in the field of Civil Engineering. CSCE McGill Chapter connects students to the professional engineering world through construction site tours, guest speakers, industry tours and seminars. Membership is free!	https://www.mcgill.ca/civil/students/csce	csce@mcgilleus.ca	\N	https://www.facebook.com/CSCEmcgill	\N	2025-01-28 06:56:55.886+00	2025-01-05 17:45:03.171+00	t	\N	\N	\N	\N	\N	\N
271	the-plumbers-ledger	The Plumber's Ledger	The Plumber's Ledger is the non-satirical student publication of the McGill Engineering Undergraduate Society, falling within the Communications portfolio. Founded in 2012, this publication serves as a platform for engineering student voices, covering a diverse range news and culture with specific emphasis on what is relevant to McGill engineering and engineers. The Plumber's Ledger maintains a close relationship with its less-serious sister EUS publication, the Plumber's Faucet.	http://ledger.mcgilleus.ca/	ledger@mcgilleus.ca	\N	https://www.facebook.com/ThePlumbersLedger	\N	2025-01-28 06:57:28.949+00	2025-01-05 17:45:02.311+00	f	\N	\N	\N	\N	\N	\N
269	seam	Sustainability in Engineering at McGill	Sustainability in Engineering at McGill, is a committee within the Engineering Undergraduate Society. The committee was formally founded in 2014. SEAM's purpose is to foster and promote a culture of sustainability in the Engineering community. SEAM's main efforts are planning events, managing projects, providing consulting work, and offering sustainability resourcesto the McGill Engineering community.	http://seam.mcgilleus.ca/	seam.chair@mcgilleus.ca	\N	https://www.facebook.com/sustainability.eus	\N	2025-01-28 06:58:46.873+00	2025-01-05 17:45:01.259+00	t	\N	\N	\N	\N	\N	\N
268	o-week-committee-engineering	O-week Committee Engineering	Engineering Orientation-week, or O-week, or more generally Frosh, is an event for entering students filled with enjoyable activities, networking sessions to meet new students and Dank Memes. There are plenty of ways to become involved beyond first year!	https://frosh.mcgilleus.ca/	oweek@mcgilleus.ca	\N	https://www.facebook.com/EngineeringFrosh	\N	2025-01-28 06:59:55.965+00	2025-01-05 17:45:00.699+00	t	\N	\N	\N	\N	\N	\N
265	engineering-peer-tutoring-service	Engineering Peer Tutoring Service	The Engineering Peer Tutoring Service, or EPTS, offers free tutoring of U0 and U1 classes for engineering students. Their tutors go through a rigorous selection process and are able to provide students with the help that they need. All of their tutors are undergraduate students that have taken the courses that they are tutoring. They hold weekly drop in hours in FDA 6B as well as midterm and final exam review sessions. Whether you need help with an assignment, study for an exam or sharpen your skills, EPTS is for you!	https://epts.mcgilleus.ca/	epts@mcgilleus.ca	\N	https://www.facebook.com/epts.mcgill	\N	2025-01-28 14:16:34.483+00	2025-01-05 17:44:59.095+00	t	\N	\N	\N	\N	\N	\N
284	mcgill-formula-electric	McGill Formula Electric	McGill Formula Electric is an engineering design team that designs, manufactures, and competes a formula-style, open wheel, electric prototype with a full CFRP monocoque. The team strives to understand, develop, and implement the latest in green technology in order to produce the most competitive electric prototype and to be able to enter the workforce equipped to engineer a more sustainable future. This project stems from the continuous improvements made over the course of 20 years in McGill’s FSAE Chapter, and even a merger between two very competitive teams.	https://www.mcgillformulaelectric.com/	fsae@mail.mcgill.ca	\N	https://www.facebook.com/FSAE	https://www.instagram.com/mcgillformulaelectric	2025-01-05 17:45:09.215+00	2025-01-05 17:45:09.215+00	t	\N	\N	\N	\N	\N	\N
289	copi-eus	Copi-EUS	CopiEUS is your one stop shop for anything related to printing (except for 3D Printing, that would be The Cube). Located in the EUS Mall in McConnell Engineering, CopiEUS is one of four major Services offered by the EUS. CopiEUS has two black and white laser printers, one color laser printer, and two HP plotters for large-format printing. In addition, it offers coil binding services, coursepacks for McGill classes, blank notebooks, lamination, faxes, and employees who are able and willing to work with you to best determine how to meet your printing needs.	http://www.copieus.mcgilleus.ca/	copieus@mcgilleus.ca	\N	https://www.facebook.com/copieusmcgill	https://www.instagram.com/copi_eus	2025-01-05 17:45:11.71+00	2025-01-05 17:45:11.71+00	t	\N	\N	\N	\N	\N	\N
286	mcgill-robotics	McGill Robotics	McGill Robotics is an engineering design team that builds robots for international competitions as well as organizes a robotics themed hackathon annually. The team’s goal is to foster an interest in robotics through competition, cultivate a relationship with the surrounding Montreal community, and much closer to home, to create a core community at McGill. They prioritize team bonding and growth along with engineering accomplishment, with the belief that it takes a solid team to build a winning robot. McGill Robotics currently fosters four technical projects – AUV, Drone, Mars Rover, RoboHacks – and one Business Team, who oversees team Finances, Sponsorship, Marketing and Outreach Events.	https://mcgillrobotics.com/	\N	\N	https://www.facebook.com/mcgillrobotics	https://www.instagram.com/mcgillrobotics	2025-01-28 06:48:37.005+00	2025-01-05 17:45:10.23+00	t	\N	\N	\N	\N	\N	\N
285	mini-baja-racing	Mini Baja Racing	McGill Baja has a proud history full of hard work, friendship, ingenuity and sweat. From sleepless nights to Jacquelin’s Sugar Shack Challenge, they have experienced it all over the years. The Baja Racing Team has competed in Kentucky, Quebec City, Peoria, and plenty of other exciting areas!	https://eus.wiki/Mini_Baja_Racing	baja@mcgilleus.ca	\N	https://www.facebook.com/mcgillbaja	https://www.instagram.com/mcgill_baja	2025-01-28 06:51:11.001+00	2025-01-05 17:45:09.645+00	t	\N	\N	\N	\N	\N	\N
283	concrete-canoe	Concrete Canoe	Concrete Canoe designs, builds, and races a winning concrete canoe…. no, there is no typo here, they make a canoe entirely out of concrete!	https://canoe.mcgilleus.ca/	concrete.canoe@mcgilleus.ca	\N	https://www.facebook.com/CanoeMcgill	https://www.instagram.com/mcgillconcretecanoe	2025-01-28 06:52:27.479+00	2025-01-05 17:45:08.823+00	t	\N	\N	\N	\N	\N	\N
282	mcgill-chem-e-car	McGIll Chem-E Car	Chem-E Car is a group of university students who wish to participate in a design team. The chemical engineering background shared by much of their team leads them to look past conventional engineering competitions. Thus, they decided to participate in the AIChE Chem-E Car competition for the first time in March 2014.	https://www.mcgill.ca/engineeringdesign/design-teams/mcgill-chem-e-car	chemecar@mcgilleus.ca	\N	https://www.facebook.com/McGillChemECarTeam	https://www.instagram.com/mcgill.chemecar	2025-01-28 06:53:51.403+00	2025-01-05 17:45:08.437+00	t	\N	\N	\N	\N	\N	\N
281	mcgill-bridge-building-team	McGill Bridge Building Team	The McGill Bridge Building Team is an engineering design team that centers on designing and building bridges in either wood or steel for multiple engineering competitions. They welcome undergraduate students from diverse backgrounds to join us in managing exciting challenges through unique solutions. Their holistic mission is to provide our team members with practical, hands-on design experience to strengthen their understanding of in-class concepts, and foster creativity.	https://eus.wiki/Bridge_Building	bridgebuilding@mcgilleus.ca	\N	https://www.facebook.com/McGillBridgeBuildingTeam	https://www.instagram.com/bridgebuildingmcgill	2025-01-28 06:54:24.826+00	2025-01-05 17:45:07.959+00	t	\N	\N	\N	\N	\N	\N
280	student-energy-at-mcgill-university	Student Energy at McGill University	Student Energy at McGill empowers students to take action and shape their energy future in their communities. With Student Energy's organizational knowledge that facilitates students around the world sharing knowledge with one another, they are able to organize and host events, panels, and projects to create space for youth to have an impact.	https://studentenergy.org/chapter/mcgill-university	studentenergy@mcgilleus.ca	\N	https://www.facebook.com/studentenergyatmcgill	https://www.instagram.com/studentenergyatmcgill	2025-01-28 06:54:42.91+00	2025-01-05 17:45:07.099+00	t	\N	\N	\N	\N	\N	\N
279	queer-engineer	Queer Engineer	Queer Engineer is an EUS club at McGill University that strives to provide a safe and welcoming environment for gender and sexual minorities, both within the Faculty of Engineering and McGill as whole. QE welcomes all gay, lesbian, bisexual, asexual, trans, queer and allied students, and students with a variety of sexual and/or gender identities outside of those labels.	https://eus.wiki/Queer_Engineer	queer.engineer@mcgilleus.ca	\N	https://www.facebook.com/QueerEngineerMcGill	https://www.instagram.com/queerengineermcgill	2025-01-28 06:54:57.418+00	2025-01-05 17:45:06.447+00	t	\N	\N	\N	\N	\N	\N
278	mcgill-students-flying-club	McGill Students' Flying Club	In a short span, McGill Students' Flying Club has become one of Canada’s largest student-run aviation organizations. Operating from McGill University in Montreal, McGill Students' Flying Club provides a platform for its members to engage in flight training and other aviation-related activities. Their mission is to promote aviation and aerospace fields and foster a growing community of pilots and aviation enthusiasts.\n	http://mcgillflyingclub.com/	mcgillflyingclub@gmail.com	\N	https://www.facebook.com/McgillStudentsFlyingClub	https://www.instagram.com/mcgillflyingclub	2025-01-28 06:55:16.171+00	2025-01-05 17:45:05.431+00	t	\N	\N	\N	\N	\N	\N
290	bugs	Biochemistry Undergraduate Society (BUGS)	BUGS is a student-run organization that represents McGill's biochemistry undergraduate population. BUGS organizes a variety of social and academic events for biochemistry students and the general student body throughout the year.	https://bugs.sus.mcgill.ca	bugs@sus.mcgill.ca	\N	https://www.facebook.com/biochemundergradmcgill	\N	2025-01-05 17:54:45.932+00	2025-01-05 17:54:45.932+00	t	\N	\N	\N	\N	\N	\N
301	meus	Materials Engineering Undergraduate Society (MEUS)	The Materials Engineering Undergraduate Society (MEUS) is a student run organization that strives to improve the experience of undergraduates in the department of Material Engineering at McGill. MEUS organizes social, academic and industry related events, and acts as a liaison between the faculty and undergraduates.	https://www.linkedin.com/company/mcgillmeus	\N	\N	https://www.facebook.com/McGillMEUS	\N	2025-01-05 17:54:52.557+00	2025-01-05 17:54:52.557+00	t	\N	\N	\N	\N	\N	\N
298	mess	McGill Environment Students Society (MESS)	The McGill  Environment Students' Society logo Environment Students’ Society represents undergraduate and diploma Environment students at McGill University.\n\nMESS holds a variety of events each year of both academic and social focuses.	\N	mcgill.environment@gmail.com	\N	https://www.facebook.com/messmcgill	\N	2025-01-28 06:43:42.49+00	2025-01-05 17:54:50.238+00	t	\N	\N	\N	\N	\N	\N
297	num	Neuroscience Undergraduates of McGill (NUM)	The Neuroscience Undergraduates of McGill council is a student organization dedicated to serving the needs and wants of McGill Neuroscience students and other neuroscience enthusiasts. Hosting events, organizing a buddy mentorship program and providing students with support and resources are just some of the ways we go about achieving this.\n\nThroughout the year, we host academic and social events. These events include, but are not limited to: annual Meet & Greet with fellow neuroscience students, Buddy bonding events, Meet the Professor events, apartment crawls, career information sessions, trivia nights and Wine & Cheese events.	http://num.sus.mcgill.ca	num@sus.mcgill.ca	\N		\N	2025-01-28 06:44:04.384+00	2025-01-05 17:54:49.503+00	t	\N	\N	\N	\N	\N	\N
296	sums	Society of Undergraduate Mathematics Student (SUMS)	SUMS represents the undergraduate mathematics community at McGill University.	https://sumsmcgill.ca	sums@math.mcgill.ca	\N		\N	2025-01-28 06:44:15.982+00	2025-01-05 17:54:49.141+00	t	\N	\N	\N	\N	\N	\N
295	mugs	McGill Undergraduate Geography Society (MUGS)	MUGS stands for McGill Undergraduate Geography Society. As a Geography student, be it a Major, Minor, Honours, or Urban Systems student, you are considered a part of our tight knit MUGS community. This means you are invited to all MUGS events and exec meeting, to have your say in any undergraduate-related decision happening in the department. There is also an executive, which consists of students, elected by all MUGS members, who are tasked with many things throughout the year, including planning events, liaising with the department and other departmental groups, keeping the lounge clean and tidy, and more!	http://mcgillgeography.blogspot.com	mcgillgeography@gmail.com	\N		https://www.instagram.com/mcgillgeography	2025-01-28 06:44:40.406+00	2025-01-05 17:54:48.713+00	t	\N	\N	\N	\N	\N	\N
294	csus	Computer Science Undergraduate Society  (CSUS)	The CSUS is an elected student group tasked with improving student academics and life in the computer science department. This includes discussing course changes with faculty, organizing events, collating student feedback, and promoting a sense of community.	https://mcgill-csus.ca	csus@cs.mcgill.ca	\N		\N	2025-01-28 06:44:53.238+00	2025-01-05 17:54:48.146+00	t	\N	\N	\N	\N	\N	\N
293	mbsu	McGill Biology Student Union (MBSU)	The McGill Biology Student Union represents all McGill Biology students pursuing their Major, Honours, Liberal, or Minor degree to help you get the most out of your undergrad.	https://www.mbsu.sus.mcgill.ca	thembsu@gmail.com	\N	https://www.facebook.com/McGillBiology	https://www.instagram.com/mbsumcgill	2025-01-28 06:45:24.725+00	2025-01-05 17:54:47.554+00	t	\N	\N	\N	\N	\N	\N
292	aossum	Atmospheric and Oceanic Sciences Society of Undergraduates at McGill (AOSSUM)	Atmospheric and Oceanic Sciences Society of Undergraduates at McGill is the officially recognized council representing the atmospheric and oceanic science (AOS) undergraduates. It is involved in helping undergrads in academic issues, addressing problems, organizing events, and promotion of the AOS department.\n\nThe diverse blend of courses in AOS explore many topics throughout the study of weather and climate. Whether you’re interested in waves and fluid dynamics, the connection between the air and ocean, or the kind of weather that turns wild and destructive, the spectrum is vast and each professor you meet has spent their lives looking into specific areas of the atmosphere.	https://web.meteo.mcgill.ca/aossum	mumsa@meteo.mcgill.ca	\N	https://www.facebook.com/AOSSUM	https://www.instagram.com/aossum	2025-01-28 06:45:44.748+00	2025-01-05 17:54:47.111+00	t	\N	\N	\N	\N	\N	\N
291	misa	Microbiology and Immunology Students' Association (MISA)	The Microbiology and Immunology Student Association (MISA) represents all undergraduate students in the Department of Microbiology and Immunology at McGill University. They act as a liaison between staff, faculty, and students of the Department at a Departmental and Faculty level.  \n\n \n\nMISA aims to enhance the education and social aspects of all members, and to create an inclusive environment in all endeavors and initiatives – both academic and social.	https://misa.ssmu.ca	misacouncil@gmail.com	\N		https://www.instagram.com/misamcgill	2025-01-28 06:45:59.63+00	2025-01-05 17:54:46.342+00	t	\N	\N	\N	\N	\N	\N
311	the-refugee-centre-mcgill-chapter	The Refugee Centre McGill Chapter	Montreal is a city full of diversity, made of people from all over the world like refugees and migrants. They aim to provide a sustainable structure of integration for refugees and migrants in McGill as well as to offer support for students and their families by creating frameworks for socializing and building a community within McGill as well as the wider Montreal community. They also aim to promote the education of the student body and the public on refugee and migrant issues and ways to productively support and advocate for refugees and migrants.	https://www.therefugeecentre.org	trcmcgill@ssmu.ca	\N	https://www.facebook.com/The-Refugee-Centre-McGill-Chapter-104216648698140	https://www.instagram.com/trc_mcgill	2025-01-28 01:09:05.952+00	2025-01-05 17:55:02.616+00	f	\N	\N	\N	\N	\N	\N
310	foundation-for-international-medical-relief-of-children	McGill Students for FIMRC (Foundation for International Medical Relief of Children)	FIMRC McGill works toward helping local people in need as well as fundraising for trips abroad. Throughout the school year, they take part in many different fundraising events. With the money they raise, they fund projects across countries in need. They also help locally, volunteering at homeless shelters every week. Any McGill student is welcome to join on Fridays as they cook, socialize, and spend time with the less fortunate of Montreal.	https://www.fimrc.org	fimrc.mcgill@gmail.com	\N	https://www.facebook.com/McGill.FIMRC	https://www.instagram.com/fimrc.mcgill	2025-01-28 01:10:27.586+00	2025-01-05 17:54:59.857+00	f	\N	\N	\N	\N	\N	\N
309	ssmu-powerlifting-club	SSMU Powerlifting Club	The SSMU Powerlifting Club is a student society at McGill dedicated to strength training. The club caters both to competitive athletes, those who are looking to learn or progress in a new sport as well as those who enjoy lifting weights at the gym to get fit and stronger! Their goals are to build a social community of people who share a passion in lifting heavy weights, setting goals at the gym and of course, eating a lot of food. They offer their members a chance to make new friends and have a good time at the gym while reaching their goals.	\N	powerliftingclub@ssmu.ca	\N		https://www.instagram.com/ssmupowerlifting	2025-01-28 01:11:07.468+00	2025-01-05 17:54:58.216+00	t	\N	\N	\N	\N	\N	\N
308	ssmu-football-enthusiasts-club	SSMU Football Enthusiasts’ Club	They are a student-run club at McGill University that aims to bring together soccer (football) fans on campus. They hold events where soccer fans can come together and share in their enjoyment of this beautiful sport, such as watch parties and pick-up soccer games.	\N	fec@ssmu.ca ssmufec@gmail.com	\N		https://www.instagram.com/ssmufec	2025-01-28 01:11:25.88+00	2025-01-05 17:54:57.839+00	f	\N	\N	\N	\N	\N	\N
307	mcgill-table-tennis-club	McGill Table Tennis Club	The McGill Table Tennis Club aims to increase exposure for the sport of table tennis in the McGill community as well as foster a friendly, yet competitive environment for players of all skill levels to improve at the sport. They host practice sessions once a week where you can drop-in whenever you have time and either play with friends or seek guidance from one of their practice coordinators who can help you improve.	\N	mcgilltabletennis@ssmu.ca	\N	https://www.facebook.com/groups/159427097309/	\N	2025-01-28 01:12:27.303+00	2025-01-05 17:54:57.284+00	t	\N	\N	\N	\N	\N	\N
306	mcgill-badminton-club	McGill Badminton Club	The McGill Badminton Club strives to create an encouraging atmosphere where members of all levels feel welcome playing together; whether you are looking for a recreational or a competitive environment. They are currently not offering drop-ins but instead, they will be hosting a semester-long tournament collaborating with the McGill Intramurals team.	https://recreation.mcgill.ca/intra-sports/badminton	mcgillbadmintonclub@ssmu.ca	\N		https://www.instagram.com/mcgillbadminton	2025-01-28 03:08:10.094+00	2025-01-05 17:54:55.588+00	t	\N	\N	\N	\N	\N	\N
305	flag-football-club	Flag Football Club	The McGill Flag Football club is an intramural league of teams that compete recreationally during a semester-long season in the fall. Register to meet like-minded, athletic peers! Whether you are a beginner or an "I definitely could have gone pro if I wanted to" type of player, compete alongside your team for the renowned MUG.	https://recreation.mcgill.ca/intra-sports/flag-football	\N	\N	https://www.facebook.com/profile.php	https://www.instagram.com/flagfootball_mcgill	2025-01-28 03:21:12.741+00	2025-01-05 17:54:55.219+00	f	\N	\N	\N	\N	\N	\N
304	dragon-boat-z	Dragon Boat Z	McGill Dragon Boat Z is a student-run dragon boat team, where members train weekly indoors at a paddling pool during the fall and winter semesters and outdoors starting in May to prepare for competitions. They compete against post-secondary schools from Montreal and Ontario, as well as many other community teams within Quebec.	https://linktr.ee/dragonboatz	dragonboatz@ssmu.ca	\N	https://www.facebook.com/dragonboatz	https://www.instagram.com/dragonboatz	2025-01-28 03:21:45.726+00	2025-01-05 17:54:54.867+00	t	\N	\N	\N	\N	\N	\N
317	mcgill-product-management-association	McGill Product Management Association	The McGill Product Management Association is Montreal’s first product management club/association dedicated to raising awareness about PM, teaching people key PM skills, giving members confidence in PM job search, and to building a community of aspirational product managers.	\N	mpma@musmcgill.ca	\N	https://www.facebook.com/mpma.mcgill	https://www.instagram.com/mpma.mcgill	2025-01-05 17:55:08.101+00	2025-01-05 17:55:08.101+00	t	\N	\N	\N	\N	\N	\N
323	gsa-german-students-association	GSA – German Students’ Association	The German Students' Association of McGill University, Montreal	\N	gsamcgill@gmail.com	\N	https://www.facebook.com/groups	\N	2025-01-05 17:55:11.613+00	2025-01-05 17:55:11.613+00	t	\N	\N	\N	\N	\N	\N
325	mira-mcgill-industrial-relations-association	MIRA – McGill Industrial Relations Association	The Industrial Relations Association of McGill University, Montreal	https://miraaus.wixsite.com/home	mira.aus@gmail.com	\N	https://www.facebook.com/mcgillindustrialrelations	\N	2025-01-05 17:55:12.378+00	2025-01-05 17:55:12.378+00	f	\N	\N	\N	\N	\N	\N
324	hsa---history-students-association	HSA - History Students’ Association	The HSA is the History Students’ Association. They represent all History students including those pursuing Minors, Majors, Honours and Joint Honours programs as well as any McGill students enrolled in at least one history class. The HSA exists to foster camaraderie, networking, and friendship among history students through fun events, peer support, and advising.	https://hsamcgill.com	mcgill.hsa.president@gmail.com	\N		https://www.instagram.com/mcgill_hsa	2025-01-28 00:57:51.716+00	2025-01-05 17:55:11.978+00	t	\N	\N	\N	\N	\N	\N
322	mess-mcgill-environment-students-society	MESS – McGill Environment Students’ Society	The McGill Environment Students' Society logo Environment Students’ Society represents undergraduate and diploma Environment students at McGill University.	https://www.mcgill.ca/environment/current-students/mess	mcgill.environment@gmail.com	\N		\N	2025-01-28 00:58:26.448+00	2025-01-05 17:55:11.146+00	t	\N	\N	\N	\N	\N	\N
321	esa-economics-students-association	ESA – Economics Students’ Association	If you study economics at McGill University, they are your student association. The Economics Students’ Association is an on-campus student organization mandated to enhance the student experience for those of us studying economics at McGill University.	\N	esamcgill@gmail.com	\N		https://www.instagram.com/esamcgill	2025-01-28 01:00:25.388+00	2025-01-05 17:55:10.579+00	t	\N	\N	\N	\N	\N	\N
320	eassa-east-asian-studies-students-association	EASSA – East Asian Studies Students’ Association	The undergraduate student association for those at McGill University’s Department for East Asian Studies.	https://eassamcgill.wixsite.com/home	eassamcgill@gmail.com	\N		https://www.instagram.com/eassa_mcgill	2025-01-28 01:00:49.932+00	2025-01-05 17:55:10.223+00	t	\N	\N	\N	\N	\N	\N
319	csaus-canadian-studies-association-of-undergraduate-students	CSAUS – Canadian Studies Association of Undergraduate Students	The Canadian Studies Association of Undergraduate Students (CSAUS) represents undergraduate students both to the MISC and the AUS. They run events for students in Canadian Studies but welcome those from all departments with an interest in Canada! CSAUS also edits and organizes the annual undergraduate Canadian Studies journal, Canadian Content.	https://www.csausmcgill.com	csaus.exec@gmail.com	\N		\N	2025-01-28 01:01:12.596+00	2025-01-05 17:55:09.431+00	t	\N	\N	\N	\N	\N	\N
318	ahcssa-art-history-and-communication-studies-students-association	AHCSSA – Art History and Communication Studies Students’ Association	The Art History and Communication Studies Student Association aims to work as a liaison between students, professors, and the broader cultural community. The association also looks to function as a resource for department students to facilitate their social and academic well-being.	\N	ahcssamcgill@gmail.com	\N	https://www.facebook.com/groups/115224378568412	\N	2025-01-28 01:01:51.502+00	2025-01-05 17:55:08.867+00	t	\N	\N	\N	\N	\N	\N
316	pennydrops	PennyDrops	PennyDrops is a registered not-for-profit organization dedicated to the advancement of financial education in Canada. They work to increase the level of financial literacy nationwide, foster a community of shared intellectual resources and bridge the financial literacy gap currently experienced by youth.	https://www.pennydrops.org	contact@pennydrops.org	\N	https://www.facebook.com/McGillPD	https://www.instagram.com/pennydrops.official	2025-01-28 01:02:22.866+00	2025-01-05 17:55:07.36+00	t	\N	\N	\N	\N	\N	\N
315	mcgill-marketing-network	McGill Marketing Network	The McGill Marketing Network is a student-run organization which provides students passionate about marketing various professional growth, community-building, and learning opportunities. From conducting informational webinars and sharing relevant job postings to hosting networking sessions with experts from the industry, they bring together the right mix of resources and industry expertise to help students succeed in their professional life, and beyond.	\N	mmn@mus.mcgill.ca	\N	https://www.facebook.com/McGillMarketingNetwork	https://www.instagram.com/musmarketingnetwork	2025-01-28 01:02:41.464+00	2025-01-05 17:55:06.476+00	f	\N	\N	\N	\N	\N	\N
314	international-management-association	International Management Association	The International Management Association is a platform where the students, faculty and alumni of the Major in International Management Program can meet and interact with one another. They aim to provide networking opportunities and self-developing resources as well to create a stronger student body for both International Management students and those passionate about the field of international business. They will also serve as a bridge between students and the faculty, representing the students’ perspectives in various issues in order to help shape the future of the program.	\N	ima@mus.mcgill.ca	\N	https://www.facebook.com/InternationalManagementAssociationhttps	https://www.instagram.com/mcgill_ima	2025-01-28 01:03:09.342+00	2025-01-05 17:55:05.357+00	t	\N	\N	\N	\N	\N	\N
313	desautels-accounting-society	Desautels Accounting Society	DAS serves as the liaison between accounting firms, the CPA Order and McGill’s accounting students. They take on the responsibility of organizing all accounting recruitment-related activities within the faculty with a strong commitment to ensure that students are well prepared for a future in the accounting field.	https://dasmcgill.ca	president@dasmcgill.ca	\N	https://www.facebook.com/das.mcgill	https://www.instagram.com/das.mcgill	2025-01-28 01:03:33.333+00	2025-01-05 17:55:03.826+00	t	\N	\N	\N	\N	\N	\N
329	enactus-mcgill	Enactus McGill	Enactus McGill is a group of talented and motivated students from McGill University striving to make a difference in the Montreal community through entrepreneurial action. They strive to create a long-term impact on the communities and businesses that they are involved with. Whether it be by providing education to Syrian refugees, empowering young students to become entrepreneurs, or decreasing the food insecurity in Montreal, their projects reach a diverse community both locally and nationally. Their ultimate vision is to enact positive change through social entrepreneurship. In other words, they envision a brighter future where local communities are improved through their impactful projects, empowering events, and engagement with community partners.	https://enactusmcgill.ssmu.ca	mcgillenactus@gmail.com	\N	https://www.facebook.com/enactusmcgill	https://www.instagram.com/enactusmcgill	2025-01-05 17:55:17.35+00	2025-01-05 17:55:17.35+00	t	\N	\N	\N	\N	\N	\N
336	falun-dafa-at-mcgill	Falun Dafa at McGill	Falun Dafa at McGill aims to provide McGill community with an environment to learn and practice Falun Dafa, as well as bring awareness to the current on-going persecution experiences by practitioners in mainland China.	https://falundafa-mcgill.com	falundafa.mcgill@gmail.com	\N	https://www.facebook.com/falundafa.mcgill	\N	2025-01-05 17:55:28.421+00	2025-01-05 17:55:28.421+00	t	\N	\N	\N	\N	\N	\N
337	lotus-dance-initative	Lotus Dance Initative	Lotus Dance Initiative promotes mental health by raising awareness through themed dance and wellness workshops. They offer non-dancers the ability to reap the mental and physical benefits of dance and fitness. Join them to release stress, connect with your body, and make new friends through dance and fitness!	https://lotusdanceinitiative.ca	lotus@ssmu.ca	\N		https://www.instagram.com/lotusinitiative.mcgill	2025-01-28 00:48:49.513+00	2025-01-05 17:55:28.785+00	t	\N	\N	\N	\N	\N	\N
335	chsp	Comparative Healthcare Systems Program	The Comparative Healthcare Systems Program is a public & global health based student group at McGill University in Montreal, Canada. Through various initiatives, like conferences, lectures and international exchange programs, they provide opportunities for students to get engaged in the study of public health and comparative healthcare. They believe that their hands-on approach to healthcare systems allows for the best understanding of how they work, and can pave the way for meaningful and substantive improvement.	https://mcgillchsp.wixsite.com/chsp	mcgill.chsp@gmail.com	\N	https://www.facebook.com/pg	\N	2025-01-28 00:53:17.056+00	2025-01-05 17:55:28.022+00	f	\N	\N	\N	\N	\N	\N
334	mssd	McGill Student Street Dancers	The McGill Student Street Dancers club strives to foster a positive and inclusive community of street dancers (i.e. bboys, poppers, lockers, waackers etc.) at McGill University, at any skill level. MSSD aims to organize and provide on-campus practice sessions and street dance events, as well as connect its members to the wider Montreal dance scene.	\N	mssdclub@gmail.com	\N		https://www.instagram.com/MSSDclub	2025-01-28 00:53:38.532+00	2025-01-05 17:55:24.214+00	f	\N	\N	\N	\N	\N	\N
333	mcgill-choral-society	McGill Choral Society	One of the largest student groups on the McGill campus, the McGill Choral Society gives members of the University community the chance to explore and enjoy making music together. Each year, they perform two major classical choral works accompanied by a small orchestra and professional soloists. Their audiences range from 500 to 1000 people! In the second half of their concerts, they perform a selection of seasonal and popular music. There are no auditions and sight-reading skills are not required, but all are encouraged to give their heart and voice to the joy of making music. Through benefit concerts, the choir has raised significant funds for groups such as the McGill Aids Centre, the Farha Foundation, Sun Youth and the McGill Assault Centre, and to support research into Lou Gehrig’s disease and lymphedema.	https://www.mcgillchoral.ca	mcgillchoral@ssmu.ca	\N		\N	2025-01-28 00:54:29.345+00	2025-01-05 17:55:23.612+00	t	\N	\N	\N	\N	\N	\N
332	les-muses-chorale	Les Muses Chorale	Les Muses Chorale is a women’s choral ensemble affiliated with the SSMU. They began in 2001 as “Simply Sweetly,” a group of talented young women who created a McGill club to express their passion for fun and challenging choral music. Now in their 20th season, Les Muses Chorale is proud to be a vibrant ensemble dedicated to choral excellence.	https://lesmuseschorale.wordpress.com	lesmuseschorale@ssmu.ca	\N	https://www.facebook.com/LesMusesChorale	https://www.instagram.com/lesmuseschorale	2025-01-28 00:54:58.486+00	2025-01-05 17:55:23.013+00	t	\N	\N	\N	\N	\N	\N
331	mcgill-undergraduates-for-communication-disorders-awareness	McGill Undergraduates for Communication Disorders Awareness	McGill Undergraduates for Communication Disorders Awareness is an on-campus organization made up of undergraduate students from across disciplines, dedicated to raising awareness for individuals with communication disorders. Formed in January 2017, MUCDA is McGill University’s first club dedicated to raising awareness for this underrepresented cause.	https://speechlangmcgill.wixsite.com/mucda	mucda@ssmu.ca	\N	https://www.facebook.com/mcgill.ucda	https://www.instagram.com/mcgill.ucda	2025-01-28 00:55:16.978+00	2025-01-05 17:55:19.514+00	t	\N	\N	\N	\N	\N	\N
330	mcgill-students-for-geriatric-health	McGill Students for Geriatric Health	The mission of McGill Students for Geriatric Health is to raise awareness, create a dialogue, and establish connections with volunteer organizations on the subject matter of geriatric healthcare.	https://geriatrichealth.ssmu.ca	mcgillgeriatrichealth@ssmu.ca	\N	https://www.facebook.com/msghmcgill	https://www.instagram.com/mcgillgeriatrichealth	2025-01-28 00:55:37.981+00	2025-01-05 17:55:18.795+00	t	\N	\N	\N	\N	\N	\N
328	girls-for-ghana	Girls For Ghana	Girls for Ghana is a student-run club with the main goal of fundraising on behalf of the Create Change Foundation. The Create Change Foundation is a registered Canadian non-profit that focuses on empowering girls in Ghana through education and leadership, allowing them to help their families and communities out of poverty. Their mission is to lead a self-sufficient model of charity that is run by empowered youth. They host various fundraisers throughout the year, as well as guest speaker panels and social events. This club is a safe space for all McGill students to learn more about the importance of women’s education, gain leadership experience, and help grant others the same opportunities that we are so privileged to have.	https://www.createchangenow.ca	girlsforghana@ssmu.ca	\N	https://www.facebook.com/girlsforghanamcgill	https://www.instagram.com/girlsforghanamcgill	2025-01-28 00:56:15.67+00	2025-01-05 17:55:15.615+00	t	\N	\N	\N	\N	\N	\N
346	mcgill-blockchain-association	McGill Blockchain Association	Blockchain at McGill is a student run educational group that aims to raise awareness and foster engagement in the field of Blockchain and it’s related technologies. BAM accelerates it’s members to become leaders in the industry by providing them with relevant experience and fostering industry connections.	https://www.blockchainatmcgill.xyz	blockchain@ssmu.ca	\N	https://www.facebook.com/blockchainatmcgill	https://www.instagram.com/blockchain_mcgill	2025-01-05 17:55:41.416+00	2025-01-05 17:55:41.416+00	t	\N	\N	\N	\N	\N	\N
349	mcgill-student-club-for-animal-liberation-and-ethics-scale	McGill Student Club for Animal Liberation and Ethics	Formerly known as McGill Herbivores, McGill Student Club for Animal Liberation and Ethics (SCALE) is a nonhierarchical club concentrating on animal rights issues. The club’s focus is on animal liberation activism, providing a space for vegan students to get involved in activism, as well as support and educational resources for non-vegan students looking to adopt a more ethical lifestyle.	https://herbivores.ssmu.ca	mcgill.scale@ssmu.ca	\N	https://www.facebook.com/McGillSCALE	https://www.instagram.com/mcgill.scale	2025-01-24 16:17:35.313+00	2025-01-05 17:55:47.045+00	t	\N	\N	\N	\N	\N	\N
348	mcgill-collective-for-gender-equality	McGill Collective for Gender Equality	The McGill Collective for Gender Equality engages students through advocacy and fundraising. In support of their goal, the organization raises awareness about gender-based global issues such as violence against women and girls, reducing the spread of HIV/AIDS among women and girls, empowerment programs, and achieving gender equality in democratic governance in a time of peace and conflict. They organize events such as panel discussions on human rights and gender equality, film showings, fundraisers, and discussion groups.	https://unwomenmcgill.wixsite.com/club	genderequalitycollectivemcgill@gmail.com	\N	https://www.facebook.com/GenderEqualityMcGill	https://www.instagram.com/genderequalitymcgill	2025-01-24 16:18:48.883+00	2025-01-05 17:55:46.363+00	t	\N	\N	\N	\N	\N	\N
347	mwil	McGill Women in Leadership Students Association	MWIL is dedicated to providing students with the information, opportunities, and support network they need to tap into their full potential as professionals, students, and young people. They welcome women and non-binary identifying students from a range of career fields to share their accomplishments and experiences; connect members with extensive opportunities to learn, and ultimately empower them to be critically engaged global leaders.	https://www.mwil.org	mcgillwil@ssmu.ca	\N	https://www.facebook.com/MWILeadership	https://www.instagram.com/mcgillwil	2025-01-24 16:31:46.344+00	2025-01-05 17:55:43.071+00	t	\N	\N	\N	\N	\N	\N
345	gcc	Global China Connection	Global China Connection is a student-run non-profit organization that helps develop deep and trusting personal relationships between young leaders. GCC network currently consists of more than 60 university chapters around the world, and GCC McGill is one of the leading chapters in Canada. GCC McGill is committed to building a multicultural and interacting community by organizing a variety of activities including delegations of university students, social and professional events, panels, and more. GCC helps to develop your leadership skills and to meet fellow students.	https://gccglobal.org	mcgill@gccglobal.org	\N	https://www.facebook.com/GCCMcGill	\N	2025-01-28 00:11:41.4+00	2025-01-05 17:55:40.311+00	f	\N	\N	\N	\N	\N	\N
344	mcgill-trivia-club	McGill Trivia Club	The McGill Trivia Club provides a forum for McGill students who enjoy trivia to assemble and indulge their interest. They meet twice a week to practice, and attend tournaments in Ottawa, Toronto, Waterloo, and Chicago.	\N	mcgill.triviaclub@ssmu.ca	\N	https://www.facebook.com/groups/McGillTrivia	\N	2025-01-28 00:12:48.839+00	2025-01-05 17:55:38.942+00	t	\N	\N	\N	\N	\N	\N
342	mcgill-students-chess-club	McGill Students’ Chess Club	The McGill Chess Club meets every Thursday evening for casual chess. They offer lessons, seminars, tournaments and other activities. All levels welcome, from beginner to master!	https://discord.gg/sx65wQDWDx	mcgill.chess@ssmu.ca	\N	https://www.facebook.com/groups/McGillChess	\N	2025-01-28 00:28:04.116+00	2025-01-05 17:55:37.811+00	t	\N	\N	\N	\N	\N	\N
341	mcgill-poker-studies-club	McGill Poker Studies Club	McGill Poker Studies Club is the foremost community of poker players at McGill. They host weekly no buy-in tournaments in the SSMU building as well as tournaments for inter-university games. New and experienced players welcome!	https://mcgillpoker.ca	pokerstudies@ssmu.ca	\N	https://www.facebook.com/McGillPoker	\N	2025-01-28 00:29:18.282+00	2025-01-05 17:55:36.959+00	f	\N	\N	\N	\N	\N	\N
340	gamers-guild	Gamers’ Guild	Gamers' Guild is a club that meets up to play board games in person or online every week! They welcome anyone who wants to drop by, and have a variety of both simple and complex games for all to enjoy.	http://ssmugamersguild.blogspot.com	mcgillgamersguild@ssmu.ca	\N		\N	2025-01-28 00:30:28.511+00	2025-01-05 17:55:36.431+00	t	\N	\N	\N	\N	\N	\N
339	counterpoint	Counterpoint	Counterpoint is McGill University’s first fully student-run music magazine providing music news, reviews and articles with the purpose of exposing McGill students to campus musicians and Montreal’s vibrant music scene in general.Counterpoint also hosts events and parties which aim to bring people together to celebrate Montreal’s diverse nightlife and musical talent. Counterpoint is obsessed with music and they hope to rub off some of their passion onto you.	https://counterpoint.ssmu.ca	counterpoint.mcgill@gmail.com	\N	https://www.facebook.com/counterpointmcgill	https://www.instagram.com/counterpoint.mcgill	2025-01-28 00:32:14.146+00	2025-01-05 17:55:34.996+00	t	\N	\N	\N	\N	\N	\N
356	mcgill-engineers-in-action	McGill Engineers in Action	McGill Engineers in Action is a student chapter of the EIA Bridge Program which designs, funds, and builds pedestrians footbridges in remote communities.	https://eus.wiki/McGill_Engineers_in_Action	eia.president@mcgilleus.ca	\N	https://www.facebook.com/McGillEIA	https://www.instagram.com/mcgill.engineersinaction	2025-01-24 16:03:16.842+00	2025-01-05 17:56:06.363+00	t	\N	\N	\N	\N	\N	\N
355	eus-junior-council	EUS Junior Council	Junior Council is a committee under the EUS composed of first and second year engineering students. At the beginning of the fall semester, all incoming first years are encouraged to apply for any VP positions, departmental representatives, or external council representatives. The council’s goal is to welcome all first year engineering students by organizing both academic and social events throughout the school year, and to create a strong network of first year students.	https://eus.wiki/Junior_Council	junior.council@mcgilleus.ca	\N	https://www.facebook.com/EUSJuniorCouncil	https://www.instagram.com/eusjuniorcouncil	2025-01-24 16:10:10.833+00	2025-01-05 17:56:03.68+00	t	\N	\N	\N	\N	\N	\N
354	eus-sports	EUS Sports	EUS Sports is an intramural sports program offered by the Engineering Undergraduate Society to all full-time McGill students and provides the opportunity to participate in competitive sport. Individuals are encouraged to participate in the spirit of fair play and good sportsmanship. EUS Sports provides soccer and flag football during the fall semester and broomball during the winter semester. The leagues run throughout the semester and end with a tournament to have a winning team declared and labelled on the EUS trophy.	https://eus.wiki/EUS_Sports	sports@mcgilleus.ca	\N	https://www.facebook.com/EusSports	https://www.instagram.com/eus_sports	2025-01-24 16:11:02.126+00	2025-01-05 17:56:03.278+00	t	\N	\N	\N	\N	\N	\N
353	moroccan-students-society	Moroccan Students’ Society	Moroccan Students’ Society is a student group of the SSMU dedicated to representing Morocco, spreading Moroccan culture, and helping underprivileged people in Morocco, by organizing various events throughout the year.	\N	mss@ssmu.ca	\N	\N	https://www.instagram.com/mss.mcgill	2025-01-24 16:12:46.812+00	2025-01-05 17:55:54.816+00	t	\N	\N	\N	\N	\N	\N
352	mcgill-icon	McGill ICON	ICON is a Christian club open to everyone looking for a spiritual and social group. Their purpose is to offer a religious group on campus and to create a community that is friendly and welcoming to everyone. They encourage people to share opinions about their faith and develop enlightening discussions. Meetings take place on a weekly basis at the Newman Centre of McGill University. The club is very people-oriented, going to dinner together on a weekly basis after our meetings and offering various social activities throughout the semester to promote fellowship and introduce a fun side to spirituality.	\N	icon@ssmu.ca	\N	https://www.facebook.com/groups	\N	2025-01-24 16:15:08.173+00	2025-01-05 17:55:52.094+00	t	\N	\N	\N	\N	\N	\N
351	bss	Baltic Students Society (BSS)	The Baltic Students’ Society is a club at McGill University dedicated to celebrating the common history and culture of the Baltic countries.\n \n We aim to:\n Maintain and celebrate the cultural heritage of the Baltic countries\n Create a positive space in which to address and discuss issues of Baltic culture, identity and contemporary Baltic life\n Reach out to Baltic communities in Montreal and elsewhere\n Create and spread awareness of Baltic cultures and societies within the McGill community	\N	bss@ssmu.ca	\N	https://www.facebook.com/groups/BalticMcGill/	\N	2025-01-24 16:16:26.438+00	2025-01-05 17:55:48.513+00	t	\N	\N	\N	\N	\N	\N
362	mcgill-biodesign-team	McGill BioDesign Team	McGill BioDesign is an official EUS design team whose goal is to address real-world issues by finding solutions at the intersection of engineering, biology, and business. They work on biotechnology projects and present them at competitions, provide students with research experience, build a community for like-minded students from a range of backgrounds, and offer networking and professional development opportunities through workshops and tutorials.	http://mcgillbiodesign.com	biodesign@mcgilleus.ca	\N	https://www.facebook.com/McgillBiodesign	https://www.instagram.com/mcgillbiodesign	2025-01-24 16:23:15.177+00	2025-01-05 17:56:09.31+00	t	\N	\N	\N	\N	\N	\N
361	vertical-flight-society	Vertical Flight Society	Vertical Flight Society aspires to advance the involvement of vertical flight enthusiasts at McGill University in the industry.	https://vtol.org	vfs@mcgilleus.ca	\N	https://www.facebook.com/vfsMcGill	https://www.instagram.com/vfs.mcgill	2025-01-24 16:23:29.242+00	2025-01-05 17:56:08.924+00	t	\N	\N	\N	\N	\N	\N
360	reboot	Reboot	The mission of Reboot McGill is to facilitate asset reallocation around the university by collecting old computers and peripherals, refurbishing the equipment if possible, redeploying the equipment where appropriate, donating any unwanted usable equipment, and finally arranging the proper disposal of all unusable equipment scrap. The purpose of the program is to reallocate computer equipment for university/personal use.	https://eus.wiki/Reboot	reboot@mcgilleus.ca	\N	https://www.facebook.com/RebootMcGill	\N	2025-01-24 16:24:18.417+00	2025-01-05 17:56:08.311+00	t	\N	\N	\N	\N	\N	\N
359	powe	Promoting Opportunities for Women in Engineering	Promoting Opportunities for Women in Engineering is a McGill student-run organization with a vision to increase the presence of women in the engineering classroom and profession. To achieve this goal, POWE reaches out to future engineering students and supports current students through professional development activities.	http://powe.mcgilleus.ca	powe@mcgilleus.ca	\N	https://www.facebook.com/powemcgill	https://www.instagram.com/powemcgill	2025-01-24 16:24:55.052+00	2025-01-05 17:56:07.763+00	t	\N	\N	\N	\N	\N	\N
358	national-society-for-black-engineers	National Society for Black Engineers	The National Society of Black Engineers was created by two engineering students at Purdue University, Edward Barnett and Fred Cooper. NSBE’s main goal is to provide academic and career opportunities to its members through various programs, scholarships and training.	https://eus.wiki/National_Society_for_Black_Engineers	nsbe@mcgilleus.ca	\N	https://www.facebook.com/McGillNSBE	https://www.instagram.com/nsbemcgill	2025-01-24 16:25:11.891+00	2025-01-05 17:56:07.37+00	t	\N	\N	\N	\N	\N	\N
371	eline	ELINE	Engaged Learning in Engineering is an EUS committee focused on promoting a culture of engaged learning among the engineering student community.	https://eus.wiki/ELINEhttps://elinemcgill.wordpress.com	elinechair@mcgilleus.ca	\N	https://www.facebook.com/ELINEMcGill	\N	2025-01-24 02:37:07.985+00	2025-01-05 18:16:13.837+00	t	\N	\N	\N	\N	\N	\N
369	meca	McGill Koreans Educational and Cultural Association	The McGill Koreans’ Educational & Cultural Association provides academic support to students and promotes Korean culture on campus. As a SSMU-affiliated student group, we are committed to community engagement and involvement.	\N	meca@ssmu.ca	\N	https://www.facebook.com/mecamcgill	https://www.instagram.com/meca.mcgill	2025-01-24 02:42:29.749+00	2025-01-05 18:16:04.367+00	t	\N	\N	\N	\N	\N	\N
367	democrats-abroad-mcgill	Democrats Abroad @ McGill	Democrats at McGill is a politically active club on campus that assists U.S students in registering to vote, mailing in ballots, and accessing resources for Americans within Montreal. The club hosts a variety of events including phone banking for democratic candidates, letter writing, and social events to discuss politics. Democrats at McGill places a strong emphasis on creating a safe, inclusive, and welcoming community for all students regardless of nationally who are passionate about social activism. They encourage all who are willing to fight for progressive policies and learn about the Democratic Party to join the club.	\N	demsabroadinternal@ssmu.ca	\N	https://www.facebook.com/demsabroadmcgill	https://www.instagram.com/democratsatmcgill	2025-01-24 16:19:40.815+00	2025-01-05 18:15:56.837+00	t	\N	\N	\N	\N	\N	\N
366	mcgill-students-for-parkinsons-awareness	McGill Students’ for Parkinson’s Awareness	McGill Students for Parkinson’s Awareness’s initiative to raise awareness on campus for Parkinson’s by informing students about the nature of the disease and the current challenges that are being faced by the researchers. They raise funds for charities supporting Parkinson’s patients and their caregivers as well as biomedical research focused on finding a cure for the disease.	https://mcgillstudentsforp3.https//mcgillstudentsforp3.wixsite.com/mcgillparkinsonsclub%20wixsite.com/mcgillparkinsonsclub	mcgillstudentsforparkinsons@ssmu.ca	\N	https://www.facebook.com/mcgillstudentsforparkinsons	https://www.instagram.com/mcgillparkinsonsclub	2025-01-24 16:20:17.534+00	2025-01-05 18:15:47.743+00	t	\N	\N	\N	\N	\N	\N
365	mcgill-students-for-greenpeace	McGill Students for Greenpeace	McGill Students for Greenpeace is the first university-level chapter of Greenpeace International to be established in Canada. They promote environmental awareness and advocacy around campus and the greater Montreal community. Their campaigns are related to sustainable habits and practices around consumption, food, waste, and resource-use, as well as increasing awareness of global environmental challenges.	https://greenpeacemcgill1.wixsite.com/msfgreenpeace	greenpeace.mcgill@ssmu.ca	\N	https://www.facebook.com/GreenpeaceMcGill	https://www.instagram.com/greenpeacemcgill	2025-01-24 16:20:57.76+00	2025-01-05 18:15:24.063+00	t	\N	\N	\N	\N	\N	\N
363	mcgill-rocket-team	McGill Rocket Team	The McGill Rocket Team is an EUS Design Team that aims to develop a Canadian aerospace community by providing students with practical experience in the development of rocket technologies and by promoting the Canadian aerospace industry. In practice, this means that members of the team build sounding rockets for various student rocketry competitions. The main competition the Rocket Team participated had been the Intercollegiate Rocket Engineering Competition (IREC), now called Spaceport America Cup (SAC), but as of 2022, the McGill Rocket Team is planning to compete in the Launch Canada competition.	https://www.mcgillrocketteam.com	rocketteam@mcgilleus.ca	\N	https://www.facebook.com/McGillRocketTeam	https://www.instagram.com/mcgill_rocket_team	2025-01-24 16:22:45.319+00	2025-01-05 17:56:11.074+00	t	\N	\N	\N	\N	\N	\N
370	canadian-engineering-competition	Canadian Engineering Competition	Each year, the Canadian Engineering Competition brings together 150 of the most innovative and creative engineering undergraduate students from across the nation to compete against each other in one of six categories, ranging from design, consulting, presentation and debate. Each competition category at CEC challenges its participants to expand their frame of reference and to identify solutions to problems experienced by our profession.	https://mec.mcgilleus.ca	\N	\N	\N	\N	2025-01-24 16:27:44.528+00	2025-01-05 18:16:13.211+00	t	\N	\N	\N	\N	\N	\N
368	mcgill-students-in-solidarity-for-palestinian-human-rights	McGill Students in Solidarity for Palestinian Human Rights	SPHR is a student-led club that champions the Palestinian liberation struggle settler-colonialism, apartheid, and genocide based on principles of anti-colonial solidarity. They also advocate for the rights of Palestinian students in the face of racism, misinformation, harrassment, and surveillance at McGill, as well as campaign for the end of the University’s complicity in the colonization of Palestine.	\N	mcgillsphr@gmail.com	\N	https://www.facebook.com/sphrmcgill	https://www.instagram.com/sphrmcgill	2025-01-24 16:28:36.515+00	2025-01-05 18:15:59.471+00	t	\N	\N	\N	\N	\N	\N
372	plumbers-student-design-eus	Plumbers' Student Design EUS	Plumber's Student Design is a student-run service providing free, innovative and efficient graphic design solutions for EUS members and organizations. The PSD is a committee under the VP Communications.	https://eus.wiki/Plumbers%27_Student_Design	psd@mcgilleus.ca	\N	https://www.facebook.com/psdeus	\N	2025-02-09 20:52:03.395+00	2025-01-05 18:16:15.567+00	f	\N	\N	\N	\N	\N	\N
364	mcgill-e-sports-students-society	McGill E-Sports Students' Society	The McGill eSports Student Association is one of the campus’ largest clubs, with over a hundred members and over 7 competitive collegiate teams that are playing Valorant, League of Legends, Rocket League, Apex Legends, DOTA II and Smash.	https://mcgillathletics.ca/sports/2020/9/2/Esports.aspx	esports@ssmu.ca	\N	https://www.facebook.com/mcgillesports	https://www.instagram.com/mcgillesportsassociation	2025-02-21 15:33:24.385+00	2025-01-05 18:15:20.695+00	f	\N	\N	\N	\N	\N	\N
2	mcgill-cycling	McGill Cycling	Interactive forum whereby members can post group rides, races, potlucks and other club events. The website also serves as a platform for discussing the sport of cycling as well as a free and for sale classified service.	https://mcgillcycling.com/	mcgillcycling@gmail.com	\N	https://www.facebook.com/McGillCycling	https://www.instagram.com/mcgillcycling/	2025-01-24 15:29:00.086+00	2025-01-05 17:38:52.168+00	t	\N	\N	\N	\N	\N	\N
5	agelf---lassociation-gnrale-des-tudiants-de-langue-et-littrature-franaises	AGELF - L’Association Générale des Étudiants de Langue et Littérature Françaises	Toutes les personnes actuellement inscrites à une majeure, à une mineure ou à une spécialisation au Département des littératures de langue française, de traduction et de création (DLTC) de l'université McGill sont membres de l'AGELF.	https://www.mcgill.ca/litterature/fr/activites-etudiantes/agelf?fbclid=PAZXh0bgNhZW0CMTEAAaaxu9aak36cai1z9IRuOeVy0EFYyrzULdbGl-J-5QCx2S-wwsYwq77RWjA_aem_ulQ1KmbBu5HZGp41cehltg	mcgillagelf@gmail.com	\N	https://www.facebook.com/agelf	https://www.instagram.com/agelf.dltc/	2025-01-24 15:36:59.987+00	2025-01-05 17:39:12.564+00	t	\N	\N	\N	\N	\N	\N
9	contemporary-review-of-genocide-and-political-violence	Contemporary Review of Genocide and Political Violence	Canada is no stranger to genocide, although Canadians sometimes can be. We are a nation founded on genocide. We continue to exist on stolen land from murdered indigenous peoples, and we continue the theft along with the murder. Canada went on to suppress other minorities (any list would oversimplify) much of which continues today. This reality necessitates that we study the topic, review our history, to attempt understand today, and to prepare for tomorrow. As Heschel said “We are not all guilty, but we are all responsible.” In this contemporary review, we hope to better comprehend the past and the present from our current standpoint. The topics are broad and can only be understood with serious analysis of its different embodiments. It is possible that, given the constantly changing abuses, a study of genocides and political violence will never be complete. As such, we nonetheless hope to make a small contribution to a global exchange.	http://crgreview.com/	genocidesjournal@ssmu.ca	\N	https://www.facebook.com/CRGreview	\N	2025-01-24 15:49:32.972+00	2025-01-05 17:39:36.141+00	f	\N	\N	\N	\N	\N	\N
357	nobe	National Organization for Business and Engineering McGill Chapter	National Organization for Business and Engineering (NOBE) engages engineering students to diversify and broaden their engineering curriculum. Through exclusive skills-building workshops and networking events, NOBE provides engineering students with the skills, confidence, and network to excel in careers outside the typical engineering scope, such as consulting (management, tech, or engineering), banking, marketing, and more!	https://eus.wiki/National_Organization_for_Business_and_Engineering_McGill_Chapter	president@nobemcgill.org	\N	https://www.facebook.com/NOBEMcGill	https://www.instagram.com/nobemcgill	2025-01-24 16:02:16.893+00	2025-01-05 17:56:06.919+00	t	\N	\N	\N	\N	\N	\N
15	lsa	McGill Lebanese Students Association (LSA)	McGill LSA operates to facilitate the integration of Lebanese students into the McGill environment and Montréal. They aim to represent, unite and promote the Lebanese Community through cultural, educational and social activities and introduce Lebanese culture to students of different nationalities and backgrounds.	\N	lsa@ssmu.ca	\N	https://www.facebook.com/lsamcgill	https://www.instagram.com/lsamcgill	2025-01-24 16:05:55.198+00	2025-01-05 17:39:54.243+00	t	\N	\N	\N	\N	\N	\N
377	licm	Legal Information Clinic at McGill	The LICM is committed to increasing access to justice for McGill and Montreal communities and to meeting the needs of students and marginalized groups because justice matters for everyone, offering free and bilingual legal information as well as student advocacy services.	https://licm.ca	info.studentadvocacy@licm.ca	438-944-6546	https://www.facebook.com/licm.cijm	https://www.instagram.com/licm_cijm	2025-02-27 15:31:33.324+00	2025-01-05 18:22:54.679+00	t	google.com	Clinique d'information juridique à McGill	La CIJM est engagée à améliorer l'accès à la justice des communautés mcgilloises et montréalaises, ainsi qu'à répondre aux besoins des étudiant.e.s et des groupes marginalisés, car la justice, on y a tous droit. 	\N	\N	\N
375	blockchain-at-mcgill	Blockchain at McGill	Blockchain at McGill is a student run educational non-profit raising awareness and fostering engagement in the field of Blockchain and its related technologies. BAM accelerates its members and executives to become leaders in the industry by providing them with relevant experience and industry connections.	\N	\N	\N	https://www.facebook.com/blockchainatmcgill	https://www.instagram.com/blockchain_mcgill	2025-02-27 15:37:29.399+00	2025-01-05 18:22:08.813+00	t	\N	Blockchain à McGill	Blockchain à McGill est une association éducative à but non lucratif gérée par des étudiants, qui sensibilise et encourage l'engagement dans le domaine de la blockchain et de ses technologies connexes. BAM aide ses membres et ses membres exécutifs à devenir des leaders de l'industrie en leur fournissant une expérience pertinente et des connexions avec l'industrie.	\N	\N	\N
350	mcgill-students-chapter-for-amnesty-international	McGill Students Chapter for Amnesty International	McGill Students for Amnesty International is a club that aims to raise awareness on international human rights violence on campus. They host weekly meetings and organize events to promote campaigns by Amnesty International Canada to prevent and end grave abuses of human rights and to demand justice for those whose rights have been violated.	https://amnestymcgill.ssmu.ca	amnestymcgill@ssmu.ca	\N	https://www.facebook.com/groups	https://www.instagram.com/amnestymcgill	2025-01-24 16:17:06.098+00	2025-01-05 17:55:47.451+00	t	\N	\N	\N	\N	\N	\N
28	fuss	First-Year Undergraduate Science Society (FUSS)	The First-Year Undergraduate Science Society (FUSS) of McGill University is a group of appointed first-year science students with the goal of representing U0 and U1 undergraduates through organizing events as well as acting as a liaison between students and Faculty. Through these initiatives, FUSS strives to engage the first-year community and ease the transition to university life.	https://www.fussmcgill.com/	fuss.sus@mail.mcgill.ca	\N	https://www.facebook.com/sciencefuss	https://www.instagram.com/mcgill.fuss	2025-01-24 16:23:40.473+00	2025-01-05 17:42:48.072+00	t	\N	\N	\N	\N	\N	\N
36	dss	Dental Students' Society (DSS)	The Dental Students’ Society (DSS) represents the student body of all students studying to acquire a DMD degree and which are currently enrolled in the Faculty of Dentistry at McGill University. It serves to promote the views of its members in all dealings with the Faculty of Dentistry of McGill University and the University at large.  	https://mcgilldss.com/	president.dss@mail.mcgill.ca	\N	https://www.facebook.com/DSSmcgill	https://www.instagram.com/mcgilldentistry	2025-01-24 16:37:49.496+00	2025-01-05 17:42:52.618+00	t	\N	\N	\N	\N	\N	\N
47	ssmu-ski-and-snowboard-club	SSMU Ski and Snowboard Club	SSMU Ski and Snowboard Club is a service that, in the winter term, takes students to local mountains for weekly ski trips. In the fall, there are a few events that allow for students to meet each other before they head out skiing and snowboarding in the winter semester.	https://www.ssmuski.com/	mail@ssmuskiandsnowboardclub.com	\N	https://www.facebook.com/ssmuskiandsnowboardclub	https://www.instagram.com/ssmuski	2025-01-24 16:55:04.006+00	2025-01-05 17:42:59.389+00	t	\N	\N	\N	\N	\N	\N
59	mcgill-students-for-world-vision	McGill Students for World Vision	McGill Students for World Vision is founded with the mission to help achieve the goals set by World Vision—a humanitarian charity organization dedicated to working with children, families, and communities worldwide. Their key activities include fundraising, advocacy, and education within the McGill community in order to promote awareness on campus and student participation in both international and Canadian World Vision programs.		worldvision.mcgill@gmail.com	\N	https://www.facebook.com/mcgillworldvision	https://www.instagram.com/worldvisionmcgill	2025-01-24 17:19:22.563+00	2025-01-05 17:43:05.225+00	t	\N	\N	\N	\N	\N	\N
18	the-cube	The Cube	The Cube is the largest student-run 3D-printing service at McGill University. It's main lab space is located on the second floor of the MacDonald Engineering Building, room MD264 (just down the hall from Mechanical Engineering Reception). There are currently five 3D printers in the lab, and 2 3D scanners, servicing clients including students, professors, and even the general public can submit 3D printing orders to The Cube via their online ordering system found on their website. A student technician uses 3D printing software to evaluate the submitted designs and then sends an quote to the customer. Once the price of the quote has been confirmed by the customer, the technician will put the print on the printer. When the print is complete, the customer can pay for and pick up their completed print at CopiEUS. The typical lead time of a print ranges from 2 days to 1 week.	http://cube.mcgilleus.ca/	cube@mcgilleus.ca	\N	https://www.facebook.com/thecube3dprinting/	\N	2025-01-25 22:51:58.079+00	2025-01-05 17:40:13.058+00	f	\N	\N	\N	\N	\N	\N
84	desa-department-of-english-students-association	DESA – Department of English Students’ Association	The DESA executive is an elected student organization in the Department that represents every student who has declared a Major, Minor, or Honours concentration in an English program. As a social, cultural, political, and educational organization for students, DESA performs the functions of student government and representation at the departmental level.	https://www.mcgill.ca/english/undergrad/desa	desamcgill@gmail.com	\N	https://www.facebook.com/DESAMcGill	https://www.instagram.com/desamcgill/	2025-01-25 23:11:55.468+00	2025-01-05 17:43:19.199+00	t	\N	\N	\N	\N	\N	\N
92	mcgill-naginata-club	McGill Naginata Club	The McGill Naginata Club is dedicated to the martial art of Naginata. In addition to teaching the techniques of the sport, the club also promotes healthy teamwork and fosters strong bonds between members through competition, mutual learning, and social activities. The McGill Naginata Club welcomes all students, of every level, and especially those who have never tried (or seen) naginata before! 	https://mcgillnaginata.com/	mcgillnaginata@gmail.com	\N	https://www.facebook.com/mcgillnaginata	https://www.instagram.com/mcgillnaginata	2025-01-25 23:22:02.391+00	2025-01-05 17:43:23.923+00	t	\N	\N	\N	\N	\N	\N
97	mscs	McGill Students’ Cancer Society (MSCS) – Relay for Life	The McGill Students’ Cancer Society (MSCS) is a student-led group dedicated to making a difference in the lives of Canadians affected by cancer. By organizing fundraising campaigns, raising awareness, and planning the annual Relay For Life, the MSCS contributes to funding life-saving cancer research and patient support programs provided by the Canadian Cancer Society. 	https://mcgillcancersociety.wordpress.com/	mcgill.relay@gmail.com	\N	https://www.facebook.com/McgillRelayForLife	https://www.instagram.com/mcgill.relay	2025-01-25 23:26:57.769+00	2025-01-05 17:43:26.487+00	t	\N	\N	\N	\N	\N	\N
108	mushvc	McGill University Student Hospital Volunteer Club (MUSHVC)	MUSHVC is a group of students who volunteer at McGill-affiliated hospitals (and more) that are trying to give the same experiences to incoming and current McGill students. 	https://mushvcmcgill.wixsite.com/mysite	mushvc@ssmu.ca	\N	https://www.facebook.com/MUSHVCMCGILL	https://www.instagram.com/mushvcmcgill	2025-01-25 23:43:02.55+00	2025-01-05 17:43:36.019+00	t	\N	\N	\N	\N	\N	\N
118	chromatones-a-cappella	Chromatones a Cappella	Chromatones A Cappella is a student-led a cappella group at McGill University. They are one of the four groups on campus. They rehearse songs of all genres which are arranged by current and past members, and perform at the end of the semester and in various gigs in the community. 	http://chromatones.ca/	chromatonesmcgill@gmail.com	\N	https://www.facebook.com/ChromatonesACappella	https://www.instagram.com/chromatones	2025-01-25 23:51:14.225+00	2025-01-05 17:43:40.665+00	t	\N	\N	\N	\N	\N	\N
343	mcgill-students-mafia-club	McGill Students’ Mafia Club	The McGill Mafia Club is a social club open to anyone who wants to play or learn how to play the game “Mafia,” also known as Werewolf. Mafia is a social psychology game that pits the uninformed majority (villagers) against an informed minority (mafia). Villagers must guess who the mafia are among them while attempting to avoid being killed themselves. In addition to playing mafia, they also play other related intrigue games such as One Night Werewolf, Two Rooms and a Boom, and The Resistance. There are usually snacks to go around during the meetings. Outside of their regularly scheduled gatherings, they host multiple social events a year like parties, picnics, ice skating, and trivia nights to name a few. They're open to anyone who would like to join!	https://discord.gg/JGDspHAQBR	mafiaclub@ssmu.ca	\N	https://www.facebook.com/groups/mcgillmafia	\N	2025-01-28 00:14:23.617+00	2025-01-05 17:55:38.374+00	t	\N	\N	\N	\N	\N	\N
338	uaem	McGill Students Chapter of Universities Allied for Essential Medicines	Universities Allied for Essential Medicines is a global network of students that fight to make life-saving medicines affordable and accessible for all. Since universities develop many of the medical technologies that end up in the hands of pharmaceutical companies, students have the power to encourage universities to adopt equitable licensing practices. Throughout the years, their student chapter has been working on promoting the adoption of open science practices across McGill, promoting world-wide access to essential medicines and vaccines and on advocating for more transparency around clinical trials. They are also very proud to be one of the main UAEM chapters working on the organization-wide Canadian Report Card project.	https://ssmu.ca	uaem@ssmu.ca	\N	https://www.facebook.com/UAEMMcGill	https://www.instagram.com/uaem_mcgill	2025-01-28 00:34:09.25+00	2025-01-05 17:55:29.619+00	t	\N	\N	\N	\N	\N	\N
327	russ---russian-undergraduate-students-society	RUSS - Russian Undergraduate Students’ Society	The Russian Undergraduate Students' Society is the community for McGill students studying Russian literature and language. They run many events, including conversation hours, translation workshops, and community events.	http://russmcgill.weebly.com	russ.aus@gmail.com	\N		https://www.instagram.com/russmcgill	2025-01-28 00:56:59.833+00	2025-01-05 17:55:14.237+00	t	\N	\N	\N	\N	\N	\N
326	idssa---international-development-studies-students-association	IDSSA - International Development Studies Students’ Association	The McGill International Development Studies Students Association comprises the over one thousand undergraduate international development studies students at McGill University. All undergraduate students in the international development major, minor, honours, or joint honours program are automatically a member of the IDSSA.	https://idssamcgill.com	idssamcgill@gmail.com	\N		https://www.instagram.com/idssamcgill	2025-01-28 00:57:20.72+00	2025-01-05 17:55:12.801+00	t	\N	\N	\N	\N	\N	\N
312	black-youth-outreach-program	Black Youth Outreach Program	The Black Youth Outreach Program is a club that aims to stimulate interest in programs at McGill among the black youth of Montreal. Their goals include increasing the representation of black students at McGill, encouraging the pursuit of higher education with a focus on black youth and being a resource prospective students can refer to. They also intend to establish connections with other black associations on campus to expand the network of services offered to black students at McGill, and enrich their university experience. As a club, their mandate is to foster an equitable environment for all students at McGill, increase the sense of belonging of black McGill students, introduce local black youth to a variety of fields and careers McGill degrees give access to, and contribute to abolishing barriers black students face in their pursuit of higher education. Our efforts will be directed towards diversifying fields where black populations are typically underrepresented and providing support to young black students while they are navigating the world of academia, whether it be in their current studies or in the process of applying to McGill.	https://www.byomcgill.com/about	byo@ssmu.ca	\N	https://www.facebook.com/p	https://www.instagram.com/byo.mcgill	2025-01-28 01:08:15.529+00	2025-01-05 17:55:03.402+00	f	\N	\N	\N	\N	\N	\N
303	potus	McGill Physical and Occupational Therapy Undergraduate Society	As the official governing body of all undergraduate students enrolled in the physical and occupational therapy programs at McGill University, POTUS plays a prominent role in representing and advocating for students, in leading student life and organizing extracurricular activities, as well as in promoting an environment of academic excellence and social responsibility for our students. POTUS is committed to enhancing and improving students’ learning experience at McGill University. They provide information about future career opportunities to our students by increasing their exposure to potential employers and organize networking events. POTUS is committed to encouraging students to participate in activities that help them develop their professional identity and increase their sense of belonging to a tight-knit community of future healthcare rehabilitation professionals.	https://potusmcgill.wixsite.com/potus	president.potus@mail.mcgill.ca	\N	https://www.facebook.com/potus.mcgill	https://www.instagram.com/mcgillpotus	2025-01-28 03:22:33.748+00	2025-01-05 17:54:54.461+00	t	\N	\N	\N	\N	\N	\N
302	musa	Music Undergraduate Students' Association (MUSA)	The Music Undergraduate Students' Association is apart of the Schulich Music Undergraduate Students’ Association, and supports all students in the program. They organize events including socials and formals, and offer a wide range of association positions to make your voice heard and become more involved.	https://www.mcgillmusa.ca	administration.musa@mail.mcgill.ca	\N	https://www.facebook.com/McGillMUSA	https://www.instagram.com/mcgill_musa	2025-01-28 06:40:51.988+00	2025-01-05 17:54:53.237+00	t	\N	\N	\N	\N	\N	\N
300	ecsess	The Electrical, Computer, & Software Engineering Student Society (ECSESS)	Electrical, Computer & Software Engineering Students' Society at McGill is a student association which helps McGill ECSE students in their academic, technical, social and professional progression.	https://ecsess.mcgilleus.ca	\N	\N	https://www.facebook.com/ECSESS	https://www.instagram.com/mcgill_ecsess	2025-01-28 06:42:47.699+00	2025-01-05 17:54:52.196+00	t	\N	\N	\N	\N	\N	\N
275	game-development-students-society	Game Development Student's Society	The Game Development Student's Society is a community of people that enjoy creating games and learning about all aspects of game development. The club also hosts McGame Jam, which is the second biggest game jam in Quebec.	https://www.gamedevmcgill.ca/	gamedev@mcgilleus.ca	\N	https://www.facebook.com/gamedevmcgill	\N	2025-01-28 06:55:59.039+00	2025-01-05 17:45:04.071+00	t	\N	\N	\N	\N	\N	\N
228	newman-catholic-students-society	Newman Catholic Students’ Society	The Newman Catholic Students’ Society is the Catholic student community of McGill University. Based out of the Newman Centre of McGill University, they seek to make our Christian faith alive through social activities and community life, faith formation and spiritual enrichment, charitable outreach and service, and a strong sense of friendship and fellowship among our members. They also enthusiastically collaborate with our brothers and sisters in other Christian and religious groups on campus. Finally, they are open for any student, regardless of their religious affiliation, to come hang out and take a break from the busy life of a student in a warm, comfy, and communal atmosphere.	https://www.mcgillcatholics.ca/	mcgillcatholics@ssmu.ca	\N	https://www.facebook.com/mcgillcatholics	\N	2025-02-07 06:27:48.314+00	2025-01-05 17:44:39.288+00	t	\N	\N	\N	\N	\N	\N
299	medusa	Music Education Undergraduate Student Association (MEdUSA)	The Music Education Undergraduate Students' Association exists to provide services to strengthen the educational, cultural, environmental, political and social conditions of our membership, as well as to facilitate interaction between members and professionals in the field of Music Education. MEdUSA represents all of the students in the ​Concurrent B.Mus/B.Ed program, the Advanced Placement B.Ed in Music program, and all Minor in Music Education students. The council, consisting of six executive and three representative positions, promotes the welfare of their student population by providing solutions for course selection and scheduling conflicts, organizing annual social events, and providing fun and educational workshops, some of which are mentored by members of the QBA (Quebec Band Association). MEdUSA also helps students create a circle of contacts with current band teachers in the Montreal region, recently graduated McGill students, and current staff and peers at McGill. They also work to make current and recently graduated students aware of job opportunities in the area. MEdUSA works hard in order for students in music education to have the best experience while studying at McGill University.	https://www.medusamcgill.com	medusa.mcgill@gmail.com	\N		https://www.instagram.com/medusa.mcgill	2025-01-28 06:43:25.257+00	2025-01-05 17:54:50.933+00	t	\N	\N	\N	\N	\N	\N
288	codejam	CodeJam	CodeJam is the annual 36-hour programming competition at McGill. The hackathon is run by the McGill Electrical, Computer, and Software Student Society in their very own Trottier Engineering Building. They provide an engaging environment for students to learn and have fun over a weekend of coding!	http://codejam.mcgilleus.ca/	codejam@mcgilleus.ca	\N	https://www.facebook.com/mcgillcodejam	https://www.instagram.com/mcgillcodejam	2025-01-28 06:47:57.241+00	2025-01-05 17:45:11.275+00	t	\N	\N	\N	\N	\N	\N
287	buss	Bioengineering Undergraduate Student Society (BUSS)	The Bioengineering Undergraduate Student Society is a student organization which serves to represent all undergraduate students in the Department of Bioengineering at McGill University. BUSS is dedicated to providing academic and social opportunities to inspire, entertain, and guide its members through their undergraduate degree.	https://buss.mcgilleus.ca/	\N	\N	https://www.facebook.com/BUSSMcGill	https://www.instagram.com/buss.mcgill	2025-01-28 06:48:13.799+00	2025-01-05 17:45:10.873+00	t	\N	\N	\N	\N	\N	\N
264	engineering-games	Engineering Games	Engineering Games (also known as Eng Games, or Jeux de Génie, JDG in French) is a province-wide engineering competition around which a community of engineering undergraduate students from 12 different schools is built. The Games themselves takes place during the first week of January every year, but the participants keep in touch and participate in many social events together year-round.	https://eus.wiki/Engineering_Games	enggames@mcgilleus.ca	\N	https://www.facebook.com/mcgillenggames	\N	2025-01-28 14:16:58.675+00	2025-01-05 17:44:58.699+00	t	\N	\N	\N	\N	\N	\N
263	engineering-adventure-committee	Engineering Adventure Committee	The Engineering Adventure Committee is dedicated to organizing fun and inclusive alcohol-free events for engineering undergraduate students at McGill. If you are interested in participating in exciting and low cost events, their Facebook Page has for more information on upcoming events!	https://eus.wiki/Engineering_Adventure_Committee	eac@mcgilleus.ca	\N	https://www.facebook.com/EngAdventures	\N	2025-01-28 14:17:38.059+00	2025-01-05 17:44:58.312+00	t	\N	\N	\N	\N	\N	\N
260	mustbus	MUSTBUS	MUSTBUS is a student-led initiative focused on providing low-cost transit travel. The organization offers weekend and holiday bus services for McGill students to explore cities like Toronto, New York City, and more. Through the service, they promote student mobility and public transit usage as well as education for the student body.	http://www.mustbuscoop.ca/	mustbus@ssmu.ca	\N	https://www.facebook.com/MUSTBUSCOOP	https://www.instagram.com/mustbuscoop	2025-01-28 14:20:14.369+00	2025-01-05 17:44:56.769+00	t	\N	\N	\N	\N	\N	\N
258	golden-key	Golden Key	The Golden Key chapter at McGill University believes in excellence and strives to provide the best environment possible for guiding our members to achieve in academics, leadership and service. The 246th Golden Key chapter and the 1st in Canada, McGill was chartered April 7, 1997. With more than 9000 members since 1997, the McGill Golden Key chapter is one of the largest chapters in Canada with an average of over 700 members currently at McGill in any given year. Members focus on community service, networking events, and reaching out to make connections with the local community and the entire university student body. They welcome prospective members who are in the top 15% of their class and interested in service and leadership development.	https://www.goldenkey.org/	info@goldenkeymcgill.org	\N	https://www.facebook.com/goldenkeymcgill	https://www.instagram.com/goldenkeymcgill	2025-01-28 14:21:28.653+00	2025-01-05 17:44:55.723+00	t	\N	\N	\N	\N	\N	\N
256	daily-publications-society-the-mcgill-daily-le-dlit	Daily Publications Society – The McGill Daily & Le Délit	The Daily Publications Society is a fully independent, student-run, not-for-profit organisation which publishes two student newspapers at McGill University: The McGill Daily and Le Délit. The McGill Daily began as a daily sports rag in 1911 and has served the McGill community ever since, evolving into its current format as an alternative media outlet. The Daily currently produces one print issue every week, online content, as well as Unfit to Print, its podcast produced in collaboration with CKUT. Le Délit was introduced in 1977. It was first limited to a French section of the regular McGill Daily, then grew to be its own weekly French issue  before separating itself from The Daily in 1979, becoming its sister newspaper. Want to get involved with their papers? The McGill Daily and Le Délit are always looking for new writers and contributors to join their team! As a student at McGill you are already a member of the DPS and have a say in how the papers are run. No experience is necessary!	https://www.dailypublications.org/	ads@dailypublications.org	\N	https://www.facebook.com/DailyPublicationsSociety	\N	2025-02-06 03:20:36.052+00	2025-01-05 17:44:52.563+00	t	\N	\N	\N	\N	\N	\N
252	safely-connected-mcgills-eating-disorder-centre	Safely Connected McGill’s Eating Disorder Centre	Safely Connected McGill is the first post-secondary chapter of the not-for-profit organization Safely Connected. As a part of Safely Connected’s chapters program, it belongs to what will become a network of university based community resources. Run by peers, for peers, Safely Connected McGill has a youth centered approach and understanding to care, education and advocacy. Safely Connected McGill is dedicated to providing and creating inclusive, accessible resources and content that address, acknowledge and break down the white centered, cisnormative, ableist stereotypes and structures of care for eating disorders. Diet culture, fitness culture and fatphobia create unsafe, activating and toxic environments and conceptions of the meaning of food, health and bodies. Safely Connected McGill aims to break down the unrealistic and distorted aims of these forces, to create university campuses that become spaces of care, recognition and understanding, allowing students to connect and heal through community.	https://edrsc.ssmu.ca/	eatingdisorder@ssmu.ca	\N	https://www.facebook.com/safelyconnectedmcgill	https://www.instagram.com/mcgilleatingdisordercentre	2025-02-06 03:24:59.096+00	2025-01-05 17:44:50.513+00	t	\N	\N	\N	\N	\N	\N
250	arab-student-network	Arab Student Network	Since its foundation, the McGill Arab Students' Network (ASN) has represented the Arab population at McGill and introduced the McGill and Montreal community to the rich Arab culture and heritage. Throughout the years, the ASN has expanded in proportion to the increasing number of Arab students on campus and the vast interest in the hosted events expressed by the general McGill community. The ASN offers a diverse range of events and initiatives, some social, some educational, others centered around charity and development. Their goal is to create a tight-knit and active community to make McGill and Montreal feel like home, while also bridging gaps and positively engaging as representatives of their culture with the wider McGill and Montreal community. So whether it's a Middle East enthusiast or just a homesick student craving their homeland's cuisine, the ASN is reaching out. Please note that the ASN has no political or religious affiliation; any charities or initiatives they support are humanitarian or educationally oriented. They stand for international human rights, equality, and justice for all.	https://asnmcgill.ca/	asnmcgill@ssmu.ca	\N	https://www.facebook.com/ASNMcGill	https://www.instagram.com/asnmcgill	2025-02-07 06:11:57.843+00	2025-01-05 17:44:49.452+00	t	\N	\N	\N	\N	\N	\N
248	bsn	Black Students’ Network (BSN)	Founded in 1970 and a service of the SSMU, The Black Students’ Network is available to the entire McGill and Montreal Community. While they are dedicated to addressing the needs and interests of Black students at McGill, all interested students, irrespective of race, culture or creed, are encouraged to participate in our numerous events BSN is a service provided through the Student Society of McGill University, and is available to all McGill students. BSN offers social and political events by and for Black Students, in addition to hosting discussions and providing mentoring and resources. The mission of BSN is to sensitize the McGill community to issues concerning Black peoples and to work towards making the McGill campus safe and accessible for black students in order to support their academic success as well as mental and physical well-being. While dedicated to addressing the needs and interests of Black students, all interested students, irrespective of race, culture or creed, are encouraged to participate in the organization’s numerous events and activities."	https://www.bsnmcgill.com/	bsn@ssmu.ca	\N	https://www.facebook.com/BlackStudentsNetworkOfMcGill	https://www.instagram.com/bsnmcgill	2025-02-07 06:14:34.245+00	2025-01-05 17:44:48.487+00	t	\N	\N	\N	\N	\N	\N
244	mk	Midnight Kitchen	Midnight Kitchen is a non-profit worker and volunteer run collective dedicated to increasing food accessibility on McGill campus and beyond. They support individuals and communities by providing a working alternative to capitalist, profit-driven systems of food production. They also offer education with respect to food politics, social justice issues, food preparation, and urban agriculture. By taking the initiative to produce and distribute food in their own communities, they act in the pursuit of social and environmental justice and support others who share these goals.	https://midnightkitchen.org/	midnightkitchencollective@gmail.com	\N	https://www.facebook.com/midnightkitchencollective	https://www.instagram.com/midnightkitchencollective	2025-02-07 06:17:09.482+00	2025-01-05 17:44:46.681+00	t	\N	\N	\N	\N	\N	\N
239	sacomss	Sexual Assault Centre of the McGill Students’ Society	The Sexual Assault Centre of the McGill Students’ Society (SACOMSS) is a volunteer-run organization committed to supporting survivors of sexual assault and their allies through direct support, advocacy, and outreach. SACOMSS strives to be a pro-survivor, pro-feminist, anti-racist, anti-colonial, anti-ableist, anti-classist, queer-positive, trans-positive, pro-sex worker, and anti-oppressive organization. They provide a safe, accessible and non-judgmental space for members of many different communities and identifications. All their services are open to the public and are provided free of charge.	http://www.sacomss.org/wp	SACOMSS@gmail.com	\N	https://www.facebook.com/sacomss	https://www.instagram.com/sacomss	2025-02-07 06:21:02.318+00	2025-01-05 17:44:44.167+00	t	\N	\N	\N	\N	\N	\N
238	flat-bike-collective	Flat Bike Collective	The Flat Bike Collective is a student run organization at McGill dedicated to promoting cycling as an accessible, affordable, and environmentally friendly mode of transportation. They seek to empower cyclists by encouraging self sufficiency and to foster the cycling community both on and off campus.	http://www.theflat.wordpress.com/	theflat.bikecollective@gmail.com	\N	https://www.facebook.com/TheFlatBikeCollective	https://www.instagram.com/theflatbikecollective	2025-02-07 06:21:17.978+00	2025-01-05 17:44:43.767+00	t	\N	\N	\N	\N	\N	\N
218	mcgill-italian-student-society	McGill Italian Student Society	The McGill Italian Student Society embraces and promotes Italian culture on campus.	\N	MISS@ssmu.ca	\N	https://www.facebook.com/mcgillitalians	https://www.instagram.com/mcgill_iss	2025-02-07 15:08:42.293+00	2025-01-05 17:44:34.407+00	t	\N	\N	\N	\N	\N	\N
237	msert	McGill Students’ Emergency Response Team (MSERT)	The McGill Student Emergency Response Team is a student-run volunteer service, supported by the Students' Society of McGill University. Their mission is to provide a free and accessible first aid service to McGill University and the greater Montreal community. Their team is made up of 75+ dedicated volunteers that are certified First Responders under the Canadian Red Cross. They carry a wide range of first aid equipment, including automated external defibrillators, oxygen tanks, cervical collars, and Epi-Pens, and they operate under nationally-recognized protocols. They respond to all McGill residences, with the exception of Solin Hall, between the hours of 6 PM and 6 AM. As an official training partner of the Canadian Red Cross, they aim to disseminate first aid knowledge and skills to the public, by offering first aid courses and certifications.	http://www.msert.ca/	msert@ssmu.ca	\N	https://www.facebook.com/msertfirstaid	https://www.instagram.com/msert.mcgill	2025-02-14 15:39:28.302+00	2025-01-05 17:44:43.287+00	t	\N	\N	\N	\N	\N	\N
215	mcgill-hellenic-students-association	McGill Hellenic Students Association	The McGill Hellenic Student Association’s mission is to promote Hellenic culture by holding events which unify students of Hellenic descent, and those simply interested in their culture. By promoting an open atmosphere and propagating Hellenic culture, both ancient and modern, they intend to bring the true spirit of Neo-Hellenism to life amongst the members of our organization. Fuelled by a strong Greek spirit, they also hope to create and maintain a sense of community that will always strive to achieve excellence and is a great joy to participate in.	\N	mhsa.exec@ssmu.ca	\N	https://www.facebook.com/McGillHellenicStudentAssociation	https://www.instagram.com/mcgillhellenicstudents	2025-02-07 15:10:31.231+00	2025-01-05 17:44:32.977+00	t	\N	\N	\N	\N	\N	\N
207	isa	Indian Students Association (ISA)	The Indian Students Association at McGill is a student-run organization that upholds Indian culture by celebrating various festivals throughout the year. The events are inclusive, unique, and energetic and will always leave you with a plethora of good memories. As the largest South-asian community on campus, the ISA aims to provide its members with a microcosm of rich Indian traditions. They are the bridge for anyone who wishes to get more involved with Indian culture, whether it’s through food, cinema, music or volunteer projects!	\N	indianstudentsassociation@ssmu.ca	\N	https://www.facebook.com/ISAMcGill	https://www.instagram.com/isamcgillu	2025-02-07 15:23:42.269+00	2025-01-05 17:44:29.275+00	t	\N	\N	\N	\N	\N	\N
196	mcgill-students-for-hanvoice	McGill Students for HanVoice	The McGill chapter for HanVoice is Canada’s leading and largest NGO advocating for North Korean human rights and refugees. Their central goals are to raise awareness for the North Korean humanitarian crisis that is often overlooked in mainstream media within the McGill and general Montreal community through our events and media outlets.	https://mcgillhanvoice.weebly.com/	mcgillhanvoice@ssmu.ca	\N	https://www.facebook.com/McGillHanvoice	https://www.instagram.com/mcgillhanvoice	2025-02-07 15:38:07.13+00	2025-01-05 17:44:24.06+00	t	\N	\N	\N	\N	\N	\N
184	sos	Students Offering Support	Students Offering Support is a national student-led charity made up of a network of student volunteers working through university chapters to coordinate and teach Exam-AID’s (group review sessions prior to midterms/finals for first and second year courses). SOS charges a $20 donation for students to attend sessions and at the end of each year, all the money raised by an SOS chapter is spent on an educational sustainable development project in a Latin American country. These projects are not only funded by SOS, but are also planned and built by SOS volunteers through an annual outreach trip. This full-circle experience provides volunteers an experience to see the direct impact they can have on their community as well as in marginalized communities around the world.	https://ssmu.ca/clubs/networking-and-leadership-development-clubs/students-offering-support-sos-2/	sosmcgillchapter@gmail.com	\N	\N	\N	2025-02-07 15:47:43.395+00	2025-01-05 17:44:17.669+00	f	\N	\N	\N	\N	\N	\N
241	mcgill-students-nightline	McGill Students’ Nightline	514-398-6246 to call, or visit their website for the online chat! McGill Students’ Nightline is a confidential, anonymous and non-judgmental listening service run by McGill students to provide the community with a variety of support. This includes anything from information, to crisis management, to referrals, to a chat on your way home. They are an English service in operation since 1984 open every night of the fall and winter semesters from 6pm to 3am. Feeling stressed, lonely, anxious, depressed, or suicidal? Looking to have a nice chat on your way home? Need to talk but don't think your friends would understand? Confused about booking an appointment at Health Services, Mental Health, or Counseling? Searching for the tastiest late-night pizza, or the closest poutine within a 500m radius? Want to talk about a difficult situation, like a sudden loss, tough relationship, or recent trauma? They're here for all of this (and more!) any night of the week. Give them a call, send them a chat!	https://nightline.ssmu.ca/	nightline@ssmu.ca	514-398-6246	https://www.facebook.com/mcgill.nightline	https://www.instagram.com/nightlinemcgill	2025-02-14 15:37:55.821+00	2025-01-05 17:44:45.091+00	t	\N	\N	\N	\N	\N	\N
204	egyptian-students-association	Egyptian Students Association	The Egyptian Students Association is a group of Egyptian students at McGill University aiming to represent rich culture and heritage on various levels, and to motivate the study body to be actively engaged as well as integrated in the community. They are a student group of the SSMU, an undergraduate students’ society at McGill University. The Egyptian Students’ Association at McGill aims to gather the Egyptian students within McGill University, help Egyptian students to integrate within the McGill environment, organize and build social and cultural events representing the Egyptian culture and heritage, and enhance the relations between the Egyptian and non-Egyptian communities.	\N	egyptianstudentsmcgill@gmail.com	\N	https://www.facebook.com/ESAMcGill	\N	2025-02-18 06:03:35.94+00	2025-01-05 17:44:27.943+00	f	\N	\N	\N	\N	\N	\N
172	mcgill-biomechanics-club	McGill Biomechanics Club	McGill Biomechanics Club innovates medical solutions that help others, by building skills and knowledge through practical experience in biomechanical projects, workshops and events. By combining both practical and social experiences, they aim to teach people more about biomechanics while also helping them to build a social and professional network.	\N	mbc@ssmu.ca	\N	https://www.facebook.com/mcgillbiomechclub	https://www.instagram.com/mcgillbiomechanicsclub	2025-02-18 06:33:11.372+00	2025-01-05 17:44:11.699+00	t	\N	\N	\N	\N	\N	\N
166	redpath-museum-society	Redpath Museum Society	The Redpath Museum Society (RMS) is a student-run organization that works with McGill’s Redpath Museum to provide outreach programs, museum tours, and a variety of events for the McGill community and the general public. RMS members are united by their love of museology, natural history, science, and discovery through activities like Trivia Night, Coffee and Crystals, and Murder Mystery Gala. The RMS also provides students with volunteering opportunities. They welcome anyone with similar passions to join their team of volunteers and help share knowledge with the community – all while building lifelong communication skills and earning diversified co-curricular experiences.	https://redpathmuseumsociety.weebly.com/	redpathmuseumsociety@ssmu.ca	\N	https://www.facebook.com/RedpathMuseumSociety	https://www.instagram.com/redpathmuseumsociety	2025-02-18 06:35:15.855+00	2025-01-05 17:44:08.781+00	t	\N	\N	\N	\N	\N	\N
160	mcgill-students-culinary-society	McGill Students Culinary Society	Through the smells, the sounds, the displays, the textures and the tastes, they invest all five senses in creating and appreciating a dish. Cooking, the unique yet the most prevalent form of art, never cease to add elegance to the everyday life. They believe that people should be eating better foods, and the best foods in the world are yet to be discovered. They strive to arouse enthusiasm for cooking and gastronomy among the McGill community, and provide opportunities for food enthusiasts to display their talents and meet like-minded friends. Their activities include cooking/baking workshops, themed potlucks, outings to restaurants, screening of food documentaries/movies, inventive food sales and more.	https://mcgillculinary.weebly.com/	mcgillculinary@ssmu.ca	\N	https://www.facebook.com/McGillCulinarySociety	https://www.instagram.com/mcgillculinarysociety	2025-02-18 06:38:15.086+00	2025-01-05 17:44:05.619+00	t	\N	\N	\N	\N	\N	\N
149	pih	McGill Students for Partners in Health (PIH)	McGill Students for Partners in Health aims to educate, advocate, and fundraise for global health efforts. Working directly with global NGO Partners in Health Canada, their mission is to bring justice and equity to healthcare. The root of their ambition is a belief in healthcare as a human right.	https://pihcanada.org/get-involved	spihcmcgill@ssmu.ca	\N	https://www.facebook.com/mcgillspihc	https://www.instagram.com/mcgillspihc	2025-02-18 06:43:25.547+00	2025-01-05 17:43:55.983+00	t	\N	\N	\N	\N	\N	\N
148	mcgill-students-chapter-of-jackorg	McGill Students Chapter of Jack.Org	The McGill Students Chapter of Jack.org is a student initiative advocating for youth mental health and well-being both on campus and in the greater Montreal community. They host various events throughout the year including Outreach initiatives as well as de-stress activities in order to initiate conversations surrounding mental health amongst the McGill community. Their goal is to increase mental health awareness and understanding amongst students and young people. They want to open up the conversation about mental health to reach not only the 1 in 5 who experience mental illness but also the 5 in 5 who have mental health.	https://jack.org/chapters/mcgill-university	mscjackdotorg@gmail.com	\N	https://www.facebook.com/mcgilljack.org	https://www.instagram.com/mscjackdotorg	2025-02-18 06:43:47.345+00	2025-01-05 17:43:55.379+00	t	\N	\N	\N	\N	\N	\N
140	somm	School of Music Montreal (SoMM)	The School of Music Montreal (SoMM)’s mission is to promote music education equality to underserved youth in Montreal and across Canada. At SoMM McGill, this primarily means providing free music lessons for students at English-speaking Montreal elementary schools that would otherwise have limited access to music education. McGill students can volunteer as teachers, who help a student learn to play their instrument, or with one of our logistics teams, which assist in event planning, fundraising, finances, administration, and other SoMM operations. You do not have to be a formally trained musician to teach, and speaking French is not required.	https://www.sommontreal.com/	sommontreal@ssmu.ca	\N	https://www.facebook.com/sommontreal	https://www.instagram.com/sommontreal	2025-02-18 06:47:13.383+00	2025-01-05 17:43:51.111+00	f	\N	\N	\N	\N	\N	\N
139	salseros-mcgill	Salseros McGill	Do you love latin music and dance or simply want to learn some fiery dance moves? Come join their fun and lively community! They bring students affordable beginner and intermediate salsa and bachata classes, practice sessions, parties (their Latin Socials) and fabulous outings which introduce students to the Montreal salsa scene.	http://salserosmcgill.weebly.com/	salserosmcgill@ssmu.ca	\N	https://www.facebook.com/SalserosMcGill	https://www.instagram.com/salserosmcgill	2025-02-18 06:47:39.281+00	2025-01-05 17:43:50.687+00	t	\N	\N	\N	\N	\N	\N
138	rdc	Recreational Dance Company (RDC)	RDC is a dance club at McGill! They are a student group of the Students’ Society of McGill University (SSMU), an undergraduate students society at McGill University. RDC offers the opportunity for anyone to learn a variety of dance styles. There are classes a few times a week but no competitions or performances, so if you can’t make it, no stress! Their teachers are all volunteers, meaning that there are no costs except the studio rental, keeping classes affordable. If you are a more experienced dancer, they also hold auditions each semester for our Executive team. Dancers of all styles are always welcome! The Exec team is responsible for choreographing and leading each class, in addition to behind the scenes planning. Outside of the Exec team, the club is open to anyone… no auditions! If you are looking for a recreational club where you can stay fit, make friends and just dance, then RDC is for you!	\N	rdcmcgill@ssmu.ca	\N	https://www.facebook.com/RDCmcgill	https://www.instagram.com/rdc.mcgill	2025-02-18 06:48:16.2+00	2025-01-05 17:43:50.251+00	t	\N	\N	\N	\N	\N	\N
374	shes-the-first	She’s the First	In partnership with the central organization, She’s the First, STF McGill helps provide support and funding to a network of grassroots education organizations in low-income countries, improving outcomes for girls with a sustainable and holistic approach. They are a community of passionate McGill University students working on campus to raise awareness and funds for girls’ education worldwide.	https://stfmcgill.wixsite.com/shesthefirst	shesthefirst@ssmu.ca	\N	https://www.facebook.com/STFMcGill	https://www.instagram.com/stfmcgill	2025-02-27 15:40:10.06+00	2025-01-05 18:22:06.534+00	f	\N	She's The First	En partenariat avec l'organisation She's the First, STF McGill aide à fournir un soutien et un financement à un réseau d'organisations d'éducation de base dans les pays à faible revenu, améliorant les conditions pour les filles grâce à une approche durable et holistique. Il s'agit d'une communauté d'étudiants passionnés qui travaillent sur le campus pour sensibiliser le public et amasser des fonds pour l'éducation des filles au travers monde.	\N	\N	\N
373	the-plumbers-station	The Plumber's Station	The Plumber’s Station is the film club of the McGill EUS. This committee welcomes all film enthusiasts to write, produce, edit video and meet individuals who share their passion for film making. The club encourages all kinds of original projects and gives a chance to its members to partake in various filming and photography events. Through the years, TPS has filmed many student-run and McGill events. They are easily noticeable at various events by our navy crew neck in which ‘Film Crew’ is engaged at the back.	https://eus.wiki/The_Plumber%27s_Station	station@mcgilleus.ca	\N	https://www.facebook.com/ThePlumbersStationMcGill	https://www.instagram.com/theplumbersstationmcgill	2025-02-27 15:45:02.347+00	2025-01-05 18:16:16.092+00	t	\N	The Plumber's Station	The Plumber's Station est le club de cinéma de l'EUS à McGill. Ce comité accueille tous les passionnés de cinéma pour écrire, produire, et monter des vidéos ainsi que rencontrer des individus qui partagent leur passion pour la réalisation. Le club encourage toutes sortes de projets et donne l'occasion à ses membres de participer à divers événements de tournage et de photographie. Au fil des ans, TPS a filmé de nombreux événements organisés par les étudiants et par McGill. Les membres de TPS sont facilement reconnaissables lors de ces événements grâce à leur col bleu marine sur lequel on peut lire « Film Crew » à l'arrière.\n	\N	\N	\N
376	the-mcgill-chavurah	The McGill Chavurah	The McGill Chavurah is a community intent on creating inclusive spaces for Jewish students. They host regular shabbat services and other events in the McGill neighbourhood which aim to integrate the peace and comfort of shared jewish experience into the hectic feeling of student life. They are progressive, sustainable, inclusive, traditional, non-hierarchical, and egalitarian in both structure and practice evolving to fit the needs of their changing community every year.	https://mcgillchavurah.wordpress.com		\N	https://www.facebook.com/themcgillchavurah	\N	2025-03-02 01:19:18.047+00	2025-01-05 18:22:53.909+00	t	\N	Chavurah de McGill	Le Chavurah de McGill est une communauté qui a pour but de créer des espaces inclusifs pour les étudiants juifs. Ils organisent régulièrement des services de shabbat et d'autres événements dans le quartier de McGill qui visent à intégrer la paix et le confort d'une expérience juive partagée dans l'effervescence de la vie étudiante. Ils sont progressistes, durables, inclusifs, traditionnels, non hiérarchiques et égalitaires, tant dans leur structure que dans leur pratique, et évoluent toujours pour répondre aux besoins de leur communauté dynamique.	15	Musical Havdallah	\N
\.


--
-- Data for Name: clubs_other_socials; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clubs_other_socials (_order, _parent_id, id, link) FROM stdin;
1	199	677ac4f94316710f71cf3660	https://www.linkedin.com/company/mcgill-belgian-student-society
1	177	677ac4ee4316710f71cf3651	https://www.linkedin.com/company/mcgillsts
1	173	677ac4ec4316710f71cf364f	https://www.linkedin.com/company/mcgill-debating-union/mycompany
1	162	677ac4e64316710f71cf364b	http://www.twitter.com/AniMcGill
1	150	677ac4dc4316710f71cf3647	https://www.linkedin.com/company/mcgillssat/mycompany
1	149	677ac4db4316710f71cf3646	http://www.twitter.com/studentsforpih
1	147	677ac4da4316710f71cf3644	https://www.linkedin.com/company/18993263/admin
1	143	677ac4d84316710f71cf3640	https://www.youtube.com/channel/UCReU4xLzSoynd73ehkhArtg
1	364	677acc3840e3021cf8608ed5	http://www.twitter.com/esportsmcgill,
2	364	677acc3840e3021cf8608ed6	https://www.youtube.com/channel/UCpD5BG4YL7qLC25NsAdWHzw/discussion
1	377	677acdfef162671e889a9391	https://www.linkedin.com/company/licm-cijm
1	375	677acdd0f162671e889a938f	https://www.linkedin.com/company/blockchain-at-mcgill
2	375	677acdd0f162671e889a9390	http://www.twitter.com/blockchainmcg
1	48	677ac4a34316710f71cf3605	http://www.twitter.com/BWV_McGill
1	69	677ac4ae4316710f71cf3617	https://www.linkedin.com/company/desautels-exchange-network/about
1	78	677ac4b34316710f71cf3620	https://www.linkedin.com/company/redpointcapital
1	83	677ac4b64316710f71cf3625	http://www.twitter.com/mcgillcsa
1	91	677ac4bb4316710f71cf3628	http://www.twitter.com/McGillQuidditch
1	110	677ac4c94316710f71cf362f	https://www.youtube.com/channel/UCSZAMYlVzvvOYuzrwn34Ndw
1	129	677ac4d24316710f71cf363a	https://www.youtube.com/channel/UC57hHM5J83Xr62Zj1XOrarw
1	141	677ac4d74316710f71cf363f	https://www.youtube.com/user/soulsticeacappella
1	145	677ac4d94316710f71cf3642	https://www.youtube.com/c/TonalEcstasy
1	146	677ac4d94316710f71cf3643	https://www.youtube.com/channel/UCBJXjYmmU50I_RWQoIeYo1w
1	153	677ac4e14316710f71cf3648	https://www.linkedin.com/company/the-meditation-club-at-mcgill
1	185	677ac4f24316710f71cf3656	http://www.twitter.com/wiiscanada
1	176	677ac4ed4316710f71cf3650	http://www.twitter.com/_scientista_
1	172	677ac4eb4316710f71cf364d	https://www.linkedin.com/company/mcgillbiomechanicsclub/about
1	170	677ac4ea4316710f71cf364c	https://ca.linkedin.com/company/mcgill-igem
1	374	677acdcef162671e889a938d	https://www.linkedin.com/company/she-s-the-first-mcgill/mycompany
2	374	677acdcef162671e889a938e	http://www.twitter.com/stf_mcgill
1	202	677ac4fa4316710f71cf3662	http://www.twitter.com/McGillChabad
1	216	677ac5014316710f71cf3668	http://www.twitter.com/McGill_MISA
1	290	677ac7655f200b12e0e46e1c	https://twitter.com/BUGS_McGill
2	290	677ac7655f200b12e0e46e1d	https://www.linkedin.com/company/mcgill-biochemistry-undergraduate-society-bugs/about
1	317	677ac77c5f200b12e0e46e31	https://www.linkedin.com/company/mpma-mcgill
1	325	677ac7805f200b12e0e46e35	https://www.linkedin.com/company/mcgill-industrial-relations-association
1	329	677ac7855f200b12e0e46e36	https://www.linkedin.com/company/enactus-mcgill
1	346	677ac79d5f200b12e0e46e3d	https://www.linkedin.com/company/blockchain-at-mcgill
1	160	677ac4e54316710f71cf364a	https://www.linkedin.com/company/84087242/admin
1	144	677ac4d84316710f71cf3641	https://www.youtube.com/c/McGillSavoySociety
1	369	677acc6440e3021cf8608ee0	https://www.linkedin.com/company/mcgill-koreans'-educational-&-cultural-association/mycompany
1	7	677ac3c529ad390cba4ee0f9	http://www.twitter.com/heal_and_hope
1	8	677ac3c529ad390cba4ee0fa	https://www.linkedin.com/company/mcconnect-mcgill/about/
1	9	677ac3d829ad390cba4ee119	http://www.twitter.com/Crgreview
1	12	677ac3df29ad390cba4ee124	http://www.twitter.com/McGillWiCS
1	13	677ac3e029ad390cba4ee126	http://www.twitter.com/McGillHacks
1	14	677ac3e729ad390cba4ee139	https://www.linkedin.com/company/mcgillmass/about/
1	357	677ac7b65f200b12e0e46e47	https://www.linkedin.com/company/nobemcgill
1	356	677ac7b65f200b12e0e46e46	https://www.linkedin.com/company/mcgill-eia
1	15	677ac3ea29ad390cba4ee13f	https://www.linkedin.com/company/mcgill-lebanese-student-s-association/
1	16	677ac3ef29ad390cba4ee147	http://www.twitter.com/ThePlateClub
1	17	677ac3f129ad390cba4ee153	http://www.twitter.com/aiesecmcgill
2	17	677ac3f129ad390cba4ee154	https://www.youtube.com/user/aiesecglobal
1	355	677ac7b35f200b12e0e46e44	https://linktr.ee/eusjuniorcouncil
1	353	677ac7aa5f200b12e0e46e42	https://www.linkedin.com/company/moroccan-students-society/about
2	353	6793bbea7607dd7722518e02	https://www.instagram.com/mss.mcgill/
1	20	677ac4924316710f71cf35f6	https://www.linkedin.com/company/scienceundergraduatesociety
1	367	677acc5c40e3021cf8608ede	http://www.twitter.com/@democratsmcgill
1	365	677acc3c40e3021cf8608ed7	http://www.twitter.com/@gpmcgill
1	362	677ac7b95f200b12e0e46e4c	https://www.linkedin.com/company/mcgill-biodesign-team
1	361	677ac7b85f200b12e0e46e4b	https://www.linkedin.com/company/vfsmcgill
1	360	677ac7b85f200b12e0e46e4a	https://www.linkedin.com/company/reboot-mcgill-nonprofit-organization
1	359	677ac7b75f200b12e0e46e49	https://www.linkedin.com/company/powemcgill
1	358	677ac7b75f200b12e0e46e48	https://www.linkedin.com/company/nsbemcgill
1	368	677acc5f40e3021cf8608edf	http://www.twitter.com/@sphrmcgill
1	347	677ac79e5f200b12e0e46e3e	https://www.linkedin.com/company/mcgill-women-in-leadership
1	33	677ac49a4316710f71cf35fe	https://www.linkedin.com/company/mcgill-chemical-engineering-student-society
1	35	6793c1467c6ff15e358b7c69	https://www.linkedin.com/company/mcgillminingeus/
1	40	677ac49e4316710f71cf35ff	https://twitter.com/MSSMcGill
1	43	677ac4a04316710f71cf3602	https://www.youtube.com/user/McGillOutdoorsClub
1	47	677ac4a34316710f71cf3604	http://www.twitter.com/SSMUSki
1	49	677ac4a44316710f71cf3606	https://www.linkedin.com/company/11752274/admin
1	50	677ac4a44316710f71cf3607	https://www.youtube.com/channel/UCB-DMNT-BNERpYfPlcl_HIg
2	50	6793c73b7c6ff15e358b7c6a	https://medium.com/@esgmcgill
1	53	677ac4a64316710f71cf3609	https://www.youtube.com/channel/UCNl2TY5y1ax8gW4FvQ2BUjg
1	54	677ac4a64316710f71cf360b	http://www.twitter.com/H4HCharity
2	54	6793c9a67c6ff15e358b7c6b	https://www.tiktok.com/@heart4heart_mcgill
1	56	677ac4a74316710f71cf360c	https://twitter.com/rtpmcgill
1	58	677ac4a84316710f71cf360d	http://www.twitter.com/unicefmcgill
1	59	677ac4a94316710f71cf360e	https://www.linkedin.com/company/mcgill-students-for-world-vision
1	11	677ac3dc29ad390cba4ee11d	http://www.twitter.com/CNSA1
1	68	677ac4ae4316710f71cf3616	https://www.linkedin.com/company/mcgill-entrepreneurship-society
1	70	677ac4af4316710f71cf3618	https://www.linkedin.com/company/mcgill-asia-business-association/about
1	71	677ac4af4316710f71cf361a	https://www.linkedin.com/company/mcgill-investment-club
1	74	677ac4b14316710f71cf361b	https://www.linkedin.com/company/mcgillconsulting
1	76	677ac4b24316710f71cf361d	https://www.linkedin.com/company/desautels-sustainabilitynetwork
1	77	677ac4b24316710f71cf361f	https://www.linkedin.com/company/real-estate-club-at-mcgill-university/about
1	80	677ac4b44316710f71cf3622	https://www.linkedin.com/company/anthromcgill
1	94	677ac4bc4316710f71cf3629	http://www.twitter.com/McGillUltimate
1	103	677ac4c14316710f71cf362b	http://www.twitter.com/MCHAM_McGill
1	104	677ac4c24316710f71cf362c	https://www.linkedin.com/company/jam-for-justice/about
1	112	677ac4ca4316710f71cf3630	https://twitter.com/projetmontreal
1	116	679578270badae0f3c4109ea	https://www.youtube.com/channel/UCbWdGvaRs5ZaWocpKJWs3DA
1	117	677ac4cc4316710f71cf3631	https://www.youtube.com/channel/UCiqTJQ7FOgore3C-OPr_l8Q
1	118	677ac4cc4316710f71cf3632	https://www.youtube.com/channel/UCUGJYtbVWZknbgSbCew8EGA
1	119	677ac4cd4316710f71cf3633	https://www.linkedin.com/company/circle-of-fashion-mcgill
1	121	677ac4cd4316710f71cf3634	https://dsignlabmcgill.wixsite.com/monsite/about
1	122	677ac4ce4316710f71cf3635	https://www.youtube.com/c/EffusionACappella
1	124	677ac4cf4316710f71cf3636	https://www.youtube.com/user/InertiaModernDanceCo
1	125	677ac4cf4316710f71cf3637	https://www.youtube.com/user/kraveKPOPclub
1	140	677ac4d74316710f71cf363e	https://www.youtube.com/channel/UCgEzFRZBNohZ5RdscNac1bQ
1	139	677ac4d64316710f71cf363d	http://www.twitter.com/McGillSalseros
1	137	677ac4d54316710f71cf363c	http://www.twitter.com/McGillPlayers
1	339	677ac7965f200b12e0e46e3c	https://www.linkedin.com/company/counterpoint-music-magazine
1	338	677ac7915f200b12e0e46e3b	http://www.twitter.com/UAEMMcGill
1	333	677ac78b5f200b12e0e46e3a	https://www.youtube.com/user/McGillChoralSociety/featured
1	332	677ac78a5f200b12e0e46e39	https://www.youtube.com/channel/UCOVF6MmBeD58-Tp3ydCkdsw/videos
1	331	677ac7875f200b12e0e46e38	https://ca.linkedin.com/company/mucda
1	330	677ac7865f200b12e0e46e37	https://ca.linkedin.com/company/mcgill-students-for-geriatric-health
1	321	677ac77e5f200b12e0e46e34	https://ca.linkedin.com/company/mcgill-economics-students-association-esa
1	319	677ac77d5f200b12e0e46e33	https://www.linkedin.com/company/csaus
1	318	677ac77c5f200b12e0e46e32	https://ca.linkedin.com/company/mcgill-art-history-and-communications-student-society-association
1	316	677ac77b5f200b12e0e46e30	https://www.linkedin.com/company/pennydrops
1	315	677ac77a5f200b12e0e46e2f	https://www.linkedin.com/company/mcgillmarketingnetwork
1	314	677ac7795f200b12e0e46e2e	https://www.linkedin.com/company/ima-mcgill
1	311	677ac7765f200b12e0e46e2a	https://www.linkedin.com/company/the-refugee-centre
1	131	677ac4d34316710f71cf363b	https://www.youtube.com/mcgillimprov
1	307	677ac7715f200b12e0e46e25	https://www.linkedin.com/company/mcgill-table-tennis-club/about
1	51	677ac4a54316710f71cf3608	https://twitter.com/fit_for_a_cause
1	295	677ac7685f200b12e0e46e22	https://twitter.com/mugslounge
1	294	677ac7685f200b12e0e46e21	https://twitter.com/mcgillcsus
1	293	677ac7675f200b12e0e46e20	https://twitter.com/mbsumcgill
1	292	677ac7675f200b12e0e46e1f	https://twitter.com/aossum1
1	291	677ac7665f200b12e0e46e1e	https://twitter.com/misacouncil
1	373	677acc7040e3021cf8608ee2	https://www.youtube.com/channel/UCx7REwIt-qeIGq9Ygl4pChw
1	288	677ac5274316710f71cf3692	https://www.linkedin.com/company/codejam
1	286	677ac5264316710f71cf3691	https://ca.linkedin.com/company/mcgill-robotics
1	285	677ac5254316710f71cf3690	https://www.linkedin.com/company/mcgillbajaracing
1	281	677ac5234316710f71cf368f	https://www.linkedin.com/company/11382251
1	280	677ac5234316710f71cf368c	https://www.linkedin.com/company/student-energy-at-mcgill-university
1	278	677ac5214316710f71cf3687	https://www.linkedin.com/company/mcgill-flying-club/about
1	274	677ac51f4316710f71cf3685	https://www.linkedin.com/company-beta/2772838
1	269	677ac51d4316710f71cf3683	https://www.linkedin.com/company/seammcgill/about
1	260	677ac5184316710f71cf3681	https://www.linkedin.com/company/mustbus
1	259	677ac5184316710f71cf367f	https://twitter.com/irsaminc
1	257	677ac5154316710f71cf367e	https://www.linkedin.com/company/ecoleproject/about
1	256	677ac5144316710f71cf367d	http://www.twitter.com/mcgilldaily
1	255	677ac5144316710f71cf367c	https://www.linkedin.com/company/ckut-radio
1	254	677ac5134316710f71cf367b	https://www.linkedin.com/company/mcgill-tribune
1	253	677ac5124316710f71cf367a	https://www.youtube.com/channel/UCStjoJmI-HCfzH7RWhdckgg
1	252	677ac5124316710f71cf3679	https://www.linkedin.com/company/eating-disorder-resource-support-centre
1	251	677ac5124316710f71cf3678	https://www.youtube.com/user/MSAMcGill
1	250	677ac5114316710f71cf3677	https://www.linkedin.com/company/mcgillasn/about
1	249	677ac5104316710f71cf3676	https://www.linkedin.com/company/ssmu-musicians-collective/about
1	248	677ac5104316710f71cf3675	https://www.youtube.com/channel/UCc80zeistjlPU2ApkEF0hLw
1	247	677ac50f4316710f71cf3674	https://www.youtube.com/user/TVMTelevision
1	246	677ac50f4316710f71cf3673	https://www.linkedin.com/company/ssmu-walksafe/about
1	245	677ac50f4316710f71cf3672	http://www.twitter.com/SSMUDriveSafe
1	244	677ac50e4316710f71cf3671	https://www.linkedin.com/company/the-midnight-kitchen_mcgill/about
1	243	677ac50d4316710f71cf3670	http://www.twitter.com/queermcgill
1	242	677ac50d4316710f71cf366f	https://www.linkedin.com/company/the-union-for-gender-empowerment
1	240	677ac50c4316710f71cf366d	https://www.linkedin.com/company/peersupportcenter/about
1	231	677ac5084316710f71cf366b	http://www.twitter.com/P2CMcGill
1	214	677ac5004316710f71cf3667	http://www.twitter.com/McGillDharma
1	212	677ac4ff4316710f71cf3666	https://www.linkedin.com/company/mcssmcgill
1	207	677ac4fd4316710f71cf3664	https://www.linkedin.com/company/mcgill-indian-students-association/mycompany
1	203	677ac4fb4316710f71cf3663	https://www.linkedin.com/company/mcgill-chinese-students-and-scholars-association
1	201	677ac4fa4316710f71cf3661	https://www.linkedin.com/company/the-caribbean-students-society-of-mcgill-university
1	197	677ac4f84316710f71cf365f	https://www.youtube.com/channel/UCXWwyi_B0gZKXZapfXj2Zog
1	196	677ac4f84316710f71cf365d	http://www.twitter.com/McGillHanVoice
1	195	677ac4f74316710f71cf365c	http://www.twitter.com/WarChildCan
1	193	677ac4f54316710f71cf365b	http://www.twitter.com/LiberalmcGill
1	189	677ac4f44316710f71cf365a	https://www.linkedin.com/company/mcgill-fomsf
1	188	677ac4f34316710f71cf3659	http://www.twitter.com/expandingecon
1	186	677ac4f24316710f71cf3657	https://ca.linkedin.com/company/women-in-tech-wit
1	184	677ac4f14316710f71cf3655	http://www.twitter.com/SOSMcGillU
1	180	677ac4ef4316710f71cf3654	https://at.linkedin.com/company/research-and-sustainability-network
1	179	677ac4ef4316710f71cf3653	http://www.twitter.com/mcgillmedspecs
1	241	677ac50d4316710f71cf366e	https://www.linkedin.com/company/mcgill-students-nightline/about
1	237	677ac50b4316710f71cf366c	http://www.twitter.com/MSERTFirstaid
1	211	677ac4ff4316710f71cf3665	https://www.linkedin.com/company/manaba
\.


--
-- Data for Name: clubs_rels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clubs_rels (id, "order", parent_id, path, club_tags_id) FROM stdin;
1196	1	46	tags	108
1197	2	46	tags	124
1769	1	180	tags	117
1770	2	180	tags	123
1771	3	180	tags	115
1209	1	52	tags	122
1210	2	52	tags	120
1211	1	53	tags	122
1212	2	53	tags	120
1220	1	58	tags	122
1221	2	58	tags	120
1226	1	61	tags	122
13	1	4	tags	108
14	2	4	tags	124
1227	2	61	tags	120
1228	1	62	tags	122
1229	2	62	tags	120
1230	3	62	tags	113
1231	1	63	tags	122
1232	2	63	tags	120
1233	3	63	tags	124
1246	1	11	tags	117
1247	2	11	tags	115
1248	1	18	tags	121
1255	1	68	tags	117
1256	2	68	tags	115
1257	3	68	tags	111
1258	4	68	tags	134
1262	1	71	tags	117
1263	2	71	tags	115
1264	3	71	tags	112
1265	4	71	tags	134
1266	1	72	tags	117
1267	2	72	tags	115
1268	3	72	tags	110
1269	4	72	tags	134
1270	1	73	tags	117
1271	2	73	tags	124
1272	3	73	tags	125
1273	4	73	tags	134
1274	1	74	tags	117
1275	2	74	tags	115
1276	3	74	tags	110
1277	4	74	tags	134
1278	1	76	tags	117
1279	2	76	tags	115
1280	3	76	tags	123
1281	4	76	tags	134
1282	1	77	tags	117
50	1	19	tags	117
51	2	19	tags	115
52	3	19	tags	132
1283	2	77	tags	115
1284	3	77	tags	118
1285	4	77	tags	134
1286	1	80	tags	128
1287	2	80	tags	117
1288	3	80	tags	115
1289	4	80	tags	129
1290	1	81	tags	128
1291	2	81	tags	117
1292	3	81	tags	115
1293	4	81	tags	129
1294	1	84	tags	128
1295	2	84	tags	117
1296	3	84	tags	115
1297	4	84	tags	129
1474	1	310	tags	122
1475	2	310	tags	120
1813	1	204	tags	126
1669	1	224	tags	126
1302	1	85	tags	128
73	1	25	tags	117
74	2	25	tags	115
75	3	25	tags	128
76	4	25	tags	139
1303	2	85	tags	117
1304	3	85	tags	115
1305	4	85	tags	129
1333	1	97	tags	122
1334	2	97	tags	120
1335	3	97	tags	113
1336	1	98	tags	122
1337	2	98	tags	120
1338	3	98	tags	123
1339	1	100	tags	113
1340	2	100	tags	117
1341	3	100	tags	115
1346	1	106	tags	122
1347	2	106	tags	123
1350	1	109	tags	122
1351	2	109	tags	113
1352	3	109	tags	120
1355	1	115	tags	122
1356	2	115	tags	120
1670	2	224	tags	115
1814	2	204	tags	115
1817	1	177	tags	117
1385	1	345	tags	117
1386	2	345	tags	115
1387	1	344	tags	124
1818	2	177	tags	112
1389	1	343	tags	124
1397	1	337	tags	109
1398	2	337	tags	126
1399	3	337	tags	127
1403	1	334	tags	109
1404	2	334	tags	107
1405	3	334	tags	124
1408	1	332	tags	107
1409	2	332	tags	124
1412	1	330	tags	113
1413	1	328	tags	122
1414	2	328	tags	120
1427	1	326	tags	128
1428	2	326	tags	117
1429	3	326	tags	115
1430	4	326	tags	129
1451	1	318	tags	128
1452	2	318	tags	117
1453	3	318	tags	115
1454	4	318	tags	129
1455	1	316	tags	120
1456	2	316	tags	112
1457	3	316	tags	124
1458	4	316	tags	134
1463	1	314	tags	117
1464	2	314	tags	115
1465	3	314	tags	134
1819	3	177	tags	115
1822	1	175	tags	113
1723	1	196	tags	122
1724	2	196	tags	120
1725	1	195	tags	122
1726	2	195	tags	120
1746	1	187	tags	117
1747	2	187	tags	115
1748	3	187	tags	120
139	1	42	tags	108
140	2	42	tags	124
1749	1	186	tags	117
1750	2	186	tags	115
1751	3	186	tags	119
1755	1	183	tags	117
1756	2	183	tags	115
1823	2	175	tags	128
1824	1	174	tags	115
1825	2	174	tags	126
1826	1	173	tags	117
1830	1	171	tags	117
151	1	48	tags	122
152	2	48	tags	120
1831	2	171	tags	115
1837	1	168	tags	122
1838	2	168	tags	120
1839	1	167	tags	117
1840	2	167	tags	124
1476	1	309	tags	108
1477	2	309	tags	124
1478	1	308	tags	108
1479	2	308	tags	124
1772	1	179	tags	117
168	1	55	tags	122
169	2	55	tags	120
1773	2	179	tags	113
1482	1	307	tags	108
1483	2	307	tags	124
1683	1	218	tags	126
1684	2	218	tags	115
1685	1	220	tags	126
1686	2	220	tags	127
1687	1	217	tags	126
1688	2	217	tags	127
1689	1	215	tags	126
1690	2	215	tags	115
1691	1	214	tags	126
1692	2	214	tags	127
1705	1	207	tags	126
1706	2	207	tags	115
1713	1	203	tags	126
1714	2	203	tags	115
1715	1	201	tags	126
1716	2	201	tags	115
1717	1	200	tags	126
1718	2	200	tags	115
1719	1	198	tags	126
1720	2	198	tags	115
1774	3	179	tags	115
1775	1	178	tags	117
1734	1	192	tags	122
1735	2	192	tags	125
1736	1	191	tags	120
1737	2	191	tags	122
1738	3	191	tags	126
1776	2	178	tags	112
1777	3	178	tags	115
1815	1	199	tags	126
205	1	69	tags	115
206	2	69	tags	134
1816	2	199	tags	115
1820	1	176	tags	117
1821	2	176	tags	115
1827	1	172	tags	117
1828	2	172	tags	119
1829	3	172	tags	113
1832	1	170	tags	117
1833	2	170	tags	115
1834	1	169	tags	117
1835	2	169	tags	115
1836	3	169	tags	113
1914	1	373	tags	115
1915	2	373	tags	124
1916	3	373	tags	132
226	1	75	tags	117
227	2	75	tags	115
228	3	75	tags	119
229	4	75	tags	134
238	1	78	tags	117
239	2	78	tags	115
240	3	78	tags	112
241	4	78	tags	134
242	1	79	tags	128
243	2	79	tags	117
244	3	79	tags	115
245	4	79	tags	129
254	1	82	tags	128
255	2	82	tags	117
256	3	82	tags	115
257	4	82	tags	129
258	1	83	tags	128
259	2	83	tags	117
260	3	83	tags	115
261	4	83	tags	129
274	1	87	tags	128
275	2	87	tags	117
276	3	87	tags	115
277	4	87	tags	129
290	1	91	tags	108
291	2	91	tags	124
309	1	99	tags	124
310	2	99	tags	126
314	1	101	tags	122
315	2	101	tags	120
316	1	102	tags	122
317	2	102	tags	119
1484	1	306	tags	108
1485	2	306	tags	124
322	1	105	tags	122
1497	1	302	tags	117
1498	2	302	tags	115
325	1	107	tags	122
326	2	107	tags	120
1499	3	302	tags	128
1500	4	302	tags	136
1513	1	298	tags	117
1514	2	298	tags	115
1515	3	298	tags	128
332	1	110	tags	122
333	2	110	tags	107
334	1	111	tags	122
1516	4	298	tags	139
1537	1	292	tags	117
337	1	114	tags	122
1538	2	292	tags	115
1539	3	292	tags	128
1540	4	292	tags	139
1553	1	286	tags	117
1554	2	286	tags	115
1555	3	286	tags	124
1565	1	281	tags	117
1566	2	281	tags	115
1567	3	281	tags	132
1570	1	279	tags	117
1571	2	279	tags	115
1572	3	279	tags	132
1591	1	265	tags	121
1592	2	265	tags	132
1593	1	264	tags	115
1594	2	264	tags	124
354	1	123	tags	107
355	2	123	tags	124
1595	3	264	tags	132
1604	1	259	tags	115
1605	2	259	tags	117
1606	3	259	tags	129
1607	1	258	tags	115
1608	2	258	tags	117
1841	1	166	tags	124
1611	1	257	tags	123
1612	2	257	tags	122
366	1	128	tags	107
367	2	128	tags	124
368	1	129	tags	107
369	2	129	tags	124
370	3	129	tags	126
375	1	132	tags	106
376	2	132	tags	124
396	1	141	tags	107
397	2	141	tags	124
405	1	145	tags	107
406	2	145	tags	124
407	1	146	tags	107
408	2	146	tags	109
409	3	146	tags	124
424	1	153	tags	127
425	2	153	tags	124
428	1	155	tags	117
429	2	155	tags	125
432	1	157	tags	122
433	2	157	tags	126
435	1	159	tags	124
439	1	163	tags	124
1842	1	165	tags	124
1843	1	164	tags	124
1844	1	162	tags	124
1845	1	161	tags	124
1850	1	154	tags	122
1851	2	154	tags	113
1852	1	152	tags	122
1853	2	152	tags	113
1854	3	152	tags	123
1855	1	151	tags	122
1613	1	256	tags	125
1856	2	151	tags	113
1857	1	150	tags	122
1858	2	150	tags	113
1859	1	149	tags	122
1860	2	149	tags	113
1861	3	149	tags	120
1864	1	147	tags	115
1865	2	147	tags	117
1868	1	143	tags	109
1869	2	143	tags	124
1870	3	143	tags	126
1871	1	142	tags	107
1872	2	142	tags	124
1877	1	138	tags	109
1878	2	138	tags	107
1879	3	138	tags	124
1885	1	135	tags	109
1886	2	135	tags	126
1887	3	135	tags	124
1888	1	134	tags	124
1889	1	133	tags	109
1890	2	133	tags	107
1891	3	133	tags	124
1846	1	160	tags	124
1847	1	158	tags	124
1848	1	156	tags	124
1781	1	372	tags	117
1782	2	372	tags	115
1783	3	372	tags	132
1784	1	241	tags	121
1787	1	233	tags	126
1788	2	233	tags	115
1789	1	230	tags	126
487	1	185	tags	122
488	2	185	tags	115
1790	2	230	tags	115
1791	1	229	tags	126
1792	2	229	tags	115
1811	1	210	tags	126
1812	2	210	tags	115
1849	2	156	tags	125
1862	1	148	tags	122
1863	2	148	tags	113
1866	1	144	tags	107
1867	2	144	tags	124
1873	1	140	tags	122
1874	1	139	tags	109
1875	2	139	tags	126
1876	3	139	tags	124
1880	1	137	tags	107
1881	2	137	tags	124
1882	1	136	tags	109
1883	2	136	tags	107
1884	3	136	tags	124
526	1	202	tags	126
527	2	202	tags	115
554	1	216	tags	126
555	2	216	tags	115
1785	1	237	tags	113
1786	2	237	tags	121
636	1	261	tags	121
637	2	261	tags	132
1799	1	223	tags	126
1800	2	223	tags	127
1801	1	222	tags	126
1802	2	222	tags	115
1807	1	213	tags	126
1808	2	213	tags	127
1809	1	211	tags	126
1810	2	211	tags	115
1892	1	131	tags	124
1893	2	131	tags	107
1894	1	130	tags	107
1895	2	130	tags	124
650	1	266	tags	115
651	2	266	tags	121
652	3	266	tags	124
653	4	266	tags	132
654	1	267	tags	117
655	2	267	tags	115
656	3	267	tags	132
1896	1	364	tags	124
663	1	270	tags	125
664	2	270	tags	132
667	1	272	tags	124
668	2	272	tags	132
678	1	276	tags	119
679	2	276	tags	115
680	3	276	tags	132
681	1	277	tags	117
682	2	277	tags	115
683	3	277	tags	132
700	1	284	tags	117
701	2	284	tags	115
702	3	284	tags	132
714	1	289	tags	121
715	2	289	tags	132
716	1	290	tags	117
717	2	290	tags	115
718	3	290	tags	128
719	4	290	tags	139
760	1	301	tags	117
761	2	301	tags	115
762	3	301	tags	128
763	4	301	tags	132
1486	1	305	tags	108
1487	2	305	tags	124
1488	1	304	tags	108
1489	2	304	tags	124
1490	1	303	tags	117
1491	2	303	tags	115
1492	3	303	tags	128
1493	4	303	tags	138
1494	1	51	tags	122
1495	2	51	tags	120
1496	3	51	tags	108
1505	1	300	tags	117
1506	2	300	tags	115
1507	3	300	tags	128
1508	4	300	tags	132
1509	1	299	tags	117
1510	2	299	tags	115
1511	3	299	tags	128
1512	4	299	tags	136
1517	1	297	tags	117
1518	2	297	tags	115
1519	3	297	tags	128
1520	4	297	tags	139
1521	1	296	tags	117
1522	2	296	tags	115
1523	3	296	tags	128
1524	4	296	tags	139
1525	1	295	tags	117
1526	2	295	tags	115
1527	3	295	tags	128
1528	4	295	tags	139
1529	1	294	tags	117
1530	2	294	tags	115
1531	3	294	tags	128
1532	4	294	tags	139
1533	1	293	tags	117
1534	2	293	tags	115
1535	3	293	tags	128
1536	4	293	tags	139
1541	1	291	tags	117
1542	2	291	tags	115
1543	3	291	tags	128
1544	4	291	tags	139
1547	1	288	tags	117
1548	2	288	tags	115
1549	1	287	tags	117
1550	2	287	tags	115
1551	3	287	tags	128
1552	4	287	tags	132
1556	1	285	tags	124
1557	2	285	tags	115
1558	1	283	tags	117
1559	2	283	tags	115
1560	3	283	tags	124
1561	4	283	tags	132
1562	1	282	tags	117
1563	2	282	tags	115
1564	3	282	tags	132
1568	1	280	tags	123
1569	2	280	tags	122
1573	1	278	tags	124
1596	1	263	tags	115
1597	2	263	tags	121
1598	3	263	tags	124
1599	4	263	tags	132
1600	1	262	tags	115
1601	2	262	tags	117
1602	3	262	tags	132
1603	1	260	tags	121
1614	2	256	tags	122
1615	1	255	tags	122
1616	1	254	tags	125
1617	2	254	tags	122
1618	1	253	tags	120
1619	2	253	tags	122
1620	1	252	tags	121
1701	1	209	tags	126
1702	2	209	tags	115
1703	1	208	tags	126
1704	2	208	tags	115
1707	1	206	tags	126
1708	2	206	tags	115
1709	1	205	tags	126
1710	2	205	tags	115
1721	1	197	tags	122
1722	2	197	tags	116
1727	1	194	tags	122
1728	2	194	tags	116
1729	1	193	tags	122
1730	2	193	tags	116
1731	3	193	tags	117
1739	1	190	tags	122
1740	1	189	tags	115
1741	2	189	tags	122
1742	3	189	tags	115
1743	1	188	tags	117
1744	2	188	tags	115
1745	3	188	tags	122
1752	1	184	tags	120
1753	2	184	tags	122
1754	3	184	tags	123
1574	1	275	tags	124
1575	2	275	tags	115
1576	3	275	tags	132
1583	1	271	tags	125
1584	2	271	tags	132
1621	1	251	tags	126
1622	2	251	tags	127
1623	1	250	tags	126
1624	2	250	tags	115
1625	1	249	tags	115
1626	2	249	tags	107
1627	3	249	tags	124
1628	1	248	tags	126
1629	2	248	tags	115
805	1	317	tags	117
806	2	317	tags	115
807	3	317	tags	114
808	4	317	tags	134
1630	1	247	tags	121
1632	1	245	tags	121
1634	1	243	tags	121
1635	1	242	tags	121
1897	2	364	tags	128
1637	1	240	tags	121
1638	1	239	tags	121
1639	1	238	tags	123
1640	2	238	tags	121
1643	1	236	tags	126
1644	2	236	tags	115
1645	3	236	tags	128
1646	1	235	tags	126
1647	2	235	tags	115
1648	3	235	tags	128
1649	1	234	tags	126
1650	2	234	tags	115
829	1	323	tags	128
830	2	323	tags	117
831	3	323	tags	115
832	4	323	tags	129
1653	1	232	tags	126
1654	2	232	tags	115
837	1	325	tags	128
838	2	325	tags	117
839	3	325	tags	115
840	4	325	tags	129
1661	1	228	tags	126
1662	2	228	tags	127
1793	1	227	tags	126
851	1	329	tags	122
852	2	329	tags	120
1794	2	227	tags	115
1695	1	212	tags	126
1696	2	212	tags	115
1763	1	182	tags	117
1764	2	182	tags	115
1765	3	182	tags	131
1766	1	181	tags	117
1767	2	181	tags	116
1768	3	181	tags	115
1795	1	226	tags	126
1796	2	226	tags	115
866	1	336	tags	126
867	2	336	tags	127
1797	1	225	tags	126
1798	2	225	tags	115
1803	1	221	tags	126
1804	2	221	tags	127
1805	1	219	tags	126
1806	2	219	tags	115
882	1	346	tags	117
883	2	346	tags	119
884	3	346	tags	115
1198	1	47	tags	108
1199	2	47	tags	124
1200	1	49	tags	122
1201	2	49	tags	123
1202	3	49	tags	125
1203	1	50	tags	122
1204	2	50	tags	123
1205	3	50	tags	115
1213	1	54	tags	122
1214	2	54	tags	120
1249	1	31	tags	117
1250	2	31	tags	115
1251	3	31	tags	128
1252	4	31	tags	132
1253	1	65	tags	122
1254	2	65	tags	120
1259	1	70	tags	117
1260	2	70	tags	115
1261	3	70	tags	134
1306	1	86	tags	128
1307	2	86	tags	117
1308	3	86	tags	115
1309	4	86	tags	129
1310	1	88	tags	128
1311	2	88	tags	117
1312	3	88	tags	115
1313	4	88	tags	129
1314	1	89	tags	128
1315	2	89	tags	117
1316	3	89	tags	115
1317	4	89	tags	129
1318	1	90	tags	128
1319	2	90	tags	117
1320	3	90	tags	115
1321	4	90	tags	129
1342	1	103	tags	122
1343	2	103	tags	113
1344	1	104	tags	122
1345	2	104	tags	107
1348	1	108	tags	122
1349	2	108	tags	113
1353	1	112	tags	122
1354	1	113	tags	122
1357	1	116	tags	107
1358	2	116	tags	124
1359	1	117	tags	106
1360	2	117	tags	126
1361	3	117	tags	124
1390	1	342	tags	124
1391	1	341	tags	124
1392	1	340	tags	124
1395	1	338	tags	122
1396	2	338	tags	113
1400	1	335	tags	113
1401	2	335	tags	117
1402	3	335	tags	115
1471	1	311	tags	122
1472	2	311	tags	120
1473	3	311	tags	117
1215	1	56	tags	122
1216	2	56	tags	120
1217	3	56	tags	108
1322	1	92	tags	108
1323	2	92	tags	124
1324	1	93	tags	108
1325	2	93	tags	124
1904	1	377	tags	121
1908	1	375	tags	117
1909	2	375	tags	115
1910	3	375	tags	119
1911	4	375	tags	134
1920	1	376	tags	126
1921	2	376	tags	115
1922	3	376	tags	124
979	1	371	tags	115
980	2	371	tags	117
981	3	371	tags	132
990	1	369	tags	126
991	2	369	tags	115
993	1	2	tags	108
994	2	2	tags	124
995	1	3	tags	117
996	2	3	tags	115
997	3	3	tags	128
998	4	3	tags	132
999	1	5	tags	128
1000	2	5	tags	117
1001	3	5	tags	115
1002	4	5	tags	129
1003	1	6	tags	128
1004	2	6	tags	117
1005	3	6	tags	115
1006	4	6	tags	129
1007	1	7	tags	122
1008	2	7	tags	120
1009	3	7	tags	113
1010	1	8	tags	115
1011	2	8	tags	117
1012	1	9	tags	122
1013	2	9	tags	116
1014	1	10	tags	124
1015	2	10	tags	125
1016	3	10	tags	106
1019	1	12	tags	117
1020	2	12	tags	119
1021	3	12	tags	115
1025	1	13	tags	117
1026	2	13	tags	119
1027	3	13	tags	115
1028	1	14	tags	126
1029	2	14	tags	115
1033	1	357	tags	117
1034	2	357	tags	115
1035	3	357	tags	132
1039	1	356	tags	120
1040	2	356	tags	122
1041	3	356	tags	132
1042	1	15	tags	126
1043	2	15	tags	115
1044	1	16	tags	121
1045	2	16	tags	123
1046	1	17	tags	120
1047	2	17	tags	122
1048	1	355	tags	115
1049	2	355	tags	117
1050	3	355	tags	124
1051	4	355	tags	132
1052	1	354	tags	115
1053	2	354	tags	108
1054	3	354	tags	132
1056	1	353	tags	126
1057	2	353	tags	115
1058	3	353	tags	128
1059	1	20	tags	117
1060	2	20	tags	115
1061	3	20	tags	128
1062	4	20	tags	139
1063	1	352	tags	126
1064	2	352	tags	127
1065	1	351	tags	126
1066	2	351	tags	115
1067	1	350	tags	122
1068	1	21	tags	117
1069	2	21	tags	115
1070	3	21	tags	128
1071	4	21	tags	139
1072	1	349	tags	122
1073	1	22	tags	117
1074	2	22	tags	115
1075	3	22	tags	128
1076	4	22	tags	139
1077	1	348	tags	122
1078	2	348	tags	120
1079	1	367	tags	117
1080	2	367	tags	122
1081	3	367	tags	116
1082	1	23	tags	117
1083	2	23	tags	115
1084	3	23	tags	128
1085	4	23	tags	139
1086	1	366	tags	122
1087	2	366	tags	113
1088	1	24	tags	117
1089	2	24	tags	115
1090	3	24	tags	128
1091	4	24	tags	139
1092	1	365	tags	122
1093	2	365	tags	123
1094	3	365	tags	120
1095	1	26	tags	117
1096	2	26	tags	115
1097	3	26	tags	128
1098	4	26	tags	139
1100	1	27	tags	117
1101	2	27	tags	115
1102	3	27	tags	128
1103	4	27	tags	139
1104	1	363	tags	117
1105	2	363	tags	115
1106	3	363	tags	124
1107	1	362	tags	117
1108	2	362	tags	115
1109	3	362	tags	132
1110	1	361	tags	119
1111	2	361	tags	115
1112	3	361	tags	124
1113	1	28	tags	117
1114	2	28	tags	115
1115	3	28	tags	128
1116	4	28	tags	139
1117	1	29	tags	117
1118	2	29	tags	115
1119	3	29	tags	128
1120	4	29	tags	131
1121	1	360	tags	123
1122	2	360	tags	122
1123	1	359	tags	117
1124	2	359	tags	115
1125	3	359	tags	132
1126	1	358	tags	126
1127	2	358	tags	115
1128	3	358	tags	132
1129	1	30	tags	117
1130	2	30	tags	115
1131	3	30	tags	128
1132	4	30	tags	139
1141	1	370	tags	115
1142	2	370	tags	117
1143	3	370	tags	132
1144	1	368	tags	122
1145	2	368	tags	120
1577	1	274	tags	112
1578	2	274	tags	115
1579	3	274	tags	132
1580	1	273	tags	117
1150	1	32	tags	117
1151	2	32	tags	115
1152	3	32	tags	128
1153	4	32	tags	132
1154	1	347	tags	117
1155	2	347	tags	115
1156	1	33	tags	117
1157	2	33	tags	115
1158	3	33	tags	128
1159	4	33	tags	132
1160	1	34	tags	117
1161	2	34	tags	115
1162	3	34	tags	128
1163	4	34	tags	132
1164	1	35	tags	117
1165	2	35	tags	115
1166	3	35	tags	128
1167	4	35	tags	132
1168	1	36	tags	117
1169	2	36	tags	115
1170	3	36	tags	128
1171	4	36	tags	130
1172	1	37	tags	117
1173	2	37	tags	115
1174	3	37	tags	128
1175	4	37	tags	133
1176	1	38	tags	117
1177	2	38	tags	115
1178	3	38	tags	128
1179	4	38	tags	137
1180	1	39	tags	117
1181	2	39	tags	115
1182	3	39	tags	128
1183	4	39	tags	140
1184	1	40	tags	117
1185	2	40	tags	115
1186	3	40	tags	128
1187	4	40	tags	135
1188	1	41	tags	108
1189	2	41	tags	124
1190	1	43	tags	108
1191	2	43	tags	124
1192	1	44	tags	108
1193	2	44	tags	124
1194	1	45	tags	108
1195	2	45	tags	124
1218	1	57	tags	122
1219	2	57	tags	120
1222	1	59	tags	122
1223	2	59	tags	120
1224	1	60	tags	122
1225	2	60	tags	120
1234	1	64	tags	122
1235	2	64	tags	120
1581	2	273	tags	115
1582	3	273	tags	132
1238	1	66	tags	117
1239	2	66	tags	115
1240	3	66	tags	119
1241	4	66	tags	134
1242	1	67	tags	117
1243	2	67	tags	115
1244	3	67	tags	108
1245	4	67	tags	134
1326	1	94	tags	108
1327	2	94	tags	124
1328	1	95	tags	122
1329	2	95	tags	120
1330	1	96	tags	122
1331	2	96	tags	120
1332	3	96	tags	123
1362	1	118	tags	107
1363	2	118	tags	124
1364	1	119	tags	124
1365	1	120	tags	109
1366	2	120	tags	124
1367	3	120	tags	107
1368	1	121	tags	124
1369	1	122	tags	107
1370	2	122	tags	124
1371	1	124	tags	109
1372	2	124	tags	124
1373	1	125	tags	109
1374	2	125	tags	124
1375	3	125	tags	107
1376	1	126	tags	106
1377	2	126	tags	124
1378	3	126	tags	107
1379	1	127	tags	107
1380	2	127	tags	124
1393	1	339	tags	124
1394	2	339	tags	125
1406	1	333	tags	107
1407	2	333	tags	124
1410	1	331	tags	122
1411	2	331	tags	113
1585	1	269	tags	117
1586	2	269	tags	115
1587	3	269	tags	123
1588	4	269	tags	132
1589	1	268	tags	115
1590	2	268	tags	132
1631	1	246	tags	121
1633	1	244	tags	121
1423	1	327	tags	128
1424	2	327	tags	117
1425	3	327	tags	115
1426	4	327	tags	129
1431	1	324	tags	128
1432	2	324	tags	117
1433	3	324	tags	115
1434	4	324	tags	129
1435	1	322	tags	128
1436	2	322	tags	117
1437	3	322	tags	115
1438	4	322	tags	129
1439	1	321	tags	128
1440	2	321	tags	117
1441	3	321	tags	115
1442	4	321	tags	129
1443	1	320	tags	128
1444	2	320	tags	117
1445	3	320	tags	115
1446	4	320	tags	129
1447	1	319	tags	128
1448	2	319	tags	117
1449	3	319	tags	115
1450	4	319	tags	129
1459	1	315	tags	117
1460	2	315	tags	115
1461	3	315	tags	114
1462	4	315	tags	134
1466	1	313	tags	117
1467	2	313	tags	115
1468	3	313	tags	134
1469	1	312	tags	122
1470	2	312	tags	120
1655	1	231	tags	126
1656	2	231	tags	127
1912	1	374	tags	122
1913	2	374	tags	120
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.events (id, slug, description, location, updated_at, created_at, location_link, incentive, is_chance, limited_availability, sign_up_link, instagram_post, graphic_id, title, title_fr, description_fr, incentive_fr, location_fr) FROM stdin;
11	meditation-workshop-morsl	Join us for a guided meditation session in collaboration with MORSL! A seated mediation on cushion or chair, no prior experience assumed or required. After initially engaging the body to enhance seated meditation posture with comfort, pranayama, a breath awareness practice, will be introduced. This practice cultivates a more interiorized state, preparing the mind for the formal meditation session. Shifts of the body may occur as participants settle in, and guidance is provided towards progressively longer periods of group silence and stillness. There is time at the end of the session for questions and feedback.\t	MORSL Meditation Room, 3610 McTavish, 3rd Floor room 36-3	2025-02-16 05:26:53.225+00	2025-01-27 22:17:50.177+00	https://maps.app.goo.gl/oAno25sHrqFytNSC6	\N	\N	\N	https://docs.google.com/forms/d/1VtXxWMLn_nyjFEt4EJMZx2V58K4TkQ3yGPXp9lJVbus/prefill	\N	4	Meditation Workshop with MORSL	\N	\N	\N	\N
9	activities-night-w2025	Stop by our table and learn more about MindVista, and sign up to our newsletter for a chance to win 5 free spin classes at Spin Énergie!	University Center	2025-02-16 05:27:13.59+00	2025-01-27 22:13:44.805+00	https://maps.app.goo.gl/wokmerL6vEyTNAjx6	Chance to win 5 class pass to Spin Énergie	t	\N		https://www.instagram.com/p/DFN6I0oO1Kp/?img_index=1	7	Activities Night (Winter 2025)	\N	\N	\N	\N
14	november-journaling-workshop	Join MindVista and SUS for a journaling workshop! No experience necessary! Learn about journaling, how to get started, and different ways to journal. Journals and snacks provided :)	680 Sherbrooke St. Room 1355	2025-02-22 16:56:50.27+00	2025-01-28 02:06:02.029+00	https://www.google.com/maps/place/680+Rue+Sherbrooke+O,+Montr%C3%A9al,+QC+H3A+0B8/data=!4m2!3m1!1s0x4cc91a465a4450e5:0x9fa1f856ee1ef07c?sa=X&ved=1t:242&ictx=111	Journals and snacks provided!	\N	\N	https://docs.google.com/forms/d/e/1FAIpQLSc90y_c_SDoSE4gV8qv5EzsziTQp3bKrbl34hQxLShA699ngA/closedform	https://www.instagram.com/p/DCfGcXTy8k9/	12	MindVista X SUS Journaling Workshop	\N	\N	\N	\N
13	winter-wellness-challenge	Prioritize your wellness for a chance to win a 10 class pass to Modo Yoga! Submit your entries below, each activity completed = one entry into the draw to win!	Can be completed anywhere!	2025-02-26 17:51:10.907+00	2025-01-28 01:53:42.295+00	\N	10 Class Pass to Modo Yoga valued at $200!	t	\N	https://docs.google.com/forms/d/1VtXxWMLn_nyjFEt4EJMZx2V58K4TkQ3yGPXp9lJVbus/prefill	\N	5	Winter Wellness Challenge (2025)	Défi de bien-être hivernal (2025)	Mettez en priorité votre bien-être pour une chance de gagner 10 cours gratuits chex Modo Yoga! Soumettez vos contributions ci-dessous, chaque activité complétée vous obtiens une chance de gagner le tirage!	10 cours chez Modo Yoga d'une valeur totale de 200$	Peut être complété n'importe où!
10	winter-wellness-walk-2025	Explore the Plateau and Jeanne Mance area, and get a free hot drink on us!	Meet in front of the Arts building at 1pm!	2025-03-02 02:25:33.146+00	2025-01-27 22:15:03.961+00	\N	A free hot beverage!	\N	t	\N	\N	\N	Winter Wellness Walk (2025)	\N	\N	\N	\N
15	ice-skating-feb-2025	Come join us on Sunday, February 23rd, for a fun skating activity! We'll meet at Roddick Gates at 3:00 PM and walk to Esplanade Tranquille Ice Rink together.\n If you have your own skates, please bring them! Otherwise, rentals will be available on-site.\n\nTo note about rentals:\nSkate rentals usually are $15, but we will pay for half!\nPlease bring your ID, as it will be used as a deposit for the loan\nSkate rentals are only for 2 hours\nFree lockers are available on-site; you can bring your own padlock or rent one for an additional price. Make sure to dress appropriately for the weather!	Roddick Gates to the Esplanade Tranquille Ice Rink 	2025-02-26 17:41:40.085+00	2025-02-19 18:37:02.009+00	https://maps.app.goo.gl/W1Bex67VSspRgsT68	Subsidized skate rentals 	\N	\N	https://docs.google.com/forms/d/e/1FAIpQLSd06NHVWtJFhUs-BKdBVStuJ7s73pkSmdI2g6DxgJyun3F9hQ/viewform	https://www.instagram.com/p/DGOFShlO_YE/?igsh=MXIwa2toZXRjNnc5cA==	9	Ice Skating	Patinage	Rejoignez-nous ce dimanche 23 février pour une activité de patinage! Notre point de rencontre sera aux portes Roddick à 15h00 et nous marcherons ensemble jusqu'à la patinoire Esplanade  Tranquille.\nSi vous avez vos propres patins, n'hésitez pas à les apporter ! Sinon, il sera possible d'en louer sur place.\n\nÀ noter au sujet de la location :\nLa location de patins coûte habituellement 15 $, mais nous offrons de payer la moitié!\nN'oubliez pas d'apporter une carte d'identité, elle servira de caution pour le prêt.\nLa location de patins est valide pendant 2 heures.\nDes casiers gratuits seront disponibles sur place; il est possible d'apporter votre propre cadenas ou d'en louer un pour (à vos frais). \n\nN'oubliez pas de vous habiller en fonction de la météo!	Location de patins subventionnée	Aux portes Roddick jusqu'à l'Esplanade Tranquille
16	wellness-challenge-spring-2025	This is your chance to win a cozy gift basket valued at over $100 by improving your mental wellness! Each completed challenge = 1 entry into the raffle. The more you complete, the higher your chances of winning!	Can be completed anywhere!	2025-03-13 21:39:15.844+00	2025-03-13 21:39:15.834+00	\N	The basket includes a mug, a $40 Subway gift card, an Owala travel mug, and the best-selling book *Atomic Habits*!	t	f	https://docs.google.com/forms/d/e/1FAIpQLSfo0PEe7qQlx5sxgHHzGgMBkFRCkC4eeVRMIalKN9SEpaYb7g/viewform	https://www.instagram.com/p/DG1FiRZO0nU/?img_index=1	16	Reading Week Wellness Challenge (2025)	\N	\N	\N	\N
17	financial-wellness-rbc	Join us on Monday, March 17th at 4:00 PM for an insightful session on credit, fraud, investments, and budgeting—key topics that impact your financial well-being! No prior knowledge is needed—everyone is welcome!	1 Place Ville Marie	2025-03-13 21:45:04.769+00	2025-03-13 21:45:04.765+00	\N	Free snacks & journals	\N	\N	\N	https://www.instagram.com/mindvista.mcgill/p/DHCLFcmO6WB/	17	Financial Wellness Event with RBC Bank	\N	\N	\N	\N
\.


--
-- Data for Name: events_date_ranges; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.events_date_ranges (_order, _parent_id, id, start_date, end_date) FROM stdin;
1	11	679805d01cca636280fe397b	2025-02-05 22:30:00+00	2025-02-05 23:30:00+00
1	9	679804cf1cca636280fe3975	2025-01-28 21:00:00+00	2025-01-29 01:00:00+00
2	9	679804eb1cca636280fe3977	2025-01-29 21:00:00+00	2025-01-30 01:00:00+00
1	14	67983b4ebc3e365968a7995b	2024-11-21 21:00:00+00	2024-11-21 22:00:00+00
1	15	67b623561dbb4f1da8046b52	2025-02-23 20:00:00+00	2025-02-23 22:30:00+00
1	13	679835f8745ca6c1fb83f877	2025-01-27 23:30:00+00	2025-02-10 04:30:00+00
1	10	6798053e1cca636280fe3979	2025-01-19 18:00:00+00	2025-01-19 20:00:00+00
1	16	67d34d902bba1475263e0ba5	2025-03-05 05:00:00+00	2025-03-20 03:30:00+00
1	17	67d351672bba1475263e0ba6	2025-03-17 20:00:00+00	2025-03-17 21:00:00+00
\.


--
-- Data for Name: holistic_wellness; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.holistic_wellness (id, page_id, hero_content, hero_content_fr, wellness_wheel_top_content, wellness_wheel_top_content_fr, wellness_wheel_bottom_content, wellness_wheel_bottom_content_fr, updated_at, created_at) FROM stdin;
1	10	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "What is ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Holistic Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": "?", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Discover the interconnected dimensions of wellness and how they contribute to your overall well-being and mental health.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Wheel", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The Wellness Wheel is a visual tool that highlights the interconnected aspects of wellness, demonstrating the balance needed for overall well-being. Each portion of the wheel represents an important dimension of wellness: Physical, Social, Intellectual, Emotional, Occupational, Environmental, Financial, and Spiritual.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Together, these areas form a cumulative approach to wellness, and demonstrate how different aspects of life can influence and support each other.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By focusing on each dimension, individuals can create a more balanced, fulfilling, and resilient life. The Wellness Wheel promotes self-reflection and action, encouraging continuous growth and balance in order to foster mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N	2025-02-22 19:53:18.76+00	2025-02-21 20:12:07.332+00
\.


--
-- Data for Name: holistic_wellness_sections; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.holistic_wellness_sections (_order, _parent_id, id, content, content_fr) FROM stdin;
1	1	67b8d36375f2c0657b93e0a7	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Wellness", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " Is More Than Mental Health", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Mental wellness encompasses a range of factors that contribute to overall well-being, including emotional regulation, resilience, healthy coping mechanisms, positive self-esteem, and a sense of purpose or meaning in life. It involves the ability to manage stress, anxiety, and other challenges that arise in daily life, as well as the capacity to form and maintain healthy relationships with others.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Achieving and maintaining mental wellness requires ongoing effort and attention, which can be a difficult hurdle for many.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The willingness to seek support and treatment when necessary is crucial, and something we should all feel comfortable and supported reaching towards. Achieving mental wellness encompasses many factors, and could involve engaging in practices like mindfulness meditation, regular exercise, and self-care, as well as seeking therapy or other forms of professional support when facing mental health challenges.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ultimately, mental wellness is about cultivating a sense of balance, resilience, and fulfillment in all aspects of life.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Evidence shows that improving our mental wellness can reduce our risk of developing mental illness, which is an underlying issue for not only university students, but our entire community as a whole.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N
2	1	67b8d3e075f2c0657b93e0a9	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "This is where ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "MindVista", "type": "text", "style": "", "detail": 0, "format": 2, "version": 1}, {"mode": "normal", "text": " comes in.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista is a student-led initiative at McGill to improve overall student wellbeing and engagement on-campus. We've gathered a comprehensive list of information about all the resources available at McGill and around Montreal, in order to help you foster positive mental wellness practices with ease.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Given these benefits, MindVista strives to promote more attention towards mental illness prevention, and the awareness and improvement of overall mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	\N
\.


--
-- Data for Name: holistic_wellness_wellness_wheel_dimensions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.holistic_wellness_wellness_wheel_dimensions (_order, _parent_id, id, name, name_fr, description, description_fr, color) FROM stdin;
1	1	67b8d33475f2c0657b93e0a3	Intellectual		Broadening your learning, expressing your creativity, and activities that encourage critical thinking which leads to personal growth.		violet-500
2	1	67b8d35b75f2c0657b93e0a5	Emotional		Understanding, controlling, and expressing emotions in healthy ways while developing your self-awareness.	\N	pink-500
3	1	67b8d56467ccd8052fc497ee	Occupational		Satisfaction & sense of purpose with work, school, and other daily activities. It can strengthen by aligning personal values with professional goals.	\N	amber-500
4	1	67b8d57767ccd8052fc497f0	Environmental	\N	Living in harmony with your surroundings, ensuring sustainability & safety in surrounding areas, and an overall positive relationship with the environment.	\N	emerald-500
5	1	67b8d58d67ccd8052fc497f2	Financial	\N	Managing finances wisely, achieving stability, and reducing stress through planning & responsibility, resulting in less financial burden.	\N	red-500
6	1	67b8d59d67ccd8052fc497f4	Spiritual	\N	Exploring personal values, beliefs, and purpose in order to better understand connections beyond oneself.	\N	indigo-500
7	1	67b8d5b233636dbefec7998a	Physical	\N	Maintaining health through exercise, nutrition, sleep, and health habits supports both mental & physical health.	\N	indigo-600
8	1	67b8d5ae67ccd8052fc497f8	Social	\N	Focuses on building meaningful relationships with loved ones, fostering a sense of belonging, and maintaining a supportive social network.	\N	cyan-500
\.


--
-- Data for Name: legal; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.legal (id, page_id, content, updated_at, created_at, content_fr, _status) FROM stdin;
5	2	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Privacy Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-02-06", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista (\\"we,\\" \\"our,\\" or \\"us\\") values your privacy. This Privacy Policy outlines how we collect, use, and protect your information when you use our website (mindvista.ca). This Privacy Policy is intended to be easy to understand, and we avoid legal jargon whenever possible. However, to ensure transparency and protection, we provide links detailing how third-party services handle your information. Below, you'll find a complete list of the data we collect and how we use it.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Cookies and Local Storage", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not use cookies on our website. We use local storage to remember your preferences, such as your choice of dark or light theme. This data is stored on your device only and is not transmitted to our servers. You can manage or clear this data at any time through your browser settings.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information We Collect", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We collect only the following information:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "1. Contact Form Submissions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "When you fill out a contact form on our website, we use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Web3Forms", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to process your submission. The information you provide, such as your name, email address, and message, is used solely for responding to your inquiry. Contact form submissions may be retained indefinitely unless a deletion request is made. Web3Forms' privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://web3forms.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://web3forms.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use hCaptcha to prevent spam and ensure user actions on our online service (such as submitting a contact form) meet our security requirements. To do this, hCaptcha analyzes the behavior of the website or mobile app visitor based on various characteristics. This analysis starts automatically as soon as the website or mobile app visitor enters a part of the website or app with hCaptcha enabled. For the analysis, hCaptcha evaluates various information (e.g. IP address, how long the visitor has been on the website or app, or mouse movements made by the user). The data collected during the analysis will be forwarded to IMI. hCaptcha analysis in the \\"invisible mode\\" may take place completely in the background. Website or app visitors are not advised that such an analysis is taking place if the user is not shown a challenge. For more information on this process, hCaptcha's privacy policy may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://www.hcaptcha.com/privacy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://www.hcaptcha.com/privacy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "2. Newsletter Subscriptions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you subscribe to our newsletter, we collect your email address via ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Mailchimp", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to send you updates and news. While you can unsubscribe at any time by clicking the unsubscribe link in any email, we may retain your email address and subscription data in an archive for record-keeping purposes. Mailchimp's policies may be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://mailchimp.com/legal/", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://mailchimp.com/legal/", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "3. Website Analytics", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Web Analytics", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"mode": "normal", "text": "Vercel Speed Insights", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " to collect anonymous website usage data. This data helps us understand website performance and improve user experience. No personally identifiable information (PII) is collected through analytics, and we retain this data in accordance with Vercel’s retention policies. Vercel's privacy policy for Web Analytics and Speed Insights may be found at: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/analytics/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/analytics/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " and ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://vercel.com/docs/speed-insights/privacy-policy", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://vercel.com/docs/speed-insights/privacy-policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": " respectively.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "How We Use Your Information", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We use the information we collect for the following purposes:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To respond to your inquiries submitted through the contact form.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To send newsletters to subscribers.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To analyze website performance and improve functionality.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Information Sharing", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We do not sell, trade, or share your information with third parties, except as necessary to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Provide the services mentioned above (e.g., Web3Forms, Mailchimp, Vercel Web Analytics).", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Comply with legal obligations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Data Retention", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We retain your information only as long as necessary to fulfill the purposes outlined in this policy:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact form submissions are retained indefinitely unless you specifically request deletion.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Newsletter subscription data is retained indefinitely for record-keeping purposes, even after you unsubscribe.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Anonymous analytics data is retained according to Vercel’s retention policies.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Your Rights", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You have the following rights regarding your data:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Access: ", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": "Request access to the data we have about you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Correction:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request correction of any inaccurate information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 3, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Deletion:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Request deletion of your data, subject to legal and contractual limitations.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 4, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Unsubscribe:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " Opt-out of our newsletter at any time. Your data is not deleted when you unsubscribe, and you must submit a request of deletion to have your information removed.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "bullet", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "You do not have the right to access, modify, or request the removal of non-personally identifiable information, as it is fully anonymized. Since we have no way to track this data, we cannot delete it, nor can we request its removal from any third parties.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To exercise these rights, please contact us at ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Security", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We take reasonable measures to protect your data from unauthorized access, alteration, or disclosure. However, no system is completely secure, and we cannot guarantee absolute security.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Changes to This Policy", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update this Privacy Policy from time to time. Changes will be posted on this page with an updated effective date. It is your responsibility to remain updated with said changes.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have questions or concerns about this Privacy Policy, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ".", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for trusting MindVista with your information.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	2025-02-21 23:57:12.748+00	2025-01-18 04:00:44.589+00	\N	published
6	3	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h1", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Effective Date:", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}, {"mode": "normal", "text": " 2025-01-17", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Welcome to MindVista (\\"we,\\" \\"our,\\" or \\"us\\"). By using our website (mindvista.ca), you agree to comply with and be bound by the following Terms and Conditions. If you do not agree, please do not use our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Purpose of the Site", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "The purpose of our website is to provide information and resources regarding mental wellness for McGill University students. We also host wellness events to support student well-being.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Acceptable Use", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "By using our website, you agree to:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "ol", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Only submit accurate and truthful information in our contact and newsletter subscription forms.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "listitem", "value": 2, "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Refrain from submitting spam or using an email address that does not belong to you.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "listType": "number", "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Any violation of these rules may result in restricted access to our website and further legal action, as necessary.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Ownership of Content", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "All content on this website, including but not limited to text, images, and resources, is the property of MindVista unless otherwise credited. Credits for specific content can be found here: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "https://github.com/atlasgong/mindvista?tab=readme-ov-file#credits", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"mode": "normal", "text": ". Unauthorized use, reproduction, or distribution of this content is prohibited without explicit written permission.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Third-Party Links", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Our website may contain links to third-party websites. We provide these links for convenience and informational purposes only. We are not responsible for the content, policies, or practices of third-party websites. Visiting these websites is at your own risk.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Disclaimer of Liability", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "MindVista provides its website and content on an \\"as is\\" and \\"as available\\" basis. We make no representations or warranties of any kind, express or implied, regarding the accuracy, reliability, or availability of the website or its content.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "To the fullest extent permitted by law, we disclaim all liability for any loss or damage, including but not limited to direct, indirect, incidental, consequential, or punitive damages, arising from your use of our website.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Updates to Terms and Conditions", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "We may update these Terms and Conditions from time to time. Updates will be posted on this page with an updated effective date. It is your responsibility to remain informed about any changes by reviewing this page regularly.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Governing Law", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "These Terms and Conditions are governed by the laws of Canada and the province of Quebec. Any disputes arising from the use of our website shall be resolved under these laws.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"tag": "h2", "type": "heading", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Contact Us", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "If you have any questions about these Terms and Conditions, please contact us:", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Email: ", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}, {"type": "autolink", "fields": {"url": "mailto:mindvista.mcgill@gmail.com", "linkType": "custom"}, "format": "", "indent": 0, "version": 2, "children": [{"mode": "normal", "text": "mindvista.mcgill@gmail.com", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr"}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Website: mindvista.ca", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": "ltr", "textStyle": "", "textFormat": 0}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Thank you for visiting MindVista and supporting mental wellness.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": "ltr", "textStyle": "", "textFormat": 0}], "direction": "ltr"}}	2025-02-21 23:57:28.411+00	2025-01-18 04:24:58.484+00	\N	published
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.media (id, alt, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, prefix, purpose, alt_fr) FROM stdin;
12	Poster for the MindVista X SUS Journaling Workshop. Reads: Want to start journaling but don't know how? Join us to learn everything there is to know about it! when: Thursday November 21 4-5pm, Where: TBD. Free journals and snacks provided! QR code in the bottom left corner with accompanying text that says "Sign up here"!	2025-02-22 16:56:40.433+00	2025-02-22 16:56:40.242+00	\N	\N	f2024_journaling_workshop_sus.jpg	image/jpeg	120152	1545	2000	50	50	media	fall 2024 mindvista X sus journaling workshop poster for events page	\N
13	Caffettiera Logo	2025-02-22 17:31:31.054+00	2025-02-22 17:31:30.83+00	\N	\N	caffettiera.png	image/png	81870	2029	1291	50	50	media	sponsor logo on sponsor us page	Logo de Caffettiera
14	AYM Yoga Logo	2025-02-22 17:51:12.439+00	2025-02-22 17:50:55.657+00	/api/media/file/aym.webp	\N	aym.webp	image/webp	57578	1399	1578	50	50	media	sponsor logo on sponsor us page	Logo d'AYM Yoga
15	musical havdallah	2025-03-02 01:19:01.72+00	2025-03-02 01:19:01.47+00	\N	\N	musical_havdallah.webp	image/webp	21594	630	1120	50	50	media	graphic for clubs/the-mcgill-chavurah	\N
9	February ice skating with MindVista, read the event details in the description. 	2025-03-04 05:12:50.17+00	2025-02-20 05:36:11.593+00	/api/media/file/ice_skating_with_mindvista	\N	ice_skating_with_mindvista.jpg	image/jpeg	76388	828	818	50	50	media	Promotional graphic	\N
7	Map to find MindVista's table at activities night. We will be located at table 179 in the Health and Wellness Section on the 3rd floor of the University Center.	2025-03-04 05:12:50.381+00	2025-01-28 04:29:43.822+00	/api/media/file/w2025-activities-night-map	\N	w2025-activities-night-map.png	image/png	348722	1080	1080	50	50	media	activities night map for events section	\N
5	Graphic for the MindVista Winter Wellness Challenge. Blue background with pink and white text. Title reads: The Challenges... enter via the link in our bio! Don't forget to attach a picture as proof. Check list of the challenges to complete reads: 1. Attend our meditation workshop with MORSL on Feb 5 2. Visit our Activities Night table (Jan 28-29) 3. Spend time outside doing a winter activity (skating, skiing, walking...) 4. Declutter your closet 5. Start learning a new language! (ex. 5-day streak on Duolingo) 6. Create a music playlist 7. Create a vision board! (by hand or online) 8. Spend time on a creative project (ex. crocheting, DIYing, etc...)	2025-03-04 05:12:50.652+00	2025-01-28 01:53:38.431+00	/api/media/file/w2025-winter-wellness-challenge	\N	w2025-winter-wellness-challenge.png	image/png	117861	1080	1080	50	50	media	winter 2025 wellness challenge for Modo Yoga Pass	\N
4	Graphic for the MindVista X MORSL (McGill Office for Religious and Spiritual Life) meditation workshop. When: Wednesday Feb, 5th, 5:30-6:30pm. Join us for a relaxing meditation session in the MORSL meditation room!	2025-03-04 05:12:50.832+00	2025-01-28 01:40:34.825+00	/api/media/file/w2025-meditation-workshop-MORSL	\N	w2025-meditation-workshop-MORSL.png	image/png	362322	1080	1080	50	50	media	winter 2025 meditation workshop poster for events	\N
16	Graphic for the MindVista Reading Week Wellness Challenge. Blue background with navy blue text. Text outlines wellness tasks: 1 Come to our Financial Wellness with RBC event on March 17th 2 Do a digital detox of your photos, emails, files, etc. 3 Write down 3 things you are grateful for 3 days in a row 4 Take a picture of a beautiful nature landscape 5 Walk 10,000 steps in a day 6 Play board games with friends or family 7 No usage of social media for 24 hours 	2025-03-13 21:39:00.583+00	2025-03-13 21:39:00.325+00	\N	\N	reading_week_2025_wellness_challenge.jpg	image/jpeg	196046	1179	1162	50	50	media	reading week 2025 wellness challenge for gift basket	\N
17	Graphic for Financial Wellness Event with RBC Bank. Join us to learn more about financial wellness through four topics: credit, fraud, investments, and budgeting. Prizes and snacks will be included!	2025-03-13 21:42:12.03+00	2025-03-13 21:42:11.861+00	\N	\N	financial_wellness.jpg	image/jpeg	106714	1179	1158	50	50	media	winter 2025 financial wellness event poster	\N
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.pages (id, slug, title, seo_description, updated_at, created_at, title_fr, seo_description_fr) FROM stdin;
5	about	About Us	Established in 2023, MindVista emerged from the collaborative as part of the Integrated Management Student Fellowship (IMSF) at McGill University. Rooted in a commitment to enhancing mental wellness, our group functions as a student, volunteer-run initiative that envisions a holistic approach to fostering well-being for every McGill student.	2025-01-13 02:14:56.413+00	2025-01-13 02:14:56.413+00	\N	\N
10	holistic-wellness	What is Holistic Wellness?	We’re crafting a space dedicated to holistic wellness—your journey to a healthier, happier mind begins here. While we fine-tune the details, remember: your mental health matters every single day. Check back soon for tips, insights, and resources to support your well-being!	2025-01-24 15:13:25.616+00	2025-01-13 02:52:11.641+00	\N	\N
13	events	Events	Discover upcoming wellness events hosted by MindVista! Join us for fun and engaging activities designed to promote mental health and well-being at McGill University. Stay updated on all our exciting events and get involved in fostering a supportive student community.	2025-01-27 17:01:03.365+00	2025-01-24 23:50:58.275+00	\N	\N
4	contact	Contact Us	Have questions or feedback? We’re here to listen and help. Whether you need support, have inquiries about our initiatives, or want to share your thoughts, we’re ready to assist you. Your mental health journey matters to us, and we’re committed to providing the resources and guidance you need. Reach out to MindVista today and connect with our team.	2025-01-27 17:01:54.342+00	2025-01-13 02:03:55.573+00	\N	\N
8	directory	Directory	Further your mental wellness journey by browsing our comprehensive collection of student clubs and wellness resources at McGill University. Explore a variety of options to support your mental health and well-being, and connect with organizations dedicated to creating a positive impact in the McGill community.	2025-01-27 17:04:06.713+00	2025-01-13 02:34:55.443+00	\N	\N
6	directory/clubs	Club Directory	View our comprehensive directory of McGill student clubs and organizations. Whether you're looking to get involved, find peer support, or explore activities related to mental wellness, our directory offers diverse options for every need and interest. Discover opportunities to connect and contribute to a healthier campus community.	2025-01-27 17:04:18.471+00	2025-01-13 02:32:17.728+00	\N	\N
7	directory/resources	Resource Directory	Explore our extensive directory of wellness resources available to McGill students. From counseling services to mental health workshops and self-care tools, we’ve compiled a range of options to help you on your mental wellness journey. Take advantage of these valuable resources to support your well-being at McGill University.	2025-01-27 17:04:30.197+00	2025-01-13 02:34:41.348+00	\N	\N
9	crisis	Need help NOW?	Need help immediately? View emergency care resources and immediate support options for mental health crises at McGill University. Whether you're facing a personal emergency or need urgent assistance, our Crisis page provides access to vital contacts, professional support, and guidance to help you navigate through challenging times.	2025-01-27 17:05:15.935+00	2025-01-13 02:51:43.003+00	\N	\N
3	terms-and-conditions	Terms and Conditions	Review the Terms & Conditions for using MindVista's services and website. This page outlines important information regarding your rights, responsibilities, and the terms that govern your use of our platform. By using MindVista, you agree to comply with these terms.	2025-01-27 17:05:59.069+00	2025-01-02 03:52:35.46+00	\N	\N
2	privacy-policy	Privacy Policy	Learn how MindVista collects, uses, and protects your personal information through our Privacy Policy. This page provides transparency about our data practices and your privacy rights, ensuring you understand how we safeguard your information while using our services.	2025-01-27 17:06:04.783+00	2025-01-02 03:45:17.394+00	\N	\N
12	sponsor	Sponsor Us	Looking to support a meaningful cause? Sponsor MindVista and help us promote mental wellness at McGill University. Explore our sponsorship opportunities or see the list of our current sponsors making an impact in the community.	2025-02-22 17:52:43.692+00	2025-01-24 18:37:11.565+00	\N	\N
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
11	\N	2025-01-04 20:31:38.8+00	2025-01-04 20:31:38.8+00
266	\N	2025-01-27 22:05:16.529+00	2025-01-27 22:05:16.529+00
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, users_id, media_id, pages_id, legal_id, clubs_id, resources_id, club_tag_categories_id, resource_tag_categories_id, club_tags_id, resource_tags_id, events_id) FROM stdin;
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
2	fix_currently_active	1	2025-01-05 17:33:58.851+00	2025-01-05 17:33:58.851+00
3	fix_on_campus	2	2025-01-05 17:38:31.59+00	2025-01-05 17:38:31.59+00
4	20250206_053130_localize_events	3	2025-02-06 05:54:05.83+00	2025-02-06 05:54:05.83+00
1	dev	-1	2025-03-07 23:20:00.805+00	2025-01-01 20:42:35.663+00
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
73	users-list	{"limit": 10}	2025-01-27 21:28:42.31+00	2025-01-27 21:28:42.31+00
74	legal-list	{"limit": 10}	2025-01-27 22:07:04.519+00	2025-01-27 22:07:03.987+00
67	media-list	{"limit": 10}	2025-01-27 22:07:05.665+00	2025-01-27 21:11:48.115+00
75	pages-list	{}	2025-01-28 00:06:53.627+00	2025-01-28 00:06:53.627+00
76	clubs-list	{"limit": 10}	2025-01-28 00:08:09.653+00	2025-01-28 00:08:03.916+00
80	resource-tag-categories-list	{}	2025-01-28 00:32:07.513+00	2025-01-28 00:32:07.513+00
82	media-list	{}	2025-01-28 01:28:43.264+00	2025-01-28 01:28:43.264+00
83	clubs-list	{"limit": 10}	2025-01-28 03:46:15.223+00	2025-01-28 03:40:51.565+00
84	pages-list	{"limit": 10}	2025-01-28 18:50:22.192+00	2025-01-28 18:50:07.644+00
86	media-list	{}	2025-01-28 21:44:37.81+00	2025-01-28 21:44:37.81+00
90	pages-list	{}	2025-02-07 15:00:04.632+00	2025-02-07 15:00:04.632+00
91	events-list	{}	2025-02-07 15:02:10.747+00	2025-02-07 15:02:10.747+00
87	resources-list	{"limit": 100}	2025-02-07 15:04:45.967+00	2025-01-29 17:04:27.005+00
89	locale	"en"	2025-02-16 05:26:02.93+00	2025-02-01 18:42:12.823+00
93	legal-list	{}	2025-02-09 03:49:58.32+00	2025-02-09 03:49:58.32+00
94	pages-list	{"limit": 10}	2025-02-09 03:56:05.72+00	2025-02-09 03:54:41.29+00
85	users-list	{"limit": 10}	2025-02-09 04:11:02.07+00	2025-01-28 21:44:31.478+00
95	locale	"en"	2025-02-09 04:27:47.189+00	2025-02-09 04:27:42.631+00
97	events-list	{}	2025-02-14 15:57:01.739+00	2025-02-14 15:57:01.739+00
69	clubs-list	{"limit": 100}	2025-02-16 04:10:35.624+00	2025-01-27 21:11:52.524+00
77	club-tag-categories-list	{"limit": 100}	2025-02-16 04:10:47.137+00	2025-01-28 00:32:03.733+00
78	club-tags-list	{"limit": 100}	2025-02-16 04:10:52.739+00	2025-01-28 00:32:05.129+00
79	resources-list	{"limit": 100}	2025-02-16 04:10:58.536+00	2025-01-28 00:32:06.408+00
81	resource-tags-list	{"limit": 100}	2025-02-16 04:11:07.127+00	2025-01-28 00:32:08.997+00
92	nav	{"open": true}	2025-02-27 19:18:28.475+00	2025-02-09 03:19:01.91+00
96	events-list	{"limit": 10}	2025-03-13 21:22:39.227+00	2025-02-14 15:56:56.675+00
88	nav	{"open": false}	2025-03-14 15:53:59.035+00	2025-02-01 18:40:06.966+00
68	pages-list	{"limit": 10}	2025-01-27 21:11:51.694+00	2025-01-27 21:11:51.438+00
70	events-list	{"limit": 10}	2025-01-27 21:11:59.63+00	2025-01-27 21:11:59.123+00
71	events-list	{"limit": 10}	2025-01-27 21:12:12.952+00	2025-01-27 21:12:12.952+00
72	users-list	{"limit": 10}	2025-01-27 21:12:38.365+00	2025-01-27 21:12:38.127+00
98	collection-clubs-377	{"fields": {"otherSocials": {"collapsed": []}}}	2025-02-16 05:38:54.934+00	2025-02-16 05:38:54.404+00
99	collection-resources-136	{"fields": {"insuranceProviders": {"collapsed": ["67b17ab871521de1115c910c"]}}}	2025-02-16 05:42:34.305+00	2025-02-16 05:42:34.404+00
101	club-tag-categories-list	{}	2025-02-16 08:33:44.507+00	2025-02-16 08:33:44.493+00
102	club-tags-list	{}	2025-02-16 08:33:46.828+00	2025-02-16 08:33:46.816+00
103	resources-list	{}	2025-02-16 08:33:48.507+00	2025-02-16 08:33:48.498+00
104	resource-tag-categories-list	{}	2025-02-16 08:33:49.8+00	2025-02-16 08:33:49.799+00
105	users-list	{}	2025-02-19 14:41:13.268+00	2025-02-19 14:41:13.258+00
106	events-list	{}	2025-02-19 14:41:46.424+00	2025-02-19 14:41:46.422+00
107	legal-list	{}	2025-02-19 14:43:10.846+00	2025-02-19 14:43:10.845+00
108	media-list	{}	2025-02-19 14:43:18.067+00	2025-02-19 14:43:18.055+00
109	club-tag-categories-list	{}	2025-02-21 15:21:53.146+00	2025-02-21 15:21:53.13+00
110	club-tags-list	{"limit": 10}	2025-02-21 15:25:05.109+00	2025-02-21 15:24:55.92+00
111	global-holistic-wellness-page	{"fields": {"sections": {"collapsed": []}, "wellnessWheelDimensions": {"collapsed": ["67b8d33475f2c0657b93e0a3", "67b8d35b75f2c0657b93e0a5", "67b8d56467ccd8052fc497ee", "67b8d57767ccd8052fc497f0", "67b8d58d67ccd8052fc497f2"]}}}	2025-02-21 19:35:56.514+00	2025-02-21 19:26:22.165+00
112	global-holistic-wellness	{"fields": {"sections": {"collapsed": ["67b8e7c63f28bc1f05a6e949"]}, "wellnessWheelDimensions": {"collapsed": []}}}	2025-02-21 20:53:29.562+00	2025-02-21 20:52:53.705+00
113	global-sponsor	{"fields": {"sponsors": {"collapsed": ["67ba1ee13e535017b0cd88f1"]}, "sponsors.0.utilityClasses": {"collapsed": ["67ba1d873e535017b0cd88d9", "67ba1dc63e535017b0cd88dd"]}, "sponsors.1.utilityClasses": {"collapsed": ["67ba1dd23e535017b0cd88df", "67ba1dddc7303c1e1b95c5c0", "67ba1ddb3e535017b0cd88e3"]}}}	2025-02-22 19:02:28.725+00	2025-02-22 17:51:35.506+00
114	pages-list	{}	2025-02-26 17:35:28.601+00	2025-02-26 17:35:28.595+00
115	clubs-list	{}	2025-02-26 17:51:49.499+00	2025-02-26 17:51:49.495+00
116	resources-list	{}	2025-02-26 17:52:07.703+00	2025-02-26 17:52:07.689+00
117	media-list	{}	2025-03-13 21:34:00.52+00	2025-03-13 21:34:00.524+00
100	clubs-list	{"limit": 10}	2025-03-14 14:04:55.29+00	2025-02-16 08:33:43.295+00
118	resources-list	{"limit": 10}	2025-03-14 14:27:47.372+00	2025-03-14 14:16:36.962+00
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id) FROM stdin;
286	\N	73	user	4
288	\N	74	user	1
291	\N	67	user	1
292	\N	75	user	5
294	\N	76	user	5
298	\N	80	user	1
301	\N	82	user	4
303	\N	83	user	4
305	\N	84	user	4
307	\N	86	user	3
332	\N	90	user	7
335	\N	91	user	3
336	\N	87	user	7
343	\N	93	user	3
347	\N	94	user	3
348	\N	85	user	3
350	\N	95	user	3
358	\N	97	user	7
359	\N	69	user	1
360	\N	77	user	1
361	\N	78	user	1
364	\N	79	user	1
365	\N	81	user	1
369	\N	89	user	1
371	\N	98	user	1
372	\N	99	user	1
376	\N	101	user	3
377	\N	102	user	3
378	\N	103	user	3
379	\N	104	user	3
384	\N	105	user	8
385	\N	106	user	8
386	\N	107	user	8
387	\N	108	user	8
388	\N	109	user	5
390	\N	110	user	5
278	\N	68	user	1
282	\N	70	user	1
283	\N	71	user	4
285	\N	72	user	1
403	\N	111	user	1
406	\N	112	user	1
418	\N	113	user	1
419	\N	114	user	8
420	\N	115	user	8
421	\N	116	user	8
423	\N	92	user	3
425	\N	96	user	5
426	\N	117	user	5
427	\N	100	user	3
429	\N	118	user	5
430	\N	88	user	1
\.


--
-- Data for Name: resource_tag_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resource_tag_categories (id, name, updated_at, created_at) FROM stdin;
32	BIPOC Services	2025-01-04 22:13:07.56+00	2025-01-04 22:13:07.56+00
33	Directory	2025-01-04 22:13:08.083+00	2025-01-04 22:13:08.083+00
34	Help Lines	2025-01-04 22:13:08.503+00	2025-01-04 22:13:08.503+00
36	LGBTQ+ Services	2025-01-04 22:13:09.335+00	2025-01-04 22:13:09.335+00
37	Medical Services	2025-01-04 22:13:09.735+00	2025-01-04 22:13:09.735+00
38	Mental Health Services	2025-01-04 22:13:11.904+00	2025-01-04 22:13:11.904+00
39	Substance Use	2025-01-04 22:13:13.476+00	2025-01-04 22:13:13.476+00
40	Support and Community Services	2025-01-04 22:13:13.928+00	2025-01-04 22:13:13.928+00
41	Violence Services	2025-01-04 22:13:14.829+00	2025-01-04 22:13:14.829+00
\.


--
-- Data for Name: resource_tags; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resource_tags (id, name, category_id, updated_at, created_at) FROM stdin;
78	BIPOC Services	32	2025-01-04 22:13:07.819+00	2025-01-04 22:13:07.819+00
79	Directory	33	2025-01-04 22:13:08.276+00	2025-01-04 22:13:08.276+00
80	Help Lines	34	2025-01-04 22:13:08.692+00	2025-01-04 22:13:08.692+00
82	LGBTQ+ Services	36	2025-01-04 22:13:09.518+00	2025-01-04 22:13:09.518+00
83	Abortion Services	37	2025-01-04 22:13:09.939+00	2025-01-04 22:13:09.939+00
84	Contraception Services	37	2025-01-04 22:13:10.179+00	2025-01-04 22:13:10.179+00
85	Dental Clinic	37	2025-01-04 22:13:10.566+00	2025-01-04 22:13:10.566+00
86	Lab	37	2025-01-04 22:13:10.783+00	2025-01-04 22:13:10.783+00
87	Medical Clinic	37	2025-01-04 22:13:11.002+00	2025-01-04 22:13:11.002+00
88	Menstrual Health	37	2025-01-04 22:13:11.229+00	2025-01-04 22:13:11.229+00
89	Physiotherapy	37	2025-01-04 22:13:11.456+00	2025-01-04 22:13:11.456+00
90	STI Testing	37	2025-01-04 22:13:11.677+00	2025-01-04 22:13:11.677+00
91	Counselling	38	2025-01-04 22:13:12.088+00	2025-01-04 22:13:12.088+00
92	Crisis Support	38	2025-01-04 22:13:12.323+00	2025-01-04 22:13:12.323+00
93	Disordered Eating	38	2025-01-04 22:13:12.544+00	2025-01-04 22:13:12.544+00
94	Mental Wellness	38	2025-01-04 22:13:12.757+00	2025-01-04 22:13:12.757+00
95	Psychological	38	2025-01-04 22:13:12.982+00	2025-01-04 22:13:12.982+00
96	Support Group	38	2025-01-04 22:13:13.211+00	2025-01-04 22:13:13.211+00
97	Substance Use	39	2025-01-04 22:13:13.659+00	2025-01-04 22:13:13.659+00
98	Accessibility	40	2025-01-04 22:13:14.142+00	2025-01-04 22:13:14.142+00
99	Legal Service	40	2025-01-04 22:13:14.368+00	2025-01-04 22:13:14.368+00
100	Safety Service	40	2025-01-04 22:13:14.598+00	2025-01-04 22:13:14.598+00
101	Domestic Violence	41	2025-01-04 22:13:15.02+00	2025-01-04 22:13:15.02+00
102	Sexual Assault Services	41	2025-01-04 22:13:15.254+00	2025-01-04 22:13:15.254+00
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resources (id, slug, title, description, website, insurance_details, email, phone_number, location, updated_at, created_at, currently_active, on_campus, channel_online, channel_telephone, channel_in_person, newsletter, title_fr, description_fr, insurance_detail_fr, location_fr, graphic_id, graphic_title, graphic_title_fr) FROM stdin;
136	smart-recovery-quebec	SMART Recovery Quebec	SMART Recovery is the leading self-empowering addiction recovery support group. Participants learn tools for addiction recovery based on the latest scientific research and participate in a world-wide community which includes free, self-empowering, secular and science-based, mutual-help support groups. SMART Recovery helps with recovery from all types of addiction and addictive behaviours, including alcoholism, drug abuse, drug addiction, substance abuse, alcohol abuse, gambling addiction, cocaine addiction, and addiction to other substances and activities. Services are offered in English on Mondays and Wednesdays from 6-7:30pm both in-person and online.	https://smartrecoveryquebec.org	\N	\N	514-621-2257	OHMH – Habitation Saint Raymond on 5605 Upper Lachine Rd. H4A 3S1	2025-02-26 18:00:06.566+00	2025-01-05 18:42:31.616+00	t	f	t	f	t	\N	SMART Recovery Quebec	SMART Recovery est un groupe de soutien pour le rétablissement aux dépendances. Le programme accorde à ses participants des outils de rétablissement fondés sur les nouvelles recherches scientifiques et font partie d'une communauté mondiale qui comprend des groupes d'entraide gratuits et autonomes. SMART Recovery aide au rétablissment suivant plusieurs types de dépendance, y compris l'alcoolisme, l'abus de drogues, la toxicomanie, la dépendance au gambling et à d'autres. Les services sont offerts en anglais les lundis et mercredis de 18h à 19h30, en personne ou en ligne.	\N	\N	\N	\N	\N
2	biron-labs	Biron Labs	Biron Labs is a medical imaging directory of medical clinics, a doctor's prescription is required for all services.	https://www.biron.com/en/	Not covered  by RAMQ or out-of-province healthcare. Private insurance may cover costs fully or partially, only if applicable.	info@biron.com	\N	\N	2025-01-05 18:31:56.047+00	2025-01-05 18:31:56.047+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
7	psychology-today	Psychology Today	The Psychology Today directory features therapy and health professionals, online therapy, treatment centres and support groups.	https://www.psychologytoday.com/ca	Contact insurance company for coverage information	\N	\N	\N	2025-01-05 18:31:58.185+00	2025-01-05 18:31:58.185+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
13	baca-eating-disorder-clinic	BACA Eating Disorder Clinic	BACA Eating Disorder Clinic is a private clinic that offers services including disordered eating evaluation, supervised housing, intensive treatment for adults, and group therapy for a fee.	https://cliniquebaca.com/en/	Contact organization regarding pricing and insurance coverage.	info@cliniquequebaca.com	(514) 544-2323	2121 rue Crescent, bureau 200,Montréal QC  H3G 2C1	2025-02-14 13:14:53.643+00	2025-01-05 18:32:00.804+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
12	amiquebec	AMI-Quebec	AMI-Quebec is a non-profit organization that helps families manage effects of mental illness through support, education, guidance, and advocacy. Services offered include workshops, support groups, counselling, education and outreach, online learning, and more. AMI-Quebec's programs are free.	https://amiquebec.org/	\N	\N	(514) 486-1448	5800 boul. Decarie, Montreal QC H3X 2J5	2025-02-14 13:15:08.211+00	2025-01-05 18:32:00.374+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
11	douglas-mental-health-universi	Douglas Mental Health University Institute: Eating Disorder Program	The Eating Disorder Program specializes in anorexia and bulimia for adults aged 18 and older. Their services include external follow-ups, day program, residential program, and research program. Medical referral required.	http://www.douglas.qc.ca/page/eating-disorders-program	\N	\N	514-761-6131	6603-6605 LaSalle Boulevard, Montreal QC, H4H 1R3	2025-02-14 13:15:32.474+00	2025-01-05 18:31:59.93+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
10	aneb-anorexia-and-bulimia-queb	ANEB (Anorexia and Bulimia Quebec)	ANEB (Anorexia and Bulimia Quebec) provides open and closed support groups for ages 17+, online forums, online chat, helpline and referral line. Many services are free while more intensive treatments have a fee.	https://anebquebec.com/en	Contact ANEB for coverage information regarding paid services.	\N	(514) 630-0907	5500, Transcanadienne Pointe-Claire QC H9R 1B6	2025-02-14 13:16:27.914+00	2025-01-05 18:31:59.478+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
9	change-cognitive-behavioral-ps	Change Cognitive Behavioral Psychology Clinic	Change Cognitive Behavioral Psychology Clinic specializes in cognitive behavioural therapy (CBT). Services they offer include individual and couples therapy, child, teen and family therapy, nutrition, sexology, art therapy, animal assisted therapy, online therapy, as well as conferences and training.	https://changepsy.ca/en/	RAMQ is not accepted. You must pay for the entirety of the sessions and you will subsequently be reimbursed by your insurance.	info@changeenfamille.ca	(514) 508-5779	3275 Saint Jacques\nMontreal, Quebec\nH4C 1G8	2025-02-14 13:17:03.66+00	2025-01-05 18:31:59.044+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
8	ordre-de-psychologues-du-quebe	Ordre de Psychologues du Quebec	Ordre de Psychologues du Quebec is a service that helps people to find licensed psychologists or psychotherapist in their area. Their services are paid for and generally covered by group insurance.	https://www.ordrepsy.qc.ca/fr/accueil	Contact insurance company for coverage information.	info@ordrepsy.qc.ca	514-738-1223	Ordre des psychologues du Québec\n1100, avenue Beaumont, bureau 510\nMont-Royal (Québec) H3P 3H5	2025-02-14 13:17:43.541+00	2025-01-05 18:31:58.62+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
5	medipsy	Medipsy	Medipsy provides individual psychotherapy, sex therapy, ADHD clinic, assessments and diagnosis, neuropsychological assessments, couple and family therapy, phobic clinic, and vocational counselling.	https://www.medipsy.ca/	Your paid receipt is required by your insurance company for reimbursement.	info@medipsy.ca	514-419-3005	4610 Ste. Catherine Ouest, Westmount, H3Z 1S3	2025-02-14 13:20:17.443+00	2025-01-05 18:31:57.307+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
4	psymontreal	PsyMontreal	PsyMontreal offers individual psychotherapy, coaching, child and parenting services, and online therapy.	http://psymontreal.com/	The fees of psychotherapy services in private practice are not covered by Medicare, but many insurance companies reimburse a certain amount, depending on your coverage. Official receipts are provided for each appointment.\ninsurance information	\N	514-337-2473	Multiple office locations throughout Montreal Telephone: (514)-337-2473, extension 0	2025-02-14 13:20:56.937+00	2025-01-05 18:31:56.878+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
3	montreal-therapy-centre	Montreal Therapy Centre	Montreal Therapy Centre provides individual therapy, couple’s and family therapy, child and adolescent therapy, online therapy, therapy groups, and workshops. Services are provided in fourteen different languages.	http://www.montrealtherapy.com/	Medicare does not provide coverage for private therapy fees. Insurance receipts are available to those covered by extended health care plans.	\N	514-244-1290	Queen Elizabeth Health Complex, Suite 532, Montreal, Qc H4A 3L5	2025-02-14 13:21:55.14+00	2025-01-05 18:31:56.446+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
1	clic-sante	Clic Sante	Clic Santé offers services including blood tests, STI screening, vaccinations, and many other medical services at a hospital, a private clinic, or a pharmacy. Their website portal refers patients to various health clinics near them where their desired service is available.	https://portal3.clicsante.ca/	Pricing and coverage varies depending on service and location chosen.	\N	877-644-4545	Multiple clinics,\nLocations vary \nby postal code	2025-02-14 13:22:17.975+00	2025-01-05 18:31:55.596+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
14	national-eating-disorder-infor	National Eating Disorder Information Center	National Eating Disorder Information Center provides services including a help line, support and information on disordered eating, and referrals to health professionals.	https://nedic.ca/	\N	\N	866-633-4220	ES 7-421, 200 Elizabeth Street,Toronto ON M5G 2C4	2025-03-14 14:27:58.525+00	2025-01-05 18:32:01.283+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
28	cura-sant	Cura Santé	Cura Santé offers private medical services such as home blood tests, cardiology, nursing services, and more.	https://curasante.com/appointment-booking/	Cura Santé services are not reimbursable from the RAMQ. However, most insurance companies cover the cost between 80%-100%.	info@curasante.com	514-824-2872	5515 Rue St. Jacques, Suite 106	2025-01-05 18:32:08.115+00	2025-01-05 18:32:08.115+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
30	promed-medical-and-dental-cent	Promed Medical and Dental Center	Promed Medical and Dental Center offers a variety of services such as dental, medical, physiotherapy, diet and nutrition, and more.	https://bonjour-sante.ca/uno/clinic/cmpromed	Contact for information regarding insurance and costs.	\N	514-845-1800	1250 rue Mansfield, 3rd floor, corner of St-Catherine	2025-02-14 12:58:28.436+00	2025-01-05 18:32:09.029+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
29	medical-westmount	Medical Westmount	The Westmount Medical Building is a group of physicians in general and specialized practices that offer a multitude of services including family medicine, massage therapy, gastroentorology, pediatrics, and more.	https://westmountmedicalbuilding.ca/	Contact for information regarding insurance and costs.	wmbadmin@videotron.ca	514-488-9888	1, Westmount Square, Tower 1, Suite C-180	2025-02-14 12:58:46.805+00	2025-01-05 18:32:08.563+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
26	queen-elizabeth-health-complex	Queen Elizabeth Health Complex	The Queen Elizabeth Health Complex offers services including imaging radiology, medical care, mental health, alternative therapy, and a variety of other services. There may be additional fees for materials (e.g. cast or stitches). 	https://www.qehc.org/contact-us	Most medical services covered by RAMQ. Psychiatric services covered by the RAMQ. The QEHC offers a range of services from individual health providers. Each health provider and individual insurance plans must be consulted for each service offered.	\N	514-485-5013	2100, Marlowe Avenue Montréal, Québec H4A 3L5	2025-02-14 13:02:22.474+00	2025-01-05 18:32:07.195+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
25	clinique-union-md	Clinique Union MD	UnionMD is a group of private clinics located in downtown Montreal, the Town of Mount Royal, West Island, Laval, Gatineau and Ottawa. They offer a range of medical, surgical, and cosmetic services.  Telehealth services are also available. Fees are listed on the website.	https://unionmd.ca/en/	Fees vary depending on service. Private insurance may cover the cost of some services.	info@unionmd.ca	514-400-3291	Several Locations	2025-02-14 13:02:51.492+00	2025-01-05 18:32:06.724+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
24	cloud-med	Cloud Med	Cloud Med is a private clinic that offers services for family medicine, colorectal surgery, dermatology, gynecology, fertility, and menopause. Fees apply to access these services.	https://www.cloudmed.ca/	Provincial health insurance not accepted. Private insurance may cover some services. Individuals will have to contact their insurance providers to verify if they will accept receipts from CloudMed. Appointments range from $219 - $349, depending on the service accessed.	\N	438-943-0909	Griffintown:\n210 Rue Seigneurs\nMontreal, Quebec\nH3J 1R5\nWestmount:\n4060 Sainte-Catherine St. West, Suite 405\nWestmount, Quebec\nH3Z 2Z3	2025-02-14 13:06:48.039+00	2025-01-05 18:32:06.095+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
23	rockland-md	Rockland MD	Rockland MD is a private medical and surgical center that offers general and preventative medicine, specialized care, and complementary services such as nutrition. There are fees to open a file, and have a consultation and testing.	https://www.rocklandmd.com/	Contact organization regarding pricing and insurance coverage.	\N	514-667-3383	100 Chemin Rockland, Suite 500, 1538 Sherbrooke West	2025-02-14 13:07:36.701+00	2025-01-05 18:32:05.638+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
22	clinique-mdicale-en-route	Clinique Médicale en Route	Clinique Médicale en Route provides blood work services, general medicine, physiotherapy, and many other services. Specialists are also available.	https://cliniqueenroute.com/en/	Contact organization regarding pricing and insurance coverage.	\N	514-312-7777	150 rue Ste-Catherine O, Level 4, Tour Hilton, C.P.65	2025-02-14 13:08:11.65+00	2025-01-05 18:32:05.212+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
21	sant-mont-royal-urgent-medical	Santé Mont Royal  – Urgent Medical Clinic	Santé Mont Royal's Urgent Medical Clinic division provides GMF, urgent care, family medicine, and specialist appointments.	https://santemontroyal.com/index.asp?Lang=En	Medical services are covered by RAMQ.	reception@santemontroyal.com	514-819-6649	4480 Chemin de la Côte de liesse Suite 110 Ville	2025-02-14 13:09:06.787+00	2025-01-05 18:32:04.777+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
20	hpital-notredame	Hôpital Notre-Dame	Hôpital Notre-Dame provides an emergency room open 24/7 where patients can ask for the on-call sexual assault support worker.	https://www.mcgill.ca/osvrse/get-support/additional-resources/off	\N	\N	(514) 413-8999	1560 Sherbrooke E. Emergency room: Plessis St. entrance	2025-02-14 13:09:21.902+00	2025-01-05 18:32:04.383+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
19	montreal-sexual-assault-centre	Montreal Sexual Assault Centre/CLSC Metro	Montreal Sexual Assault Centre/CLSC Metro provides accompaniment services, medical examinations, forensic examinations, medical monitoring and treatment, information on follow-up therapy, and a 24/7 crisis line.	http://cvasm.org/main.asp?lang=en&page=accueil	\N	info@cvasm.ca	888-933-9007	\N	2025-02-14 13:10:17.854+00	2025-01-05 18:32:03.928+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
18	centre-de-sant-des-femmes-de-m	Centre de Santé des Femmes de Montréal (Women's Centre of Montréal)	The Centre de Santé des Femmes de Montréal (Montreal Women’s Health Centre) offers abortion services, gynecology services to members with a file, and sexual and reproductive health training sessions.	https://csfmontreal.qc.ca/en/home/	The abortion is free if you have a valid Quebec health insurance card (RAMQ), if you are covered by the Interim Federal Health Program (IFHP), if you are from another Canadian province and for most foreign university students.	\N	514-270-6110	3401, Avenue De Lormier, Montreal, QC H2K 3X5	2025-02-14 13:11:16.856+00	2025-01-05 18:32:03.328+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
17	morgentaler-clinic	Morgentaler Clinic	The Morgentaler Clinic offers a wide range of abortion care and related services, including counselling, contraceptive education and testing for sexually transmitted infections (STIs).	https://montrealmorgentaler.ca/en/	Fees apply if you do not have RAMQ or IFHP. Contact for specific fees.	infos@montrealmorgentaler.ca	514-844-4844	8560 rue St-Hubert	2025-02-14 13:12:09.636+00	2025-01-05 18:32:02.868+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
16	clinique-mdicale-fmina	Clinique Médicale Fémina	Clinique Médicale Fémina is a clinic that offers abortion services during the first trimester of pregnancy. Additional services include contraception consultations, contraception insertions and removals, and vasectomies.	http://www.clinique-femina.com/	Free with RAMQ card.	femina@clinique-femina.com	514-843-6706	1265, rue Berri, Room 430	2025-02-14 13:12:53.113+00	2025-01-05 18:32:02.38+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
34	first-nations-and-inuit-health	First Nations and Inuit Health Branch/Quebec Region	To obtain information on health benefits program.	http://www.hc-sc.gc.ca/	\N	\N	\N	\N	2025-01-05 18:32:10.878+00	2025-01-05 18:32:10.878+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
35	duplicate-of-75	DUPLICATE OF #75	Listening, support, crisis line. Service is available in Cree, Ojibway, Inuktitut, English and French	https://hopeforwellness.ca/home.html	\N	\N	855-242-3310	\N	2025-01-05 18:32:11.3+00	2025-01-05 18:32:11.3+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
37	first-nations-and-inuit-suicid	First Nations and Inuit Suicide Prevention Association of Quebec and Labrador	The First Nations and Inuit Suicide Prevention Association of Quebec and Labrador provides community awareness, prevention, and education services. They actively support the development of psychosocial interventions and make them accessible in the language and the cultural context respective of each nation and community.	http://www.dialogue-for-life.com/	\N	2023dialogueforlife@gmail.com	438-375-1036	3177 St. Jacques West, suite 202\nMontreal, Quebec H4C 1G7	2025-01-05 18:32:12.16+00	2025-01-05 18:32:12.16+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
42	residential-school-crisis-line	Residential School Crisis Line	The Indian Residential Schools Resolution Health Support Program provides safe, confidential, respectful, and non-judgmental mental health and emotional support services to eligible former Indian Residential School students and their families throughout all phases of the Indian Residential School Settlement Agreement, including the Common Experience Payments (CEP), Independent Assessment Process (IAP), Truth and Reconciliation Commission (TRC) events, and Commemorative activities.	\N	\N	\N	866-925-4419	\N	2025-01-05 18:32:14.558+00	2025-01-05 18:32:14.558+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
46	integrated-stbbi-screening-and	Integrated STBBI Screening and Prevention Services (SIDEP+)	The mission of SIDEP+ clinic is to provide HIV and other STBBI prevention services to men who have sex with men and trans people.	https://santemontreal.qc.ca/en/public/support-and-services/sidep-clinic/	\N	\N	514-527-9565	CLSC de la Visitation\n1705, rue de la Visitation\nMontréal H2L 3C3	2025-02-14 12:29:14.959+00	2025-01-05 18:32:16.358+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
45	trramm-directory-transresource	TRRAMM Directory: Trans*Resources At Montreal	TRRAM is a directory that provides resources for trans people in Montreal by a trans person in Montreal. The directory features employment services, community events, and medical guidance. 	https://www.trram.directory/	\N	\N	\N	Directory of various resource locations catered to trans persons in Montreal.	2025-02-14 12:30:53.436+00	2025-01-05 18:32:15.938+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
44	vision-2120	Vision 21/20	Optometrist with Aboriginal clientele.	\N	\N	\N	514-931-3591	\N	2025-02-14 12:32:19.363+00	2025-01-05 18:32:15.497+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
43	tasiutigiitassociation-of-cros	Tasiutigiit-Association of Cross-Cultural Families of Inuit and Native Children	Tasiutigiit Association of Cross-Cultural Families of Inuit and Native Children provides friendship and support group for cross-cultural families of Inuit and native children in the greater Montreal area. Their services include programming to support indigenous culture and wellness resources. 	https://tasiutigiit.org/	\N	\N	450-479-6827	Contact organization for address	2025-02-14 12:35:22.006+00	2025-01-05 18:32:15.031+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
41	quebec-native-women-inc	Quebec Native Women Inc	Quebec Native Women Inc. supports Aboriginal women in their efforts to better their living conditions through the promotion of nonviolence, justice, equal rights and health. They promote the development of new training initiatives for Indigenous women.	www.faq-qnw.org	\N	info@faq-qnw.org	450-632-0088	Contact organization for address	2025-02-14 12:37:32.004+00	2025-01-05 18:32:14.079+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
40	native-womens-shelter-of-montr	Native Women's Shelter of Montreal	Native Women's Shelter of Montreal (NWSM) provides a safe environment for Indigenous women and children to begin rebuilding their lives. Support and frontline services are offered to First Nations, Inuit and Métis women and children. They offer many programs relating to wellness, family care, and addiction support. 	http://www.nwsm.info/	\N	nakuset@gmail.com	514-933-4688	Contact organization for address	2025-02-14 12:38:42.996+00	2025-01-05 18:32:13.62+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
39	native-aboriginal-friendship-c	Native (Aboriginal) Friendship Centre of Montreal	The Native Friendship Centre of Montreal is an urban multipurpose centre with homeless projects, health services and information, and youth programs. This Aboriginal centre consists of population from ten First Nations of Quebec as well as the Inuit and Metis of Montreal. 	http://www.nfcm.org/	\N	\N	514-499-1854	2001 Saint-Laurent Boulevard Montreal, Quebec H2X 2T3 Canada	2025-02-14 12:39:47.161+00	2025-01-05 18:32:13.164+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
38	native-montreal	Native Montreal	Native Montreal has a variety of programs for different needs. Their programs include wellness navigation, education, culture, land-based programs, community, as well as sports and leisure programs.	https://nativemontreal.com/	\N	info@nativemontreal.com	514-331-6587	3183 Rue Saint-Jacques, Montréal, QC, H4C 1G7	2025-02-14 12:40:28.896+00	2025-01-05 18:32:12.679+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
36	mcgill-first-peoples-house	McGill First People's House	McGill's First Peoples' House offers a "home away from home" for Indigenous students. Services they offer include wellness and cultural programming services, Indigenous student mentorship programs, and support programs.	https://www.mcgill.ca/fph/	\N	\N	514-398-3217	First Peoples' House at McGill\n3505 Peel Street\nMontreal, Quebec H3A 1W7	2025-02-14 12:55:25.463+00	2025-01-05 18:32:11.71+00	t	t	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
33	mcgill-sport-medicine-clinic	McGill Sport Medicine Clinic	McGill's Sport Medicine Clinic provides sport medicine, massage therapy, physiotherapy, osteopathy, and more. Book an appointment through the website.	https://www.mcgillsportmedicineclinic.ca	\N	sportsmedicine.athletics@mcgill.ca	514-398-7007	475 Pine Ave W, Montreal, Quebec H2W 1S4	2025-02-14 12:56:20.082+00	2025-01-05 18:32:10.423+00	t	t	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
32	centre-mdicale-metromedic	Centre Médicale Metro-Medic	Centre Médicale Métro Médic provides services in family medicine, dermatology, gynecology, and psychiatry, as well as access to diagnostic services provided by their wholly owned subsidiary, CDL Laboratories. Minor and general surgery services are also offered at this clinic.	https://www.metromedic.com	RAMQ-affiliated clinics covers most of the cost. Private clinics are covered by most private insurance plans.	\N	514-932-2122	1538 Sherbrooke Street West, Suite 100\nMontréal, Québec, H3H 2L9	2025-02-14 12:56:53.161+00	2025-01-05 18:32:09.964+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
53	head-and-hands	Head and Hands	Head and Hands is a youth health service that provides free medical services, legal services, counseling services, and food pantry for young adults aged 12 to 25. Head and Hands prioritizes harm-reduction, non-judgment, education, holistic care, and confidentiality.	http://www.headandhands.ca/	\N	info@headandhands.ca	514-481-0277	3465 ave Benny\nMontreal, QC H4B 2R9	2025-01-05 18:32:19.849+00	2025-01-05 18:32:19.849+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
57	clinique-mdicale-lactuel	Clinique Médicale L’Actuel	Clinique Médicale L'Actuel specializes in sexual health. This clinic has a wide range of services including non-emergency STI testing, post-exposure prophylaxis (PEP), quick-HIV testing, hepatitis clinics, and opioid replacement therapies like methadone and suboxone.	http://cliniquelactuel.com/home	A charge of $5.00 to $15.00 is issued for laboratory services. Please contact the clinic for more information regarding pricing and insurance coverage.	courriel@lactuel.ca	514-524-1001	CLINIQUE MÉDICALE L'ACTUEL\n1001, boul. De Maisonneuve Est, bureau 1130\nMontréal Québec H2L 4P9	2025-01-05 18:32:21.764+00	2025-01-05 18:32:21.764+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
59	quorum	Quorum	Quorum is a medical clinic that specializes in sexual health and ITSS. Their services include HIV, STIs, and hepatitis care as well as women's health and transgender health services. These services are available by appointment only. Their website is only available in French.	http://cliniquequorum.com/	Contact for information regarding insurance and costs.	info@cliniquequorum.com	514-360-0614	800, boul. de Maisonneuve Est suite RC-1\nMontréal (QC), H2L 4L8	2025-02-14 12:13:00.945+00	2025-01-05 18:32:22.721+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
58	clinique-mdicale-de-lalternati	Clinique Médicale de L’Alternative	Clinique Médicale de L’Alternative specializes in contraception, abortion and sexual health services. It offers a number of STI and HIV testing, vasectomy, and contraception options including implants and prescriptions such as the Pill, Plan B, or Depo-Provera. Surgical and medical abortion services are also available.	http://www.cliniquedelalternative.com/	Services are free upon presentation of RAMQ card or Blue Cross. If you do not have these, please contact the clinic to find the applicable cost/fees.	\N	514-281-9848	2034, Rue St-Hubert, Montreal, QC	2025-02-14 12:13:46.983+00	2025-01-05 18:32:22.255+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
56	clinique-de-psychologie-cognit	Clinique de Psychologie Cognitive Comportementale, Clinique Change en Famille (Change Psychology Clinic)	Change Psychology Clinic is a multidisciplinary psychology clinic, that specializes in Cognitive Behavioral Therapy for a variety of mental health disorders and physical conditions. They offer a combination of psychology and nutritional counselling to individuals, couples and families for children, teenagers and adults. Some others services they offer include sexology, art therapy, animal assited therapy, and online therapy.	https://changepsy.ca/en/	\N	info@changeenfamille.ca	514-508-5779	1030 Cherrier Street #507, Montreal, Qc H1L 1H7 AND\n2100 Av. de Marlowe #630, Montreal, Qc, H4A 3L5	2025-02-14 12:18:11.673+00	2025-01-05 18:32:21.275+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
55	the-good-food-box-student-nutr	The Good Food Box - Student Nutrition Accessibility Club (SNAC) McGill	The Good Food Box, offered by SNAC, is a free weekly produce distribution program, with produce supplied by Terra Bella, a local, family-owned grocery distributor. Please note that the Good Food Box is available only to members of the McGill community, especially those facing food insecurity. See their website to register for the Good Food Box. A paid option is also offered through their partners at Marché Second Life.​	https://snacmcgill.wixsite.com/snac/the-good-food-box	\N	snac.mcgill@gmail.com	\N	Room 106 in the University Centre at McGill's downtown campus	2025-02-14 12:19:20.706+00	2025-01-05 18:32:20.808+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
54	midnight-kitchen	Midnight Kitchen	Midnight Kitchen offers free weekly lunch program that offers plant-based and nut-free creative dishes and salads targeted to low-income students, and/or students with disabilities, chronic illness, mental health conditions, or other impairments, who self-identify as benefiting from access to food through Midnight Kitchen. See their website or social media for their lunch calendar.	https://midnightkitchen.org/meal-program	\N	midnightkitchencollective@gmail.com	\N	SSMU Ballroom (University Centre, 3rd Floor), 3480 McTavish Street	2025-02-14 12:20:52.379+00	2025-01-05 18:32:20.331+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
52	drugs-help-and-referral	Drugs: Help and Referral	Drugs: Help and Referral is a 24/7, free and confidential substance use service. It provides support, information and referrals to anyone worried about their own or a loved one's use of drugs, alcohol and/or medication. Drugs: Help and Referral services help people discover resources and intervention centers in their area to meet their support needs.	https://www.aidedrogue.ca/en/	\N	\N	514-527-2626	\N	2025-02-14 12:22:54.319+00	2025-01-05 18:32:19.373+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
51	alcochoix	Alcochoix+	Alcochoix+ is a program that provides support and solutions for those concerned about the consequences their drinking habits and want to change them. Alcochoix+ offers a self-directed program option, a counsellor-guided option, or a support group option.	https://www.quebec.ca/en/health/advice-and-prevention/alcohol-drugs-gambling/alcochoix-plus/	\N	\N	\N	Contact your local CLSC to find out where this service may be offered.	2025-02-14 12:23:20.902+00	2025-01-05 18:32:18.835+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
50	smat	SMAT	Service de Messagerie texte pour Arrêter le Tabac (SMAT) is a free, online automated text messages services that provides individual-specific support and advice to help people quit cigarettes. People can sign up for SMAT through both SMS and Messenger. Usual text messaging and data charges may apply.	https://www.smat.ca/en?&lang=en?lang=en	For Quebec residents only.	\N	\N	\N	2025-02-14 12:24:21.905+00	2025-01-05 18:32:18.306+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
49	i-quit-now	I Quit Now	I Quit Now is a free and confidential online service that helps people quit cigarettes. People can seek help by speaking to a specialist on the phone or in-person, participating in QUIT NOW online, receiving helpful advice by text, or by finding an in-person Quit Smoking Centre closest to them. 	https://www.tobaccofreequebec.ca/iquitnow	For Quebec residents only.	\N	866-527-7383	Locations vary depending on city.	2025-02-14 12:25:30.27+00	2025-01-05 18:32:17.8+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
48	go-freddie	Go Freddie	Go Freddie offers online PreP services. Through Go Freddie, patients can speak with an affirming clinician for blood tests prior to starting the medication. PreP prescriptions and medication delivery are available for free or at a low cost at Go Freddie. The Go Freddie Health Hub also provides LGBTQ+ focused sexual health services and wellness resources.	https://www.gofreddie.com/	\N	\N	437-747-7584	Online service with locations across Canada.	2025-02-14 12:26:15.293+00	2025-01-05 18:32:17.326+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
66	talk-suicide-formerly-canada-s	Talk Suicide (formerly Canada Suicide Prevention Service)	Talk Suicide is a suicide crisis helpline that offers support for those who need urgent help, those who are unsure if they need help, and those who are worried about someone else. They offer 24/7 support by trained crisis responders via phone (toll free) and 4pm - midnight (EST) via SMS messaging.	https://talksuicide.ca	\N	\N	833-456-4566	\N	2025-01-05 18:32:25.953+00	2025-01-05 18:32:25.953+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
67	tracom-centre-for-crisis-inter	TRACOM Centre for Crisis Intervention	TRACOM Centre for Crisis Intervention is a 24/7, free crisis intervention service for those experiencing high levels of anxiety, distress, or suicidal ideas.\nThis intervention service provides psychosocial crisis intervention services to an adult clientele, as well as family members, caregivers, or friends of adults in distress. They also provide short-term housing to help patients through their intervention plans and community follow-up.	https://www.tracom.ca/services-en	\N	\N	514-483-3033	Confidential, offers free pickup to access centers as well.	2025-01-05 18:32:26.401+00	2025-01-05 18:32:26.401+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
68	wellness-together-canada	Wellness Together Canada	Wellness Together Canada is a mental health and substance use support service. Wellness Together's online platform and Pocketwell app consolidates mental wellness resources to learn and practice mental wellness as well as track your progress. It also offers to option to call and talk with a counselor.	https://www.wellnesstogether.ca/en-CA	\N	\N	855-242-3310	\N	2025-01-05 18:32:26.853+00	2025-01-05 18:32:26.853+00	f	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
73	hope-for-wellness-helpline	Hope for Wellness Helpline	The Hope for Wellness Helpline provides mental health for support Indigenous people. Their trained counsellors are experienced, culturally competent, and available by phone or online chat 24/7. Their services are available in English and French as well as telephone counselling in Cree, Ojibway and Inuktitut upon request.	https://www.hopeforwellness.ca	\N	\N	855-242-3310	\N	2025-01-05 18:32:29.206+00	2025-01-05 18:32:29.206+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
72	sos-conjugal-violence	SOS Conjugal Violence	SOS Conjugal Violence offers support for those in the province of Québec facing domestic violence. Anyone who is concerned about domestic violence regardless of their sex, sexual orientation, age, ethnic background is encouraged to use this service. They offer chat, text, phone and email services 24/7.	https://sosviolenceconjugale.ca/en/looking-for-answers	\N	sos@sosviolenceconjugale.ca	800-363-9010	\N	2025-02-14 11:58:18.302+00	2025-01-05 18:32:28.736+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
71	telus-health-student-support-f	Telus Health Student Support (formerly keep.meSAFE via My SSP)	Telus Health Student Support provides 24/7, confidential mental health support for students from experienced professionals in real time. This service can be accessed through its app, telephone number and website. There are no additional charges for students enrolled in schools that have signed up for Student Support - McGill University is registered. 	https://myssp.app/ca/home	Instant access at no additional charge for students enrolled in schools that have signed up for Student Support.	\N	844-451-9700	\N	2025-02-14 12:00:41.846+00	2025-01-05 18:32:28.269+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
70	west-island-crisis-center	West Island Crisis Center	The West Island Crisis Center provides support for adults 16 years of age or older who are experiencing a situational crisis, emotional distress, and suicidal ideation. They offer a 24/7 crisis line, crisis intervention in the community, short-term residential stays, and post-crisis support.	https://www.centredecriseoi.com/en/index.html	\N	\N	514-684-6160	\N	2025-02-14 12:01:57.079+00	2025-01-05 18:32:27.805+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
69	telaide-montreal	Tel-Aide Montreal	Tel-Aide Montreal is a free, confidential, and anonymous listening service. This call center in Quebec offers a listening service for those who are suffering from mental health problems or simply needing to be listened to. Tel-Aide Montreal work with clients that are struggling with issues including stress at work, emotional distress, solitude, strained relationships, abuse and intimidation, and domestic violence.	http://telaidemontreal.org/en/	\N	\N	514-935-1101	\N	2025-02-14 12:02:58.797+00	2025-01-05 18:32:27.314+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
65	suicide-action-montral	Suicide Action Montréal	Suicide Action Montreal (SAM) offers a range of services to Montrealers who are distressed or suicidal, their family, the individual`s social network, workers and/or other professionals who might be involved. SAM also supports those who have experienced the suicide of a loved one. Their services provide research-based training for a diverse audience as well as resources specifically developed for workers, professionals, schools and organizations affected by suicide.	https://suicideactionmontreal.org/en/	\N	\N	866-277-3553	\N	2025-02-14 12:05:31.135+00	2025-01-05 18:32:25.51+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
63	lactuel-sur-rue	L'Actuel sur Rue	This clinic offers drop-in services including, free, confidential rapid/standard HIV screening, standard syphilis test, and vaccination against Hepatitis A and/or B. They also provide access to sexual health care and appointments with specialized physicians, one-on-one prevention, and sex education. 	https://cliniquelactuel.com/	\N	courriel@lactuale.ca	514 524 1001	1359, rue Ste-Catherine Est, Mtl, QC, H2L 2H7	2025-02-14 12:09:11.34+00	2025-01-05 18:32:24.56+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
62	ciusss-westcentral-montreal-si	CIUSSS West-Central Montreal \nSIDEP Clinic - CLSC Métro	This is a clinic offering sexually transmitted and blood-borne infections (STBBI) screening services for those who fall into one of the following criteria groups: multiple sexual partners in the last year, man who has sex with men, unprotected sex with a new partner, user of intravenous (injecting) or intranasal (snorting) drugs. 	https://www.ciussswestcentral.ca/	\N	\N	\N	1801 de Maisonneuve West	2025-02-14 12:11:01.058+00	2025-01-05 18:32:24.099+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
61	ciuss-westcentral-youth-clinic	CIUSSS West-Central Youth Clinic (ages 14 to 24)	The Youth Clinic at the CIUSSS West-Central Montreal provides sexual health services for youth and young adults between the ages of 14 and 24. They provide STI tests and treatment, contraception services, pregnancy tests and guidance services, abortion services, and advice on romantic relationships.	https://www.ciussswestcentral.ca/programs-and-services/children-families-and-youth/children-teens-and-young-adults/youth-clinic-ages-14-to-24/	Contact for more information regarding non-RAMQ coverage.	\N	514-484-7878	CLSC Benny Farm: 6484 Monkland Avenue  CLSC Côte-des-Neiges: 5700 Côtes-des-Neiges Road	2025-02-14 12:12:02.679+00	2025-01-05 18:32:23.649+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
81	maple	Maple	A hand-picked network of online doctors, nurse practitioners, and allied healthcare professionals ready to help you.	https://www.getmaple.ca/	Prices start at $210/visit for a general practitioner and $110/visit for a specialist for Quebec residents.	\N	\N	\N	2025-01-05 18:32:33.3+00	2025-01-05 18:32:33.3+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
85	foundation-of-health	Foundation of Health	The Fountain of Health™ is a national non-profit initiative started at Dalhousie University Department of Psychiatry, dedicated to sharing the science of brain health and resilience and to translating that knowledge into practical action. They provide paper and app-based tools for clinicians to use in frontline care to invite and support health behavior change in 5 key health areas known to support long-term well-being. Clinical resources are free and available for use from the website.	https://fountainofhealth.ca/	\N	info@foundationofhealth.ca	\N	Online	2025-01-05 18:32:35.327+00	2025-01-05 18:32:35.327+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
89	centre-for-gender-advocacy	Centre for Gender Advocacy	The Centre for Gender Advocacy is an independent, student-funded, Concordia University organization mandated to promote gender equality and empowerment, particularly as it relates to marginalized communities. Services include gender-affirming care, peer support groups, and resource referrals. 	https://genderadvocacy.org/	Email organization for more information regarding cost and insurance coverage.	info@genderadvocacy.org	\N	2110 rue Mackay, First Floor Montréal, Quebec	2025-02-07 15:42:21.009+00	2025-01-05 18:32:37.197+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
87	the-lavender-collective	The Lavender Collective	The Lavender Collective is a Black-led community effort, that advocates for culturally relevant mental health related needs in BIPOC communities through education, network and resource building.	https://www.thelavendercollective.ca/	For information regarding pricing and insurance coverage, please contact organization or health professionals directly.	allo@thelavendercollective.ca	\N	\N	2025-02-07 15:44:02.798+00	2025-01-05 18:32:36.253+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
86	peer-support-warm-line	Peer Support Warm Line	The Warm Line is a confidential and anonymous service for adults. It is not a crisis line. If you are feeling lonely, isolated, anxious, depressed or in need of a friendly ear, chat online, text, or call a Warm Line peer support worker. Phone and Chat services available 4pm-12am EST 7 days a week.	https://www.warmline.ca/	\N	\N	888-768-2488	\N	2025-02-14 11:35:46.691+00	2025-01-05 18:32:35.799+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
84	student-wellness-app	Student Wellness App	The Student Wellness apps provides ways to look after your health is by setting small, doable health goals in areas that matter to you.	https://studentwellnessapp.org/app/login	\N	\N	\N	\N	2025-02-14 11:38:14.233+00	2025-01-05 18:32:34.911+00	f	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
82	anxiety-canada	Anxiety Canada	Anxiety Canada is a registered charity and non-profit organization created to raise awareness about anxiety and support access to resources and treatment. They are a leader in developing free, online self-help and evidence-based tools to help manage anxiety. Anxiety Canada offers a variety of services such as group therapy, an anxiety app, online courses, videos, podcasts, and pdf and downloadable resources.	https://www.anxietycanada.com/	Free, except for assessment fee, which is returned upon completion of the group CBT program.	\N	\N	\N	2025-02-14 11:42:10.818+00	2025-01-05 18:32:33.923+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
80	local-wellness-advisors	Local Wellness Advisors	LWAs (Local Wellness Advisors) are mental health professionals located within each faculty at McGill University. There are also LWAs for marginalized groups and students living in McGill residences. They provide outreach events and workshops and have one-on-one appointments.	https://www.mcgill.ca/wellness-hub/hub-clinical-services/hub-clinicians/local-wellness-advisors	\N	\N	\N	Student Wellness Hub	2025-02-14 11:47:12.173+00	2025-01-05 18:32:32.788+00	t	t	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
79	student-wellness-hub-mental-he	Student Wellness Hub Mental Health, Health Professionals and Counselling Services	Counsellors and Local Wellness Advisors (LWAs) are mental health professionals that can help McGill students reach their mental health and wellness goals. Student can also access a wide range of services, including support from dietitians, doctors, nurses, psychiatrists, sexologists, and laboratory services at McGill.	https://www.mcgill.ca/wellness-hub/about-hub/clinicians	Fees vary depending on service. Late cancellation and no-show fees apply.	hub.clinic@mcgill.ca	(514) 398-6017	Student Wellness Hub	2025-02-14 11:47:48.95+00	2025-01-05 18:32:32.258+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
78	mcgill-access-advisors	McGill Access Advisors	McGill Access Advisors provide help and guidance to McGill students who would like to access services offered by the Student Wellness Hub. They provided one-on-one appointments and run workshops.	https://www.mcgill.ca/wellness-hub/hub-clinical-services/hub-clinicians/access-advisors	\N	\N	\N	Student Wellness Hub	2025-02-14 11:48:39.396+00	2025-01-05 18:32:31.775+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
77	mcgill-students-nightline	McGill Students' Nightline	McGill Students’ Nightline is a confidential, anonymous, and non-judgmental listening service run by McGill students, providing the community with non-professional support in various situations, including information, guidance during a crisis, or an empathetic space to share your experiences and emotions. Services in English only. The Nightline has an online chat and telephone, both operate from 6pm to 3am. 	https://nightline.ssmu.ca	\N	\N	514-398-6246	\N	2025-02-14 11:50:39.566+00	2025-01-05 18:32:31.312+00	t	t	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
76	sacomss-sexual-assult-centre-o	SACOMSS: Sexual Assult Centre of the McGill Student's Society	The Sexual Assault Centre of the McGill Students’ Society is a volunteer-run organization committed to supporting survivors of sexual assault and their allies through direct support, advocacy, and outreach. Their services include drop-in and online, support groups, and advocacy, and outreach services. They offer sexual assault sensitivity training to McGill and Montreal groups, provide information and referrals, and organize events to raise awareness about sexual assault.	http://www.sacomss.org/wp/	\N	sacomss@gmail.com	438-943-4855	The University Centre, 3480 Rue McTavish, Room B27, Montreal, QC, H3A 0E7	2025-02-14 11:51:44.142+00	2025-01-05 18:32:30.67+00	t	t	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
75	sexual-assault-provincial-help	Sexual Assault Provincial Helpline	The Montreal Sexual Assault Centre offers a range of bilingual services free of charge to victims of sexual violence. Services are also offered to the victim’s family and close friends. Local services include medical and legal support, and clinical services for victims ages 18+, and their close ones. \nProvincial services include a Sexual Violence Helpline (learn more at sexualviolencehelpline.ca) and Support Service for Designated Centres Providing Medico-social Services for Sexual Assault Victims (learn more at en.serviceconseilqc.ca)	https://www.cvasm.org/en/	\N	\N	888-933-9007	\N	2025-02-14 11:52:31.672+00	2025-01-05 18:32:30.211+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
93	dialogue-app	Dialogue (app)	Dialogue provides virtual mental health care to Canadians. They provide high quality healthcare services delivered with expertise, convenience, and warmth.	https://www.studentcare.ca/rte/en/McGillUniversityundergraduatestudentsSSMU_Dialogue_Dialogue	SSMU members are automatically covered by HI (Virtual Health Care). The fee for full-year access (from Sept. 1, 2023 – Aug. 31, 2024) is $44.84. New Winter Term students pay $29.90 for access from Jan. 1 – Aug. 31, 2024. Please check your tuition statement to confirm if you've been automatically charged the HI (Virtual Health Care) fee.	\N	\N	\N	2025-01-05 18:32:39.08+00	2025-01-05 18:32:39.08+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
103	psychiatrists-student-wellness	Psychiatrists (Student Wellness Hub)	Psychiatrists at the McGill Student Wellness Hub can diagnose mental illnesses, prescribe and monitor medication, and make referrals for appropriate care, both on- and off-campus. You must be referred to by a medical doctor before visiting the psychiatrist. 	https://www.mcgill.ca/wellness-hub/about-hub/clinicians/psychiatrists	\N	\N	(514) 398-6018	Student Wellness Hub	2025-02-07 15:15:02.24+00	2025-01-05 18:32:43.732+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
102	doctors-mcgill-student-wellnes	Doctors (McGill Student Wellness Hub)	Doctors at the Student Wellness Hub are a great first option to provide care and referrals for any medical condition. Appointments are required and can be booked on the phone or through a nurse.	https://www.mcgill.ca/wellness-hub/hub-clinical-services/hub-clinicians/nurses-doctors#Nurses	\N	\N	(514) 398-6017	Student Wellness Hub	2025-02-07 15:16:10.407+00	2025-01-05 18:32:43.269+00	f	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
101	nurses-mcgill-student-wellness	Nurses (McGill Student Wellness Hub)	Nurses at the Student Wellness Hub have an important role in providing preventative medical interventions to students and are a great first point of contact when faced will health concerns. 	https://www.mcgill.ca/wellness-hub/hub-clinical-services/hub-clinicians/nurses-doctors#Nurses	\N	\N	(514) 398-6017	Student Wellness Hub	2025-02-07 15:16:45.743+00	2025-01-05 18:32:42.768+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
100	montreal-overeaters-anonymous	Montreal Overeaters Anonymous	Overeaters Anonymous (OA) is a Twelve-Step Fellowship for people recovering from compulsive eating. OA is not a diet club, but rather a supportive community focused on helping individuals overcome compulsive eating, anorexia, bulimia, food addiction, and obesity. If you’re struggling, OA provides a space where you can find support and guidance.	https://oamontrealenglish.org/meetings/	\N	info@oamontrealenglish.org	(514)-488-1812	Locations vary. Online meetings also available.	2025-02-07 15:17:15.331+00	2025-01-05 18:32:42.295+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
98	y-mind-ymca	Y Mind (YMCA)	Y Mind Youth is a free seven-week mental wellness program for young adults aged 18 to 30 and struggling with mild-to-moderate anxiety or stress. Anxiety can impacts the lives of young adults by preventing them from doing what we want or need to do. It can also be an isolating experience, and Y Mind is here to help. Fill their interest form to receive more information about the wellness program. 	https://www.ymca.ca/ymind	\N	\N	\N	Quebec	2025-02-07 15:21:09.413+00	2025-01-05 18:32:41.366+00	t	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
97	project-10	Project 10	Project 10 works to promote the personal, social, sexual and mental well being of lesbian, gay, bisexual, transgender, transsexual, two-spirit, intersex and questioning (2LGBTQ+) youth and adults 14-25.	https://www.p10.qc.ca/	\N	\N	514-989-0001	10138 Rue Lajeunesse, Montréal, Quebec H3L 2E2	2025-02-07 15:22:48.365+00	2025-01-05 18:32:40.885+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
96	yes-montreal	Yes Montreal	YES is a non-profit, community-driven English-language service provider that has been helping Quebecers find employment and develop as entrepreneurs since 1995.	https://yesmontreal.ca/	\N	info@yesmontreal.ca	(514) 878-9788	666 Sherbrooke St. W., suite 700\nMontreal, QC H3A 1E7	2025-02-07 15:24:18.599+00	2025-01-05 18:32:40.437+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
95	211-grand-montreal	211 Grand Montreal	211 is an information and referral service that connects citizens to community organizations, public and para-public services and programs near them. They are available through phone and an online chat. 	https://www.211qc.ca/en/	\N	\N	844-387-3598	\N	2025-02-07 15:25:42.956+00	2025-01-05 18:32:40.04+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
94	black-mental-health-connection	Black Mental Health Connections Peer Support Program	Black Mental Health Connections Montreal is an alliance of organizations and individuals focused on the mental health and well-being of the English-speaking Black community in Montreal. Their Peer Support Program provides the opportunity for Black individuals to talk and connect with others who are like them and have lived shared experiences. This program is remote and offered online. Complete the interest form to join the program. 	https://bmhcmtl.ca/online-peer-support-group/	Contact organization regarding fees and insurance coverage.	info@bmhcmtl.ca	\N	\N	2025-02-07 15:28:53.946+00	2025-01-05 18:32:39.565+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
92	womens-centre-of-montreal	Women's Centre of Montreal	The Women's Centre of Montreal is a non-profit organization created by women, for women. Their mission is to provide educational and vocational training, as well as information, counselling and referral services to help women themselves.	https://centredesfemmesdemtl.org/en/	Contact organization regarding fees and insurance coverage.	spl@centredesfemmesdemtl.org	514-842-4780	3585 Saint-Urbain Montréal (Québec) H2X 2N6	2025-02-07 15:31:53.209+00	2025-01-05 18:32:38.578+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
91	calm-app	Calm (app)	Calm is mental health platform that provides ressources for sleep, meditation, and relaxation. This ressource is available for free to McGill students through sign up with McGill email.	https://ssmu.ca/resources/access-to-prowritingaid-calm-and-udemy/	Calm's premium membership is offered for free to McGill students.	\N	\N	\N	2025-02-07 15:32:13.338+00	2025-01-05 18:32:38.114+00	f	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
90	expression-lasalle	Expression Lasalle	Expression LaSalle centre communautaire en santé mentale, located in the borough of LaSalle (Montreal), is a community mental health centre whose objective is to offer free professional therapeutic services in mental health to citizens of Montreal (18 to 65 years of age inclusively) and surrounding areas. The Centre focuses on creative arts therapies (art therapy, drama therapy, music therapy, etc.), relaxation and meditation workshops, and discussion groups on the theme of sexual abuse, and verbal counseling encouraging self-expression, and emotional well being.	https://www.expressionlasalletherapies.ca/services/	The services are free. A nominal yearly administrative fee (Membership Card) is payable upon participation only.	info@expressionlasalletherapies.ca	514-368-3736	405 Terrasse Newman, Office 210 LaSalle (Quebec) H8R 2Y9	2025-02-07 15:35:47.977+00	2025-01-05 18:32:37.676+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
115	maison-de-lina-linas-home	Maison de Lina (Lina's Home)	Maison de Lina is a shelter and service provider that aims to support women and children who are victims of domestic violence. Their services include a 24/7 helpline, accommodations, external services, youth services, and other services such as legal ones.	https://maisondelina.org/en/services/	\N	info@maisondelina.org.	450-962-8085	Location is confidential.	2025-01-29 18:10:56.031+00	2025-01-05 18:32:49.846+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
114	black-healing-center-bhc	Black Healing Center (BHC)	The BHC provides access to free and subsidized therapy for members of the Black community. They aim to counteract the shared trauma that comes with the Black experience by empowering those of Black descent to reclaim their mental, physical, emotional, and spiritual wellness. BHC offers services, including support groups such as the Black Men's Wellness program, Black Queer and Trans Collective Circle, and Black Women's Collective Care Circle. They also provide training, retreats, and research opportunities.	https://www.blackhealingcentre.com/	\N	info@blackhealingcentre.com	\N	Locations vary.	2025-01-29 18:13:08.743+00	2025-01-05 18:32:49.356+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
113	neurodivergent-student-support	Neurodivergent Student Support Group (Student Wellness Hub)	The Neurodivergent Student Support Group helps neurodivergent students who are seeking support to navigate alternative learning methods and develop the confidence and communication skills to help navigate interpersonal relationships. Neurodivergent students include those who fall within the spectrum of neurodiverse learning styles or those on the autism spectrum. Participants of this group will have the opportunity to share mutual experiences, challenges, and tips on navigating academic and personal wellness at McGill.	https://www.mcgill.ca/studentaid/channels/event/neurodivergent-students-support-group-361846	\N	\N	\N	Healthy Living Annex-Room 3100 (Brown Student Services), 3600 McTavish, CA	2025-01-29 18:16:43.881+00	2025-01-05 18:32:48.72+00	t	t	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
112	lotus-initiative-mcgill	Lotus Initiative McGill	The Lotus Initiative is a student-run organization through McGill University that allows students to better their mental health by hosting various free fitness classes such as yoga, floor barre, dance, and spin.	https://www.instagram.com/lotusinitiative.mcgill/?hl=en	\N	\N	\N	Locations vary.	2025-01-29 18:17:34.185+00	2025-01-05 18:32:48.259+00	t	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
111	ssmu-walksafe	SSMU WalkSafe	SSMU WalkSafe is a student-run service that provides McGill students with safe and free walks home. WalkSafe volunteers wear easily-identifiable red jackets and provide their peers with a safe way to get to where they need to go.	https://walksafe.ssmu.ca	\N	executive@walksafe.ca	(514) 398-2498	Locations vary.	2025-01-29 18:47:09.43+00	2025-01-05 18:32:47.787+00	t	t	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
110	ssmu-drivesafe	SSMU DriveSafe	SSMU DriveSafe is a student-run service that provides McGill students with safe and free drives home from anywhere on the Island of Montreal as well as to Montmorency metro station, Longueuil metro station, and to Kahnawá:ke. For their marginalized communities initiatives, they extend regular service to the Mohawk Territory of Kahnawake, and will treat all calls to Kahnawake as regular calls on all days.\n\nDriveSafe operates from Thursday to Saturday from 11pm to 3am. 	https://drivesafe.ssmu.ca	\N	drivesafe@ssmu.ca	(514) 398-8040	Locations vary.	2025-01-29 18:49:37.762+00	2025-01-05 18:32:47.328+00	t	t	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
108	vent-over-tea	Vent Over Tea	Vent Over Tea is a free and confidential active listening service. There are in-person and virtual sessions available that can be booked through their website. Active-listening workshops and events are also available.	ventovertea.com	\N	info@ventovertea.com	\N	Locations vary	2025-02-07 15:03:47.137+00	2025-01-05 18:32:46.17+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
109	mcgill-student-accessibility-a	McGill Student Accessibility and Achievement	McGill Student Accessibility and Achievement services provides resources and accommodations for McGill students who are experiencing academic, mental, or physical barriers. Students must have a documented disability, mental health condition, chronic health condition, or other impairment. Appointments can be made online or in-person.	https://www.mcgill.ca/access-achieve/	\N	access.achieve@mcgill.ca	514-398-6009	Main Office: 1010 Sherbrooke Ouest\nSuite 410\nMontreal, Quebec \nH3A 2R7                                                                           Exam Center: 3459 McTavish Street\nRoom RS56\nMontreal, Quebec, H3A 0C9	2025-02-07 15:05:33.37+00	2025-01-05 18:32:46.883+00	t	t	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
107	friends-for-mental-health	Friends for Mental Health	Friends for Mental Health offers a wide range of services including counseling both for those suffering from mental illness and those who have family members facing mental health challenges, art therapy, dramatherapy, support groups, including services specifically for youth ages 13 through 25.	https://asmfmh.org/en/	Services offered to the residents of the West Island of Montreal (Sainte-Anne-de-Bellevue, Senneville, Baie d'Urfé, Kirklands, Beaconsfield, Pointe-Claire, Sainte-Geneviève, Île-Bizard, Pierrefonds-Roxboro, Dollard-des-Ormeaux, Dorval, Lachine)	info@asmfmh.org	514-636-6885	Locations vary	2025-02-07 15:06:49.75+00	2025-01-05 18:32:45.743+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
106	hope-and-cope	Hope and Cope	Hope and Cope supports those facing a new diagnosis, a recurrence, have an advanced cancer, or are accompanying a family member who has cancer. They offer peer support programs, support groups, wellness programs and activities in a warm and welcoming environment. Their staff and volunteers have experience with cancer, and offer help by providing companionship and emotional support.	https://hopeandcope.ca	\N	info.wellnesscentre@bellnet.ca	514-340-3616	Hope & Cope Cancer Wellness Centre \n4635 Côte-Sainte-Catherine\nMontréal, Québec H3W 1M1	2025-02-07 15:08:50.784+00	2025-01-05 18:32:45.274+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
105	big-brothers-big-sisters-of-gr	Big Brothers Big Sisters of Greater Montreal 16-21 Mentoring Program	Big Brothers Big Sisters of Montreal match young people facing adversity with trained adult mentors in 1-1 or group mentoring programs. Their mentorship program offers youth experience with these essential back-and-forth relationships, developing them into healthy young people better able to deal with and overcome life’s adversities. Big Brothers Big Sisters of Montreal champion the health and well-being of youth by intervening before it’s too late, giving youth a chance to reach their full potential.	https://gfgsmtl.qc.ca	Contact organization to inquire about fees.	Montreal@grandsfreresgrandessoeurs.ca	(514)-842-9715	3155 Hochelaga St\nOffice 202\nMontreal, QC\nH1W 1G4	2025-02-07 15:09:59.352+00	2025-01-05 18:32:44.842+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
130	muhc-mood-disorders-program	MUHC Mood Disorders Program	Therapy and treatment for mood disorders (Referral needed).	https://muhc.ca/mental-health/page/mood-disorders-program	\N	\N	514-934-1934 ext. 31798	Allan Memorial Institute 1025 Pine Avenue West  Montréal QC H3A 1A1 	2025-01-24 15:42:18.649+00	2025-01-05 18:32:56.898+00	f	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
129	douglas-hospital	Douglas Hospital	Interdisciplinary teams provide clinical services to all age groups in French and English. Treatment is provided for anxiety, depression, eating disorders, bipolar disorders, behaviour disorders, attention deficit disorders in children, Alzheimer’s disease and other forms of dementia, schizophrenia, and other forms of psychosis (Referral needed).	http://www.douglas.qc.ca/section/psychotic-disorders-144	\N	\N	\N	\N	2025-01-24 15:45:18.93+00	2025-01-05 18:32:56.454+00	f	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
128	information-and-referral-centr	Information and Referral Centre of Greater Montreal (Centraide)	An autonomous bilingual agency. It gives free information on community resources and directs persons seeking help in solving their problems (e.g., drugs and alcohol, gambling) to the appropriate agency providing the service needed.	https://www.centraide-mtl.org/en/directory-of-agencies-and-projects/information-and-referral-center-of-greater-montreal/	\N	crgm@info-reference.qc.ca	514 527-1375	Hochelaga-Maisonneuve	2025-01-24 15:47:38.808+00	2025-01-05 18:32:56.032+00	f	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
123	maple-virtual-care	Maple Virtual Care	Maple Virtual Care provides Medavie Blue Cross plan members 24/7 on-demand access to doctors by secure text or video for advice, diagnosis, and prescriptions. Members can talk with a physician within minutes online. Services include Doctor's notes, prescriptions, medical advice, lab work requisitions, and mental health services.	https://www.mcgill.ca/internationalstudents/health/coverage/maple-virtual-care	Medavie Blue Cross	\N	\N	\N	2025-01-24 16:19:02.496+00	2025-01-05 18:32:53.99+00	t	t	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
127	mcgill-counselling-clinic	McGill Counselling Clinic	Psychological services by graduate students in-training (low cost) for children, adolescents, and adults experiencing difficulties in an educational, social, vocational or interpersonal context.	https://www.mcgill.ca/edu-ecp/about/clinic	\N	ecpinfo.education@mcgill.ca	514-398-4242	Education Building, Room 614 3700 McTavish Street Montreal, Quebec Canada H3A 1Y2	2025-01-29 17:47:40.376+00	2025-01-05 18:32:55.653+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
125	uqam-centre-de-services-psycho	UQAM - Centre de services psychologiques	Psychological services by graduate students in-training are provided at a low cost for adults, children, and adolescents. Services can be arranged by appointment via telephone. 	https://psychologie.uqam.ca/centre-de-services-psychologiques-csp/	\N	\N	(514) 987-0253	200, rue Sherbrooke Ouest H2X 3P2	2025-01-29 17:49:22.202+00	2025-01-05 18:32:54.842+00	f	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
124	face-face-face-to-face-listeni	Face à Face (Face to Face) Listening and Referral Centre	Specially trained volunteers provide listening and referral services. Face à Face offers counseling services, active listening and referral line services, mail reception for those without a fixed address, and affordable housing and accompaniment services. All services are confidential and free of charge.	https://faceafacemontreal.org/contact-us/	\N	info@faceafacemontreal.org.	(514)-934-4546	1857 Maisonneuve West, suite 100 Montreal, QuebecH3H 1J9	2025-01-29 17:50:24.309+00	2025-01-05 18:32:54.418+00	t	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
121	lespace	L'Espace	L'Espace is a group of psychologists and psychotherapists that are passionate about addressing the mental health issues of today. Their services include individual therapy, couples therapy, child/adolescent therapy, teletherapy, group therapy, and flash appointments. Appointments can be made by phone, email, or on their website.	https://www.lespacepsychologie.com/services	\N	info@lespacepsychologie.com	438-520-2013	1591 rue Fleury, Est. Suite 300, H2C1S7	2025-01-29 17:53:40.443+00	2025-01-05 18:32:52.887+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
120	centre-professionnel-alternati	Centre Professionnel Alter-Natives Inc.	Centre Professionnel Alter-Natives is a centre of mental health professionals created by women of diverse ethnic identities to support people with diverse ethnic identities. They offer consultations and training aimed at individuals' psychological well-being and personal and professional development. Their approach focuses on a person's physical and mental health, personal and professional context, life stage, ethnicity, language, beliefs and culture. Mental health professionals speak multiple languages including Spanish, Creole, and Arabic (Lebanese and Tunisian dialects).Their professionals are multi-disciplinary, multi-ethnic, and multi-confessional.	https://alter-natives.ca	\N	info@alter-natives.ca	(514) 569-6222	\N	2025-01-29 17:55:20.094+00	2025-01-05 18:32:52.434+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
119	jeunesse-lambda	Jeunesse Lambda	A community organization created by and for lesbian, gay, bisexual, trans, queer, and questioning youth from 14 to 30 years old. They organize weekly discussions and themed activities to promote healthy socialization as well as the mental, sexual, and physical well-being for 2SLGBTQIA+ youth. 14 to 30-year-old trans and non-binary folks can access gear such as binders, gaffs, packers, harnesses, STP, breast forms, etc., for free or on a pay-what-you-can basis. They offer free and confidential one-on-one active listening sessions on a punctual or recurring basis and they can swear-in forms to change name and gender markers.	https://www.jeunesselambda.com/	\N	info@jeunesselambda.com	(514) 543-6343	1575 Rue Atateken, Montréal, QC H2L 3L4	2025-01-29 18:00:42.851+00	2025-01-05 18:32:51.738+00	t	f	f	f	f	\N	\N	\N	\N	\N	\N	\N	\N
118	inclusive-therapists	Inclusive Therapists	Inclusive Therapists is a mental health directory, and community focused on liberation. They help you find and match with therapists committed to racial, 2SLGBTQIA+, neurodivergent, and disability justice. They hope to amplify BIPOC and QTBIPOC voices, as well as neurodivergent and disabled communities of color. They aim to work towards mental health liberation through education, care, and activism, celebrating marginalized identities, abilities, and bodies. They also provide and reference other resources and helplines with similar values. They have therapists in Montreal, the rest of Canada, and the USA.	https://www.inclusivetherapists.com/	\N	\N	\N	N/A. They are an online directory	2025-01-29 18:03:13.053+00	2025-01-05 18:32:51.271+00	t	f	t	f	f	\N	\N	\N	\N	\N	\N	\N	\N
135	trans-lifeline	Trans Lifeline	Trans Lifeline is a grassroots hotline and microgrants 501(c)(3) non-profit organization offering direct emotional and financial support to trans people in crisis — for the trans community, by the trans community. The hotline is available 24 hours a day to help, support, and inform anyone concerned with issues of sexual diversity and gender diversity. Available by phone.	https://translifeline.org/	\N	\N	877-330-6366	Telephone	2025-02-26 18:05:26.356+00	2025-01-05 18:42:30.862+00	t	f	t	t	f	\N	Trans Lifeline	Trans Lifeline est un organisme à but non lucratif qui offre une ligne téléphonique d'urgence ainsi qu'un soutien émotionnel et financier direct aux personnes trans en situation de crise. Trans Lifeline est pour la communauté trans, par la communauté trans. La ligne d'assistance est disponible 24h sur 24 pour aider, soutenir et informer toute personne ayant des questions sur la diversité sexuelle ou des genres. Disponible par téléphone.	\N	\N	\N	\N	\N
133	ssmu-menstrual-health-project	SSMU Menstrual Health Project	The SSMU Menstrual Health Project is a service that aims to provide McGill students with free menstrual products on campus. Every month, the Menstrual Health Project Team gives out free sustainable and reusable menstrual products as well as disposable pads and tampons to members of the McGill Community. Visit their website to learn about the next menstrual product pick-up date and location.	https://ssmu.ca/resources/menstrual-health-project/#:~:text=Monthly%20Period%20Product%20Pick%2DUp&text=Each%20month%2C%20the%20Menstrual%20Health,the%20McGill%20community%20for%20free.	\N	menstrualhealth@ssmu.ca	\N	Locations vary. Please verify by checking website.	2025-02-26 18:09:41.125+00	2025-01-05 18:42:28.187+00	t	t	t	f	f	\N	Le projet de santé menstruelle de l'AÉUM	Le Projet de santé menstruelle du l'AÉUM est un service qui vise à fournir aux étudiantes de McGill des produits menstruels gratuits sur le campus. À tous les mois, l'équipe du projet de santé menstruelle distribue gratuitement des produits menstruels durables et réutilisables ainsi que des serviettes et tampons jetables aux membres de la communauté mcgillienne. Visitez leur site web pour connaître la date et le lieu de la prochaine collecte de produits menstruels.	\N	\N	\N	\N	\N
131	connecte-montreal-psychology-g	Connecte: Montreal Psychology Group	The Connecte Montreal Psychology Group is a practice that offers psychotherapy and group therapy services in English, French, and Mandarin. They provide CBT, ACT, DBT, mindfulness-based, and psychodynamic therapy. Connecte also offers group therapy, including anxiety, relationship, and eating disorder support groups.	https://connectepsychology.com/en/our-services/psychotherapy/	\N	info@connectepsychology.com	(514) 507-0745	4203 Saint Catherine Street West Westmount, QC, H3Z 1P6	2025-02-26 18:15:32.972+00	2025-01-05 18:32:57.282+00	t	f	t	f	t	\N	Connecte: Psychothérape Montréal	Le Groupe de psychothérapie Connecte Montréal est un cabinet de thérapie qui offre ses services en psychothérapie et en thérapie de groupe en anglais, en français et en mandarin. Connecte propose les options de CBT, ACT, DBT, fondées sur la pleine conscience et psychodynamiques. Connecte propose également des thérapies de groupe, y compris des groupes de soutien pour l'anxiété, les relations et les troubles de l'alimentation.	\N	\N	\N	\N	\N
132	student-wellness-hub-medical	Student Wellness Hub Medical Laboratory Services	The medical laboratory team provides in-person services to students during opening hours by appointment only. Before booking an appointment, you must have a lab requisition from a clinician working at the Student Wellness Hub. We do not accept laboratory requisitions from outside the Student Wellness Hub.\nTo book an appointment with a Hub clinician call (514) 398-6017.	https://outlook.office365.com/owa/calendar/StudentWellnessHubLaboratoryServices1@McGill.onmicrosoft.com/bookings/	\N	\N	(514) 398-6017	Student Wellness Hub	2025-01-29 17:43:08.586+00	2025-01-05 18:42:27.001+00	t	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
126	universit-de-montral-universit	Université de Montréal - University Clinic of Psychology	Clinical training and research facilities that provide low-cost psychological services for the general public. These services include psychological assessment, neuropsychological assessment, and individual, couple, and family therapy.	https://psy.umontreal.ca/ressources-services/clinique-universitaire-de-psychologie/	\N	clinique-universitaire@psy.umontreal.ca	514-343-7725	Pavillon Marie-Victorin Local D-331 (3e étage) 1525, boul. Mont-Royal Ouest Outremont (Québec), H2V 2J7	2025-01-29 17:48:39.813+00	2025-01-05 18:32:55.229+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
122	peer-support-centre-psc	Peer Support Centre (PSC)	The Peer Support Centre (PSC) provides mental health services through their friendly and well-trained student peer supporters who can connect students to resources. The PSC is a welcoming space where students can share their experiences and feel truly listened to. Appointments can be dropped-in or can be scheduled. There is also online support provided by the PSC, in which students may make preferential appointments with a BIPOC, 2SLGBTQIA+, or woman supporter if desired. All services are confidential and non-judgemental.	https://psc.ssmu.ca	\N	mcgill.psc@gmail.com	514-398-3782	The University Centre, 3480 Rue McTavish, Room 411, Montreal, QC, H3A 0E7	2025-01-29 17:52:30.758+00	2025-01-05 18:32:53.553+00	t	t	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
117	centre-de-ressources-et-dinter	Centre de Ressources et d'intervention pour Hommes Abusés Sexuellement dans leur Enfance (CRIPHASE)	CRIPHASE is a non-profit organization that helps support men who experienced sexual assault. They offer services, including counseling, training, and support groups.	https://www.criphase.org/?fbclid=IwAR0rkiy13SLKnoZU8zTBlRkMHXh_fiEVwVFwYVm5OELVIx4lhex2EqFarXU	\N	info@criphase.org	\N	Exact location is confidential ( Montréal, QC H2J 1L7)	2025-01-29 18:04:05.918+00	2025-01-05 18:32:50.796+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
116	pride-therapy-network-of-montr	Pride Therapy Network of Montreal	The Pride Therapy Network of Montreal is a collective of independent mental health practitioners that provide affirmative services to members of sexually and gender-diverse communities. This collective aims to counter the discrimination of sexual and gender-diverse individuals who have been stigmatized and mistreated in mental health care systems. They offer financial accessibility services with their reduced fee option and other accessibility requests.	https://pridetherapynetworkmontreal.com	\N	info@montrealpridetherapynetwork.com	\N	Locations vary.	2025-01-29 18:10:04.068+00	2025-01-05 18:32:50.319+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
104	sexologists-student-wellness-h	Sexologists (Student Wellness Hub)	Sexologists are mental health professionals with a specialty in sexual health. Sexologists at the Student Wellness Hub offer information and sexual health support in a safe judgement-free space. Appointments can be made through contacting the Student Wellness Hub. 	https://www.mcgill.ca/wellness-hub/about-hub/clinicians/sexologists	\N	\N	(514) 398-6019	Student Wellness Hub	2025-02-07 15:11:56.282+00	2025-01-05 18:32:44.226+00	f	t	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
99	action-sant-transvesties-trans	Action Santé Transvesti(e)s & Transexuel(le)s du Quebéc (ASTT(e)Q)	ASTT(e)Q is a peer support program that promotes mental health and well-being of trans people by providing outreach, interventions, support and accompaniment. They offer different services to many segments of the Quebec trans community. ASTT(e)Q also provides a 24/7 listening line (1-855-909-9038 31). Their services are confidential, low cost or free.	https://cactusmontreal.org/en/trans-support/	\N	info@cactusmontreal.org	514 847-0067	1300 Sanguinet Street, Montréal, QC H2X 3E7	2025-02-07 15:19:21.268+00	2025-01-05 18:32:41.838+00	t	f	f	f	t	\N	\N	\N	\N	\N	\N	\N	\N
88	lannexe-agence-ometz	L'Annexe: Agence Ometz	L’Annexe: the Ometz Centre for Young Adults is a diverse, LGBTQ-affirming Jewish social service and community space open to everyone aged 16 to 35. Their services include counselling, workshops, employment supports, and support for newcomers, youth, and families. 	https://www.ometz.ca/lannexe/	Most activities are free, while others may have a cost. Refer to website for more information.	social@lannexe.ca	514-345-2656	5400 Westbury Ave, Montréal, Quebec\nH3Y 2W8	2025-02-07 15:40:26.747+00	2025-01-05 18:32:36.723+00	t	f	t	f	t	\N	\N	\N	\N	\N	\N	\N	\N
83	certified-listeners-society	Certified Listeners Society	The Certified Listeners Society is a crisis and Distress Call Centres directory. They help people who need emotional support before they are in either distress or crisis. They believe that by providing early-stage and real-time interventions to the masses, they can help individuals make better mental health lifestyle choices to live better, happier, healthier lives. 	https://certifiedlisteners.org/	\N	\N	\N	5500 North Service Rd Suite 300 Burlington ON Canada L7L 6W6	2025-02-14 11:40:40.808+00	2025-01-05 18:32:34.424+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
74	coute-entraide-french-service	Écoute Entraide (French service)	Écoute Entraide provides free, confidential, listening and support services available everywhere in Quebec. They offer listening services, self-help groups, and telephone pairing to receive calls on a continuous bases for support. Their helplines are open from 8 am to 10 pm 7 days a week.	https://www.ecoute-entraide.org	\N	\N	855-365-4463	Montreal 	2025-02-14 11:53:46.448+00	2025-01-05 18:32:29.674+00	t	f	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N
64	infosant-811	Info-Santé 811	Info-Santé 811 (option 1) is a free and confidential telephone consultation service. 811 is the only telephone number for this service. Dialling 811 (option 1) promptly puts you in contact with a nurse in case of a non-urgent health issue. However, in the event of a serious problem or emergency, it is important to dial 9-1-1 or go to the emergency room. This service 24/7 support 365 days a year. Anyone living in Québec can call Info-Santé 811 for themselves or a family member.	https://www.quebec.ca/en/health/finding-a-resource/info-sante-811	\N	\N	811	\N	2025-02-14 12:06:05.584+00	2025-01-05 18:32:25.043+00	t	f	f	t	f	\N	\N	\N	\N	\N	\N	\N	\N
60	jewish-general-hospital-infect	Jewish General Hospital - Infectious Diseases and STI Clinic	The Jewish General Hospita Division of Infectious Diseases specialize in clinical activities, teaching, research, and clinical lab-related activities in relation to infectious diseases and STIs. It is a drop-in clinic, however, a hospital card is required for an appointment and can be obtained in Pavilion E, Room 0014, near the Légaré Street entrance.	https://www.jgh.ca/care-services/infectious-diseases/	\N	\N	514-340-8230	3755 Côte-Sainte-Catherine Road, Pavilion E, Room E-0064	2025-02-14 12:12:30.423+00	2025-01-05 18:32:23.197+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
47	elna-medical-formerly-clinique	ELNA Medical (formerly Clinique A)	This is a transgender health clinic that provides hormone therapy, gender-affirming care, and follow-up with Dr. Landry (Private MD).	https://drgabriellelandry.com/en/hormone-therapy/	Pricing ranges from $100 - $325 depending on the service. Cancellation fee of $50 is applicable. Contact clinic for insurance coverage.	\N	514-787-0055	ELNA CLINIQUE A ESTHÉTIQUE407, McGill St, Office 900 Montreal (Quebec) H2Y 2G3	2025-02-14 12:28:23.756+00	2025-01-05 18:32:16.864+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
31	cramed	Créa-Med	Créa-Med is a private family medical clinic that provides general medicine services. Their clinic offers STI/STD testing, annual checkups, gynecology appointments, IUD insertion, and much more. Patients must contact their clinic to book an appointment.	https://crea-med.ca/en/?utm_source=G&utm_medium=lpm&utm_campaign=medicentres	Canadian resident membership fee: $99 Non-residents: $149          Varying fees depending on service, please refer to website.  Receipts given may be used to ask for reimbursement by insurance if applicable. Not covered by RAMQ or out-of-province healthcare.	info@crea-med.ca	514-613-3520	2055 rue Mansfield	2025-02-14 12:57:55.453+00	2025-01-05 18:32:09.483+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
27	centre-mdicale-dcelles	Centre Médicale Décelles	The Centre Médicale Décelles (Décelles Medical Center) offers services such as general medicine, endocrinology, and more. Fees apply for some services. Available in French and English.	https://sante.gouv.qc.ca/repertoire-ressources/ressource/?nofiche=51177	Contact clinic regarding pricing and insurance coverage.	\N	514 739-7771	6900, boulevard Décarie, suite M-150\nCôte-Saint-Luc (Québec)  H3X 2T8	2025-02-14 13:01:49.956+00	2025-01-05 18:32:07.665+00	t	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
15	montreal-abortion-appointment-	Montreal Abortion Appointment Center	Montreal’s Abortion Appointment Centre locates free abortion appointments for patients at clinics near them in less than two weeks.	https://santemontreal.qc.ca/en/public/support-and-services/abortion-montreal-appointment-centre/	To get free abortion services, you must have a valid health insurance card, an immigration certificate, or any other document giving you access to healthcare in Quebec.	\N	514-380-8299	\N	2025-02-14 13:13:38.842+00	2025-01-05 18:32:01.911+00	f	f	f	t	t	\N	\N	\N	\N	\N	\N	\N	\N
6	emotional-health-cognitive-beh	Emotional Health Cognitive Behavioral Therapy Clinic	Emotional Health Cognitive Behavioral Therapy Clinic offers treatment for the full spectrum of anxiety and mood disorders, as well as for low self-esteem, anger, relational difficulties, and sleep disorders. Services are offered in French and English.	https://cbtclinic.ca/	The clinic does not directly deal with client insurance companies, but receipts are provided for clients to submit to their insurance providers. Additionally, RAMQ is not accepted.	info@cbtclinic.ca	514-485-7772	Queen Elizabeth Health Complex, Suite 261 2100 Marlowe Ave.\nMontreal, Quebec H4A 3L5\n1250 Saint-Joseph East Boulevard \nMontreal, Quebec H2J 1L8\n911 Jean-Talon East Street, Suite 325\nMontreal, Quebec H2R 1V5	2025-02-14 13:20:00.299+00	2025-01-05 18:31:57.743+00	t	f	t	t	t	\N	\N	\N	\N	\N	\N	\N	\N
134	mcgill-university-sexual-ident	McGill University Sexual Identitiy Centre (MUSIC)	The McGill University Sexual Identity Centre (MUSIC) provides specialized mental health care to individuals, couples, and families with sexual orientation and gender identity issues. Their clientele includes people who are questioning their gender identity or sexual orientation or who feel unhappy about it, individuals and couples seeking to improve the quality of their interpersonal relationships, and couples and families who have concerns about a loved one’s gender identity or sexual orientation. MUSIC also works to enhance the health of the larger community through research, education, outreach, and advocacy around sexual orientation and gender issues, homophobia, and transphobia.	https://muhc.ca	\N	music@muhc.mcgill.ca	514-934-1934	Located at the Montreal General Hospital, 1650 Cedar Avenue Montreal, Quebec Canada H3G 1A4, Second Floor A2-160	2025-02-26 18:06:45.838+00	2025-01-05 18:42:29.449+00	t	f	f	f	t	\N	Centre d’identité sexuelle de l’Université McGill (MUSIC)	Le Centre d’identité sexuelle de l’Université McGill (MUSIC) prodigue des soins de santé mentale aux personnes, aux familles et aux couples qui sont aux prises avec des difficultés liées à l’orientation sexuelle et l’identité de genre. Notre clientèle se compose notamment de gens qui se questionnent sur leur identité de genre ou leur orientation sexuelle ou qui ne sont pas l’aise avec celles-ci. Le MUSIC s’adresse également aux personnes et aux couples qui souhaitent améliorer la qualité de leurs relations interpersonnelles, ainsi qu’à ceux qui s’inquiètent de l’orientation sexuelle ou l’identité de genre d’un de leurs proches. Les activités du MUSIC sont axées sur la recherche, l’éducation et la formation. Elles visent ainsi à promouvoir la santé au sein d’une collectivité plus vaste et à aborder les questions relatives à l’orientation sexuelle, l’identité de genre, l’homophobie et la transphobie.	\N	\N	\N	\N	\N
\.


--
-- Data for Name: resources_insurance_providers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resources_insurance_providers (_order, _parent_id, id) FROM stdin;
\.


--
-- Data for Name: resources_insurance_providers_insurance_provider; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resources_insurance_providers_insurance_provider (_order, _parent_id, id, name, description, name_fr, description_fr) FROM stdin;
\.


--
-- Data for Name: resources_rels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.resources_rels (id, "order", parent_id, path, resource_tags_id) FROM stdin;
775	1	136	tags	96
776	2	136	tags	97
780	1	134	tags	82
781	2	134	tags	94
5	1	2	tags	86
6	2	2	tags	87
7	3	2	tags	90
782	1	133	tags	88
783	2	133	tags	98
789	1	14	tags	93
790	2	14	tags	92
791	3	14	tags	96
792	4	14	tags	80
22	1	7	tags	79
23	2	7	tags	95
24	3	7	tags	91
25	4	7	tags	96
723	1	17	tags	83
724	2	17	tags	90
725	3	17	tags	87
726	4	17	tags	84
727	1	16	tags	83
728	2	16	tags	87
729	3	16	tags	84
733	1	15	tags	83
734	2	15	tags	79
735	3	15	tags	87
736	1	13	tags	93
737	2	13	tags	91
738	3	13	tags	96
739	4	13	tags	87
740	1	12	tags	94
741	2	12	tags	96
742	3	12	tags	91
743	1	11	tags	93
744	2	11	tags	96
745	3	11	tags	91
746	1	10	tags	93
747	2	10	tags	96
748	3	10	tags	92
749	1	9	tags	95
750	2	9	tags	91
751	3	9	tags	87
89	1	28	tags	87
90	2	28	tags	86
752	4	9	tags	94
753	1	8	tags	79
754	2	8	tags	95
755	3	8	tags	91
756	4	8	tags	94
757	1	6	tags	95
758	2	6	tags	91
759	3	6	tags	94
760	1	5	tags	95
761	2	5	tags	91
762	3	5	tags	87
763	4	5	tags	94
764	1	4	tags	95
765	2	4	tags	91
549	1	88	tags	96
550	2	88	tags	94
107	2	35	tags	80
766	3	4	tags	94
112	1	37	tags	78
113	2	37	tags	95
114	3	37	tags	96
130	1	42	tags	78
131	2	42	tags	92
132	3	42	tags	95
551	3	88	tags	82
560	1	86	tags	94
154	1	53	tags	87
155	2	53	tags	91
156	3	53	tags	99
157	4	53	tags	98
163	1	57	tags	90
164	2	57	tags	87
165	3	57	tags	86
166	4	57	tags	91
193	1	66	tags	92
194	2	66	tags	95
195	1	67	tags	92
196	2	67	tags	95
197	1	68	tags	94
198	2	68	tags	92
199	3	68	tags	97
212	1	73	tags	92
213	2	73	tags	91
214	3	73	tags	78
236	1	81	tags	87
237	2	81	tags	95
246	1	85	tags	94
247	2	85	tags	95
552	1	89	tags	94
553	2	89	tags	82
554	3	89	tags	96
555	1	87	tags	78
556	2	87	tags	91
557	3	87	tags	94
558	4	87	tags	79
268	1	93	tags	87
269	2	93	tags	90
270	3	93	tags	94
559	5	87	tags	95
561	2	86	tags	92
562	1	84	tags	94
563	2	84	tags	95
564	1	83	tags	79
565	2	83	tags	92
566	1	82	tags	79
567	2	82	tags	95
568	3	82	tags	94
569	4	82	tags	96
570	1	80	tags	91
571	1	79	tags	94
572	2	79	tags	87
573	3	79	tags	91
574	4	79	tags	84
575	1	78	tags	94
576	2	78	tags	91
577	1	77	tags	94
578	2	77	tags	95
579	3	77	tags	92
580	1	76	tags	102
581	2	76	tags	92
582	3	76	tags	90
583	4	76	tags	91
584	1	75	tags	92
585	2	75	tags	102
586	3	75	tags	90
587	1	74	tags	92
588	2	74	tags	95
589	3	74	tags	96
590	4	74	tags	94
591	1	72	tags	92
592	2	72	tags	101
593	1	71	tags	94
594	2	71	tags	92
595	3	71	tags	95
596	1	70	tags	92
597	2	70	tags	95
598	3	70	tags	96
599	1	69	tags	92
600	2	69	tags	95
601	3	69	tags	94
602	4	69	tags	101
603	1	65	tags	92
604	2	65	tags	95
605	3	65	tags	92
606	4	65	tags	79
609	1	64	tags	92
610	2	64	tags	79
637	1	54	tags	98
638	1	52	tags	97
639	2	52	tags	79
640	1	51	tags	97
641	2	51	tags	96
642	3	51	tags	91
643	1	50	tags	97
644	2	50	tags	92
645	1	49	tags	97
646	2	49	tags	92
647	1	48	tags	82
648	2	48	tags	90
649	1	47	tags	82
650	2	47	tags	87
651	1	46	tags	87
652	2	46	tags	90
653	3	46	tags	82
654	1	45	tags	82
655	2	45	tags	79
656	1	44	tags	78
657	2	44	tags	87
659	1	43	tags	96
660	2	43	tags	78
661	1	41	tags	78
662	2	41	tags	95
663	3	41	tags	92
664	1	40	tags	78
665	2	40	tags	95
666	3	40	tags	92
667	4	40	tags	97
668	5	40	tags	94
669	1	39	tags	78
670	2	39	tags	95
671	3	39	tags	92
672	4	39	tags	94
673	1	38	tags	78
674	2	38	tags	94
675	3	38	tags	96
676	1	36	tags	78
677	2	36	tags	88
678	3	36	tags	79
679	4	36	tags	96
680	1	33	tags	87
681	2	33	tags	89
682	1	32	tags	87
683	2	32	tags	95
684	3	32	tags	86
685	4	32	tags	94
686	1	31	tags	87
687	2	31	tags	90
688	3	31	tags	84
689	1	30	tags	87
690	2	30	tags	85
691	3	30	tags	89
692	1	29	tags	87
693	2	29	tags	89
694	1	27	tags	87
695	1	26	tags	87
696	2	26	tags	95
697	3	26	tags	91
698	4	26	tags	94
699	1	25	tags	87
700	2	25	tags	89
701	3	25	tags	84
702	1	24	tags	87
703	2	24	tags	84
704	3	24	tags	86
705	1	23	tags	87
706	2	23	tags	86
707	1	22	tags	87
708	2	22	tags	89
709	3	22	tags	86
710	4	22	tags	95
613	1	63	tags	90
614	2	63	tags	87
615	1	62	tags	90
616	2	62	tags	87
617	1	61	tags	90
618	2	61	tags	83
619	3	61	tags	84
620	4	61	tags	87
621	5	61	tags	95
622	1	60	tags	87
623	2	60	tags	90
624	3	60	tags	86
625	1	59	tags	90
626	2	59	tags	87
627	3	59	tags	82
628	4	59	tags	97
629	1	58	tags	90
630	2	58	tags	83
631	3	58	tags	84
632	4	58	tags	88
633	1	56	tags	94
634	2	56	tags	91
635	3	56	tags	93
636	1	55	tags	98
409	1	130	tags	95
410	2	130	tags	91
411	3	130	tags	94
412	1	129	tags	95
413	2	129	tags	91
414	3	129	tags	94
415	4	129	tags	93
416	1	128	tags	97
417	2	128	tags	79
418	3	128	tags	94
431	1	123	tags	94
432	2	123	tags	79
433	3	123	tags	86
434	4	123	tags	87
443	1	132	tags	86
449	1	127	tags	95
450	2	127	tags	91
451	3	127	tags	94
452	1	126	tags	95
453	2	126	tags	91
454	3	126	tags	94
455	1	125	tags	95
456	2	125	tags	91
457	3	125	tags	94
458	1	124	tags	94
459	2	124	tags	79
460	3	124	tags	98
461	1	122	tags	94
462	2	122	tags	78
463	3	122	tags	82
464	4	122	tags	92
465	5	122	tags	79
466	1	121	tags	91
467	2	121	tags	94
468	3	121	tags	95
469	4	121	tags	96
470	1	120	tags	78
471	2	120	tags	91
472	3	120	tags	94
473	1	119	tags	82
474	2	119	tags	94
475	1	118	tags	94
476	2	118	tags	91
477	3	118	tags	79
478	4	118	tags	78
479	5	118	tags	82
480	1	117	tags	102
481	2	117	tags	91
482	3	117	tags	96
483	1	116	tags	82
484	2	116	tags	91
485	3	116	tags	79
486	1	115	tags	101
487	2	115	tags	92
488	3	115	tags	99
489	1	114	tags	78
490	2	114	tags	82
491	3	114	tags	96
492	4	114	tags	94
493	1	113	tags	94
494	2	113	tags	96
495	3	113	tags	95
496	4	113	tags	98
497	1	112	tags	94
498	1	111	tags	100
499	2	111	tags	98
500	1	110	tags	100
501	2	110	tags	78
502	3	110	tags	98
503	1	108	tags	94
504	2	108	tags	96
505	1	109	tags	98
506	2	109	tags	95
507	3	109	tags	94
508	4	109	tags	79
509	1	107	tags	94
510	2	107	tags	96
511	3	107	tags	91
512	4	107	tags	79
513	1	106	tags	94
514	2	106	tags	96
515	1	105	tags	94
516	2	105	tags	96
517	1	104	tags	90
518	1	103	tags	95
519	2	103	tags	91
520	1	102	tags	87
521	1	101	tags	87
522	1	100	tags	93
523	2	100	tags	96
524	1	99	tags	82
525	2	99	tags	97
526	3	99	tags	90
527	1	98	tags	94
528	2	98	tags	96
529	1	97	tags	79
530	2	97	tags	82
531	3	97	tags	96
532	1	96	tags	79
533	2	96	tags	96
534	1	95	tags	79
535	1	94	tags	78
536	2	94	tags	79
537	3	94	tags	94
538	4	94	tags	96
542	1	92	tags	94
543	2	92	tags	91
544	3	92	tags	79
545	1	91	tags	94
546	1	90	tags	96
547	2	90	tags	94
548	3	90	tags	102
711	5	22	tags	90
712	1	21	tags	87
713	2	21	tags	95
714	1	20	tags	102
715	2	20	tags	87
716	1	19	tags	102
717	2	19	tags	92
718	3	19	tags	87
719	4	19	tags	90
720	5	19	tags	91
721	1	18	tags	83
722	2	18	tags	87
767	1	3	tags	95
768	2	3	tags	91
769	3	3	tags	96
770	4	3	tags	94
771	1	1	tags	87
772	2	1	tags	86
773	3	1	tags	90
774	4	1	tags	79
777	1	135	tags	82
778	2	135	tags	92
779	3	135	tags	80
784	1	131	tags	91
785	2	131	tags	95
786	3	131	tags	96
787	4	131	tags	93
788	5	131	tags	78
\.


--
-- Data for Name: sponsor; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sponsor (id, page_id, our_sponsors_section, our_sponsors_section_fr, callout, callout_fr, sponsor_us_section, sponsor_us_section_fr, updated_at, created_at, _status) FROM stdin;
1	12	We are incredibly grateful for the support and dedication of our sponsors. Your belief in our mission and your generous contributions are making a real difference in the mental wellness journey. Thanks to you, we are able to continue our work, reach more people, and create lasting positive change.	\N	Your partnership is invaluable, and we are proud to have you as part of the MindVista family.	\N	We'd love to partner with like-minded organizations and individuals to help spread mental wellness. If you're passionate about making a positive impact and would like to support MindVista, shoot us a message!	\N	2025-02-22 19:32:23.601+00	2025-02-22 17:53:17.579+00	published
\.


--
-- Data for Name: sponsor_sponsors; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sponsor_sponsors (_order, _parent_id, id, url, logo_id) FROM stdin;
1	1	67ba0e553edd3b18dd28ceb4	https://www.caffettiera.ca/	13
2	1	67ba0e643edd3b18dd28ceb6	https://www.ashtangamontreal.com/	14
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until, full_name, role) FROM stdin;
3	2025-02-09 04:39:37.983+00	2025-01-07 18:59:47.132+00	murad.novruzov1899@gmail.com	c8e8da983895c487eb0863387e8362f8207ef7c9	2025-01-09 21:18:50.963+00	0cd175420f6ee6cf8e1f3373d55e85170b87a9e55a79f82f07c48e41e9a79cf1	93f7b9af8d1f2e12c25e8ad76d997b5f3c7a28c40c72578a36e253723f1340edb6853c43fc6b0ca6c2a97677cbf6fd45a8b7515e132d2a6bb563b847a3bb452017b9e4fa8caa3e19e8fb1b034b0ea282d0ad1846cde5203f97b113f9e5f24d68ccbdae606b738578bcee9e83b52f6627d991d838cfb43445e4889907883dfcc2eefc7c2f22ea9e8dff252da73f96cb84aa0c0371917384798e28ad13c7cd950558665a4475a9c289991a5a25eb83160c9b495a358527f36c6b0dd215f933de0e08897221f86bf8cf110bb84ea12a448fad2bf168a77e9db6aca4a921a00ad02ac87d5c2b598763fde69c1ab445cd1272b46897ef5a47984964dc2ece41b7044a1815953a342969ac3c77a5a1de5f840a18cf683af49dbfbef8d2510fd837ac0529995168f45e6181eb3af605194857ff8b469f1ba9e04163d02feac709aae972fea00d436e40c3dceaa61ef1824844826627c0c24f54a42141c0b6bfa27412bed1df8279e989e9d7fdf5e556873d000d52be4e8af5f9854a5d644616e002edf3b41a2be4eb0855755c909781e47285febedea67842cf6fd9f3cba9543e092ea7ea6a1f707549a726f61e2554b84e752103270cf59c47a5885b693e241d0c7f5aae529b4fdc6bf2086b921c30f98e3df8d3e6cd0878cc7191ed5ce1163f63fd08329a9782cf1ec721ede1d99bc01b259c46f0fbcfde4efcbb8e359238a1823030	0	\N	Murad Novruzov	admin
4	2025-01-28 18:49:30.765+00	2025-01-10 00:08:42.458+00	charlyrotstein@gmail.com	\N	\N	21ca284936ad392f1c029e4fede66b0c2dd3a91934d2c92143914ff748bc81bd	d85d943743daa8d93108100b8fc5a2982f2b17e5c042cccdd21c226c55cbc85f21338ddcc8293d6f85510a838a66c68e3cc1fd885c5c69785f5fe2c28e6da5d97304d9b431dbe5869622533c0a8c7ce5a8167966e4b37294be51553515639b1148f06b7af3abd908c81dd67a55e3150a07573bf4121f541ed5a53b19f4b1c24ebab3b635d03b3fdd232da131f7f11accce677580ab2ffc31dabb6a68c30bf9d1113b09be42c03b4116dc42f629e37be6ab62afa1e33d4909e98921d2088a5c1fa9a133d463bcc2f76d9819e06b2b916c23da0280c014997dcffeb4c85c0a7f24ab461c6822237009b48fab41ff61b68b6f28420d16667989aad8816c5b50982377a1fd1f4d6017bc7392fcd356141e76db0426465d6887b1f5f49a5fb5c9c184d575b49c00eb474351910921b896f674e146615b9c60a99fa7395ba2b6e98ffe2dda76d5b6c5d9a778b5a3f29b9a9d4e96796adda97ac2d285faae9c9477a514b2fb3ed138485697c12abe284034b9e10f61d7cf6d2d604d0cea9777e04e3c57bfa45d94d098020040509711eefca0aa90cddb65f133a927542e1c2d2bfa632ddbf5d8dc511c28391c6e960637ac1e37092b66745e6cabc288b53f95629fc7d352a4d2b0d2487caeadd75d8054047ee3b9c2af0c0c904c586240f7818e31da8493c2a7cd618d8d1867757cf1b59c6dbad7e21efa41f5b4e6ecd431b4dac4d299	2	\N	Charlotte Rotstein	admin
5	2025-01-13 01:05:24.755+00	2025-01-10 02:58:28.252+00	jjulieburke@gmail.com	\N	\N	d54d24e0da10326a67b27108cbfd988ba770329d327d09b39fc2d68de5467939	83a748b4fbb9574f0096024723b01c709eb0deccd4ee2987e4ace4d193d1364f28c9af9512b2273e5f5917054fca1671bbf3949de64acd7c08b1dd47c24da990e0e7f974cb7afb4dd7d526a0a75f3ac9e69075dd7d35843876783144d571518a70ca1c9889eb1384f708d97f9676ed3595c28cf476db3ca4115eff4385211d2aaf0aaddf761fd37db242707acc5f34ccca8238abc54d2e98d5d18bcae69a7f950fb4e25a8d3295070623a3f491f2926ac9f7eed1988318f4ec173a7a35668566c8149e6c0602223ae93ec4a28f5a7b8bd5eebfa190d9b5d04958438a51bc833aeabbb543425f6e0de887d599181b63c304ff7a0231f954dc2611ec7e51a71c85df3b9c316a6961172e879e7996e45826235d348881a9a37ef8789c84b432bc7d1fd722e742c96ecf699970c2459fec8c9869518725ee9a9cc54d626d35af196dd1c603f675a78895927f19c5881a5639681f12e699a67e49ca4a52b03ba75e36d6ae3bfe825c42660af3b7eca8fa65361dfb209ab98538efe90c16ac13d5e07fc4a789ec8e65623fca2a9f9ff351fd8318e7d70a470fa178685090a88b4987f9e2790a70be3ca995cac16d22fc1035997200046f27c245541dabf7397807cb8fdebfdc8aa007d106074cd5474c2a82dc05f89d3fe4588126430a6484db34bc6e42746bc8f6217b24487a07fed60af0842da133c64c8c3d80ab83bc4b88def952	1	\N	Julie Burke	contentEditor
7	2025-01-24 15:19:47.255+00	2025-01-23 18:57:40.556+00	sjpierre28@gmail.com	396e57f7380db32a737708fabaf2d242a804fcda	2025-01-24 16:19:47.23+00	bd3fa290f41f81906e5950b2d019b436ba2553e21e423d534c777744e80eeb89	6f4bbcd6f37e294570c229020b0123705239ea315e9b45afe538d5b79343434c6059c12980c573746c2233d1299d4a722440a3c9d76da34f19dbc13e07d09bb3deaf56c98328015fbaeb716db01d80cdf8b60a0cf1b430fe299cbe8fc38e1d8dfeadd9f5fd97a22f099b1be9ce83d3c0916e6dd0d71b24c9604bf47de0cb8c92aabf7d548a2193b43ce25efe8e54583d211d1cdcd4afedaf4786bfc7d736ff85f47b1cedc4b4a8e2c7ec2091b39b30986636116e35c07f4d97c6483ed0b5ccadefc02fa4f9a80f2d2a45b8dc30ec7a930d29650ec8d2041408ac96a8f5e92409ba56e5ef0c2979368c8d184ca327a7edd017137d70025253f8810843b36d5968d93ee504ec2aba9aebd21faa598c809633ab36d9dd73ccc400606dda74b92efde8f2289308689a41467185e6f9adb18e72c606f1abd4d3dcdd18a2540633ddd388d0c9377f099c0c0f860754d49e593e8b13ad4f90cd7fa32b7e66be17b2b684b063bd0066bf3b7ea2ffd0cf6b31899cde57fa1e1a28295f50c936cba0aa9f97ef4c89bc3c55f64d2682ece42285f540302878177334aa565ca3e185e09e69ab960a217b735c43adc8f52c2249a07a12c7ac3ced2979358c926c17c4c73c7c880e99c7db462effef01e2626570b804e101c7ef98653f9c9820efe55ebfc0fbe5c8d43b0264f92d7241fb8ab107179e176f2129255e3b601bf9f7dbb4f594b7de	2	\N	Stephanie Jean Pierre	contentEditor
6	2025-01-16 15:02:55.08+00	2025-01-16 15:02:55.08+00	abbiecarnahan01@gmail.com	\N	\N	64507df3a63537320a4ce93a83f98cf240b00f464a77b4d9177e3e3a1f916041	72de38ebef9202cbb2002ae44b8bdae8d516e60e44bd286e7de6e86720e5d0c672ec4487a70faa4e0f03a27fc43f8b9e3a5a9c8f603905be311d65bcd102b8bc14d71395a94d602caca2e9e8ef5e384af1458ecb341e6477b43a58f84bc349ab78e16d129a64617226ffc0bc5814418b9462e4a3bd71f2c1e7b4415aa60dbe531cd746e2e26ff4cc9a13a395ea691bd8deadd93dbfd7eca278b82d4ade05b1442323a5712a41838a743e3a76b3362ed93fc5ad81de8376fdb0f40cd86f29ab9f4112dc2dde82022f49b04969fc1506b274f4d2980bca3e9ef52e5aef2d6538b499bf25eb567da4ecd0989b9369073b8b945d1d54c3b3c3107c637161e4332b1e448d6ad9d0e05bbfca151dd77dac98daa3d3c209c7598c67a8abd2269b39d921cdf13c3b9a1bcb02523ceaf2cfd08baaf00ea58f3f63fa5f4cc100d8f0cfcda5f20bec34af823b18eea5c7d5fea677c1b17c394db8031ef839733c0aaa7b7a67445e015ed129d7d5054f6d0afd6f58e0e5ffc3415b0088f2c868828da53416effc8afff8c4cef823388689c9a0d5ce3176fb2ed54d087a2fca4afa3bb79ec192dce8d67fd5972a1c923b1590fdb8aec081e61c8458f2861d516cc0efeca53bf47658f9595e70d75bc4ec2428ca6d711f078cedcf556c901049c2efcb666245c9512141e1172f0a765c7f289c9bc17c2b2aff176117d2f7a3a8c3f056bfe4419a	0	\N	Abbie Carnahan	contentEditor
1	2025-02-09 04:41:29.341+00	2025-01-01 21:58:29.798+00	mindvista@atlasgong.dev	2108d97f73618982e5f504b376f7ea16a65d7a26	2025-01-07 19:56:23.894+00	13f6fdf5168261482bc38ae6749b8cb032e8e2990c032169a1eb41d387c5afc7	9ff7727db2922edadb40607c7ff6a4a7d11eccf3206f38e7faf5f184c9edd4ddb0d2880527ea89536c3cf7a34f76f4af7083ed53c273be4597dad344e451b7a064a985d97690db08d50f5ffce6f6ea50d4316941a2b554d473fc8c2fc09e0749113a31704e48a5c3d912afa441377ea9074db7a10410fbf7b16c2a6283f10b2e85621eed9200450ef8851864d48e58fe1884dc7284554674c7161e9c3440b7029055d94eefc319a74275e9e05cbab4a9a2671fbd46eb206613381504707813e2e6bcb9dcdbede8880d94d5df478e0a11b7050ffdacda7d507beb9da5b1efefd574d4f5989ddc110095eff0fbc6370c9a7b762535ab58133891f3d2ecd71a90c93eb4c50f12dedf73fe04b479813a21df30e6e84954764a2f4d89ca136d8e0bda78f93a86c21834cb41108e9e336993a50313c4d5e22abf4e31cd5d653c6913fe28ccd4a2c44b46948b3c2ea0c6d20a9070847211a20fc9d5a4e1dd72ce43b1c5466ab02d9ccbb0dfa167b49fb9f2b2d2e2b08741b1d6849437211b27586a248c24a27651f210532621da40d471f658ffcbc242ebd918f232d73f72bcc735d3279e139cc2b45f7ac7c4377d8ee098b781b705338cfa0ac5aade14d9172c30f31bfda56d85beddb0623b4f8df765984d9454ebf381918ab35becf21d3eaaaa17dfc37419d883022ee08a02f56bddb2606d36f51f2dc082c8e66d293692a2058e75	2	\N	Atlas Gong	admin
8	2025-02-19 14:41:31.149+00	2025-02-16 15:39:55.566+00	cyrcomeault@gmail.com	\N	\N	200cfbddff32d439e23180dce81b61b977b8feb49dabf37e9d98b83165d0befa	9680f42edad20b619ea97cecfefd18b993ecf5213066aef01cae8dda51ee503f4ce600a4e66a39001d6d114ecefbd2c92bb445dde4f2f7ac272587a67633ae5802baedfa32fb16fe574a4a5784adb7653b9021b21bfa7cfa551b350ab339780f4d7ed9f25e5240c61651df9606b8cc0465cfa037309e7bb5bdea31b8577fe3b6f33bb3c85e18b8e789323b49fc533413aec26789d1bc5a7e70a56dd9b98bda0cc473390474ab16e48b60f6becf7a571c7881af31dafceef8bcd3bd17ff775d678cbf428fc8dbab45948f4229b969c52528f24bec4faee08e040b51aa38129b123d86e12ac8a9a3a731cfb32de7a9fd0121553a0eadd67a5e8148a0ee5bcab1b5222e1eb0d86b35db6db8a86faa6abda3633679fc1dd6a2a007acdcec61a64fc4cc1e38c40cb818dd7b68db719ef080b85d2e92e24cdb37dbe06dcb023058c58183396358e2de6d5ca5341cf4dbeddabb3b885cb989198ab9404e7ff19d3d34eaf71e317a59ee5aaac45579c0d1ea61627f9d2dd6e70e441cb56188ec7fc3019e4ef160239f01469c4c5d54856661015230d0c83b850f56dfa69a95ed33307e362432c9bb629a67e0a5d39ab76fc29a8e661d4f7dfeb78e7bd6db5ed6613ce395927453d3c1badc2e95317cc909ab333cafd2489601c03c6509df98857290e62a555c49b59f71a86b7c57f36b62a746fb55e6d348590906b5c5bdc374366c1acb	0	\N	Alizée Cyr-Comeault	contentEditorFr
\.


--
-- Name: _holistic_wellness_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._holistic_wellness_page_v_id_seq', 21, true);


--
-- Name: _holistic_wellness_page_v_version_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._holistic_wellness_page_v_version_sections_id_seq', 115, true);


--
-- Name: _holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._holistic_wellness_page_v_version_wellness_wheel_dimensi_id_seq', 338, true);


--
-- Name: _legal_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._legal_v_id_seq', 11, true);


--
-- Name: _sponsor_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._sponsor_v_id_seq', 15, true);


--
-- Name: _sponsor_v_version_sponsors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public._sponsor_v_version_sponsors_id_seq', 22, true);


--
-- Name: club_tag_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.club_tag_categories_id_seq', 19, true);


--
-- Name: club_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.club_tags_id_seq', 140, true);


--
-- Name: clubs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.clubs_id_seq', 377, true);


--
-- Name: clubs_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.clubs_rels_id_seq', 1922, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.events_id_seq', 17, true);


--
-- Name: holistic_wellness_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.holistic_wellness_page_id_seq', 1, true);


--
-- Name: legal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.legal_id_seq', 6, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.media_id_seq', 17, true);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.pages_id_seq', 13, true);


--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payload_locked_documents_id_seq', 803, true);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 1541, true);


--
-- Name: payload_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payload_migrations_id_seq', 4, true);


--
-- Name: payload_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payload_preferences_id_seq', 118, true);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 430, true);


--
-- Name: resource_tag_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.resource_tag_categories_id_seq', 41, true);


--
-- Name: resource_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.resource_tags_id_seq', 102, true);


--
-- Name: resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.resources_id_seq', 136, true);


--
-- Name: resources_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.resources_rels_id_seq', 792, true);


--
-- Name: sponsor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sponsor_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: _holistic_wellness_v _holistic_wellness_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v
    ADD CONSTRAINT _holistic_wellness_page_v_pkey PRIMARY KEY (id);


--
-- Name: _holistic_wellness_v_version_sections _holistic_wellness_page_v_version_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_sections
    ADD CONSTRAINT _holistic_wellness_page_v_version_sections_pkey PRIMARY KEY (id);


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions _holistic_wellness_page_v_version_wellness_wheel_dimension_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_wellness_wheel_dimensions
    ADD CONSTRAINT _holistic_wellness_page_v_version_wellness_wheel_dimension_pkey PRIMARY KEY (id);


--
-- Name: _legal_v _legal_v_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._legal_v
    ADD CONSTRAINT _legal_v_pkey PRIMARY KEY (id);


--
-- Name: _sponsor_v _sponsor_v_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v
    ADD CONSTRAINT _sponsor_v_pkey PRIMARY KEY (id);


--
-- Name: _sponsor_v_version_sponsors _sponsor_v_version_sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v_version_sponsors
    ADD CONSTRAINT _sponsor_v_version_sponsors_pkey PRIMARY KEY (id);


--
-- Name: club_tag_categories club_tag_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.club_tag_categories
    ADD CONSTRAINT club_tag_categories_pkey PRIMARY KEY (id);


--
-- Name: club_tags club_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.club_tags
    ADD CONSTRAINT club_tags_pkey PRIMARY KEY (id);


--
-- Name: clubs_other_socials clubs_other_socials_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_other_socials
    ADD CONSTRAINT clubs_other_socials_pkey PRIMARY KEY (id);


--
-- Name: clubs clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_pkey PRIMARY KEY (id);


--
-- Name: clubs_rels clubs_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_rels
    ADD CONSTRAINT clubs_rels_pkey PRIMARY KEY (id);


--
-- Name: events_date_ranges events_date_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events_date_ranges
    ADD CONSTRAINT events_date_ranges_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: holistic_wellness holistic_wellness_page_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness
    ADD CONSTRAINT holistic_wellness_page_pkey PRIMARY KEY (id);


--
-- Name: holistic_wellness_sections holistic_wellness_page_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness_sections
    ADD CONSTRAINT holistic_wellness_page_sections_pkey PRIMARY KEY (id);


--
-- Name: holistic_wellness_wellness_wheel_dimensions holistic_wellness_page_wellness_wheel_dimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness_wellness_wheel_dimensions
    ADD CONSTRAINT holistic_wellness_page_wellness_wheel_dimensions_pkey PRIMARY KEY (id);


--
-- Name: legal legal_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.legal
    ADD CONSTRAINT legal_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: resource_tag_categories resource_tag_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resource_tag_categories
    ADD CONSTRAINT resource_tag_categories_pkey PRIMARY KEY (id);


--
-- Name: resource_tags resource_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resource_tags
    ADD CONSTRAINT resource_tags_pkey PRIMARY KEY (id);


--
-- Name: resources_insurance_providers_insurance_provider resources_insurance_providers_insurance_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_insurance_providers_insurance_provider
    ADD CONSTRAINT resources_insurance_providers_insurance_provider_pkey PRIMARY KEY (id);


--
-- Name: resources_insurance_providers resources_insurance_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_insurance_providers
    ADD CONSTRAINT resources_insurance_providers_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: resources_rels resources_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_rels
    ADD CONSTRAINT resources_rels_pkey PRIMARY KEY (id);


--
-- Name: sponsor sponsor_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor
    ADD CONSTRAINT sponsor_pkey PRIMARY KEY (id);


--
-- Name: sponsor_sponsors sponsor_sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor_sponsors
    ADD CONSTRAINT sponsor_sponsors_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: _holistic_wellness_v_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_created_at_idx ON public._holistic_wellness_v USING btree (created_at);


--
-- Name: _holistic_wellness_v_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_updated_at_idx ON public._holistic_wellness_v USING btree (updated_at);


--
-- Name: _holistic_wellness_v_version_sections_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_version_sections_order_idx ON public._holistic_wellness_v_version_sections USING btree (_order);


--
-- Name: _holistic_wellness_v_version_sections_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_version_sections_parent_id_idx ON public._holistic_wellness_v_version_sections USING btree (_parent_id);


--
-- Name: _holistic_wellness_v_version_version_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_version_version_page_idx ON public._holistic_wellness_v USING btree (version_page_id);


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions_order_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_version_wellness_wheel_dimensions_order_id ON public._holistic_wellness_v_version_wellness_wheel_dimensions USING btree (_order);


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions_parent_i; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _holistic_wellness_v_version_wellness_wheel_dimensions_parent_i ON public._holistic_wellness_v_version_wellness_wheel_dimensions USING btree (_parent_id);


--
-- Name: _legal_v_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_created_at_idx ON public._legal_v USING btree (created_at);


--
-- Name: _legal_v_latest_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_latest_idx ON public._legal_v USING btree (latest);


--
-- Name: _legal_v_parent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_parent_idx ON public._legal_v USING btree (parent_id);


--
-- Name: _legal_v_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_updated_at_idx ON public._legal_v USING btree (updated_at);


--
-- Name: _legal_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_version_version__status_idx ON public._legal_v USING btree (version__status);


--
-- Name: _legal_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_version_version_created_at_idx ON public._legal_v USING btree (version_created_at);


--
-- Name: _legal_v_version_version_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_version_version_page_idx ON public._legal_v USING btree (version_page_id);


--
-- Name: _legal_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _legal_v_version_version_updated_at_idx ON public._legal_v USING btree (version_updated_at);


--
-- Name: _sponsor_v_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_created_at_idx ON public._sponsor_v USING btree (created_at);


--
-- Name: _sponsor_v_latest_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_latest_idx ON public._sponsor_v USING btree (latest);


--
-- Name: _sponsor_v_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_updated_at_idx ON public._sponsor_v USING btree (updated_at);


--
-- Name: _sponsor_v_version_sponsors_logo_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_version_sponsors_logo_idx ON public._sponsor_v_version_sponsors USING btree (logo_id);


--
-- Name: _sponsor_v_version_sponsors_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_version_sponsors_order_idx ON public._sponsor_v_version_sponsors USING btree (_order);


--
-- Name: _sponsor_v_version_sponsors_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_version_sponsors_parent_id_idx ON public._sponsor_v_version_sponsors USING btree (_parent_id);


--
-- Name: _sponsor_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_version_version__status_idx ON public._sponsor_v USING btree (version__status);


--
-- Name: _sponsor_v_version_version_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX _sponsor_v_version_version_page_idx ON public._sponsor_v USING btree (version_page_id);


--
-- Name: club_tag_categories_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX club_tag_categories_created_at_idx ON public.club_tag_categories USING btree (created_at);


--
-- Name: club_tag_categories_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX club_tag_categories_updated_at_idx ON public.club_tag_categories USING btree (updated_at);


--
-- Name: club_tags_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX club_tags_category_idx ON public.club_tags USING btree (category_id);


--
-- Name: club_tags_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX club_tags_created_at_idx ON public.club_tags USING btree (created_at);


--
-- Name: club_tags_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX club_tags_updated_at_idx ON public.club_tags USING btree (updated_at);


--
-- Name: clubs_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_created_at_idx ON public.clubs USING btree (created_at);


--
-- Name: clubs_graphic_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_graphic_idx ON public.clubs USING btree (graphic_id);


--
-- Name: clubs_other_socials_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_other_socials_order_idx ON public.clubs_other_socials USING btree (_order);


--
-- Name: clubs_other_socials_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_other_socials_parent_id_idx ON public.clubs_other_socials USING btree (_parent_id);


--
-- Name: clubs_rels_club_tags_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_rels_club_tags_id_idx ON public.clubs_rels USING btree (club_tags_id);


--
-- Name: clubs_rels_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_rels_order_idx ON public.clubs_rels USING btree ("order");


--
-- Name: clubs_rels_parent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_rels_parent_idx ON public.clubs_rels USING btree (parent_id);


--
-- Name: clubs_rels_path_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_rels_path_idx ON public.clubs_rels USING btree (path);


--
-- Name: clubs_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX clubs_slug_idx ON public.clubs USING btree (slug);


--
-- Name: clubs_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX clubs_updated_at_idx ON public.clubs USING btree (updated_at);


--
-- Name: events_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_created_at_idx ON public.events USING btree (created_at);


--
-- Name: events_date_ranges_end_date_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_date_ranges_end_date_idx ON public.events_date_ranges USING btree (end_date);


--
-- Name: events_date_ranges_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_date_ranges_order_idx ON public.events_date_ranges USING btree (_order);


--
-- Name: events_date_ranges_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_date_ranges_parent_id_idx ON public.events_date_ranges USING btree (_parent_id);


--
-- Name: events_date_ranges_start_date_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_date_ranges_start_date_idx ON public.events_date_ranges USING btree (start_date);


--
-- Name: events_graphic_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_graphic_idx ON public.events USING btree (graphic_id);


--
-- Name: events_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX events_slug_idx ON public.events USING btree (slug);


--
-- Name: events_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX events_updated_at_idx ON public.events USING btree (updated_at);


--
-- Name: holistic_wellness_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX holistic_wellness_page_idx ON public.holistic_wellness USING btree (page_id);


--
-- Name: holistic_wellness_sections_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX holistic_wellness_sections_order_idx ON public.holistic_wellness_sections USING btree (_order);


--
-- Name: holistic_wellness_sections_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX holistic_wellness_sections_parent_id_idx ON public.holistic_wellness_sections USING btree (_parent_id);


--
-- Name: holistic_wellness_wellness_wheel_dimensions_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX holistic_wellness_wellness_wheel_dimensions_order_idx ON public.holistic_wellness_wellness_wheel_dimensions USING btree (_order);


--
-- Name: holistic_wellness_wellness_wheel_dimensions_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX holistic_wellness_wellness_wheel_dimensions_parent_id_idx ON public.holistic_wellness_wellness_wheel_dimensions USING btree (_parent_id);


--
-- Name: legal__status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX legal__status_idx ON public.legal USING btree (_status);


--
-- Name: legal_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX legal_created_at_idx ON public.legal USING btree (created_at);


--
-- Name: legal_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX legal_page_idx ON public.legal USING btree (page_id);


--
-- Name: legal_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX legal_updated_at_idx ON public.legal USING btree (updated_at);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: pages_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX pages_created_at_idx ON public.pages USING btree (created_at);


--
-- Name: pages_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX pages_slug_idx ON public.pages USING btree (slug);


--
-- Name: pages_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX pages_updated_at_idx ON public.pages USING btree (updated_at);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_club_tag_categories_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_club_tag_categories_id_idx ON public.payload_locked_documents_rels USING btree (club_tag_categories_id);


--
-- Name: payload_locked_documents_rels_club_tags_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_club_tags_id_idx ON public.payload_locked_documents_rels USING btree (club_tags_id);


--
-- Name: payload_locked_documents_rels_clubs_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_clubs_id_idx ON public.payload_locked_documents_rels USING btree (clubs_id);


--
-- Name: payload_locked_documents_rels_events_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_events_id_idx ON public.payload_locked_documents_rels USING btree (events_id);


--
-- Name: payload_locked_documents_rels_legal_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_legal_id_idx ON public.payload_locked_documents_rels USING btree (legal_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_pages_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_pages_id_idx ON public.payload_locked_documents_rels USING btree (pages_id);


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_resource_tag_categories_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_resource_tag_categories_id_idx ON public.payload_locked_documents_rels USING btree (resource_tag_categories_id);


--
-- Name: payload_locked_documents_rels_resource_tags_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_resource_tags_id_idx ON public.payload_locked_documents_rels USING btree (resource_tags_id);


--
-- Name: payload_locked_documents_rels_resources_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_resources_id_idx ON public.payload_locked_documents_rels USING btree (resources_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: resource_tag_categories_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resource_tag_categories_created_at_idx ON public.resource_tag_categories USING btree (created_at);


--
-- Name: resource_tag_categories_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resource_tag_categories_updated_at_idx ON public.resource_tag_categories USING btree (updated_at);


--
-- Name: resource_tags_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resource_tags_category_idx ON public.resource_tags USING btree (category_id);


--
-- Name: resource_tags_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resource_tags_created_at_idx ON public.resource_tags USING btree (created_at);


--
-- Name: resource_tags_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resource_tags_updated_at_idx ON public.resource_tags USING btree (updated_at);


--
-- Name: resources_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_created_at_idx ON public.resources USING btree (created_at);


--
-- Name: resources_graphic_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_graphic_idx ON public.resources USING btree (graphic_id);


--
-- Name: resources_insurance_providers_insurance_provider_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_insurance_providers_insurance_provider_order_idx ON public.resources_insurance_providers_insurance_provider USING btree (_order);


--
-- Name: resources_insurance_providers_insurance_provider_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_insurance_providers_insurance_provider_parent_id_idx ON public.resources_insurance_providers_insurance_provider USING btree (_parent_id);


--
-- Name: resources_insurance_providers_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_insurance_providers_order_idx ON public.resources_insurance_providers USING btree (_order);


--
-- Name: resources_insurance_providers_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_insurance_providers_parent_id_idx ON public.resources_insurance_providers USING btree (_parent_id);


--
-- Name: resources_rels_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_rels_order_idx ON public.resources_rels USING btree ("order");


--
-- Name: resources_rels_parent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_rels_parent_idx ON public.resources_rels USING btree (parent_id);


--
-- Name: resources_rels_path_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_rels_path_idx ON public.resources_rels USING btree (path);


--
-- Name: resources_rels_resource_tags_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_rels_resource_tags_id_idx ON public.resources_rels USING btree (resource_tags_id);


--
-- Name: resources_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX resources_slug_idx ON public.resources USING btree (slug);


--
-- Name: resources_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX resources_updated_at_idx ON public.resources USING btree (updated_at);


--
-- Name: sponsor__status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sponsor__status_idx ON public.sponsor USING btree (_status);


--
-- Name: sponsor_page_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sponsor_page_idx ON public.sponsor USING btree (page_id);


--
-- Name: sponsor_sponsors_logo_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sponsor_sponsors_logo_idx ON public.sponsor_sponsors USING btree (logo_id);


--
-- Name: sponsor_sponsors_order_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sponsor_sponsors_order_idx ON public.sponsor_sponsors USING btree (_order);


--
-- Name: sponsor_sponsors_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sponsor_sponsors_parent_id_idx ON public.sponsor_sponsors USING btree (_parent_id);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: _holistic_wellness_v _holistic_wellness_v_version_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v
    ADD CONSTRAINT _holistic_wellness_v_version_page_id_pages_id_fk FOREIGN KEY (version_page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _holistic_wellness_v_version_sections _holistic_wellness_v_version_sections_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_sections
    ADD CONSTRAINT _holistic_wellness_v_version_sections_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._holistic_wellness_v(id) ON DELETE CASCADE;


--
-- Name: _holistic_wellness_v_version_wellness_wheel_dimensions _holistic_wellness_v_version_wellness_wheel_dimensions_parent_i; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._holistic_wellness_v_version_wellness_wheel_dimensions
    ADD CONSTRAINT _holistic_wellness_v_version_wellness_wheel_dimensions_parent_i FOREIGN KEY (_parent_id) REFERENCES public._holistic_wellness_v(id) ON DELETE CASCADE;


--
-- Name: _legal_v _legal_v_parent_id_legal_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._legal_v
    ADD CONSTRAINT _legal_v_parent_id_legal_id_fk FOREIGN KEY (parent_id) REFERENCES public.legal(id) ON DELETE SET NULL;


--
-- Name: _legal_v _legal_v_version_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._legal_v
    ADD CONSTRAINT _legal_v_version_page_id_pages_id_fk FOREIGN KEY (version_page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _sponsor_v _sponsor_v_version_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v
    ADD CONSTRAINT _sponsor_v_version_page_id_pages_id_fk FOREIGN KEY (version_page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: _sponsor_v_version_sponsors _sponsor_v_version_sponsors_logo_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v_version_sponsors
    ADD CONSTRAINT _sponsor_v_version_sponsors_logo_id_media_id_fk FOREIGN KEY (logo_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _sponsor_v_version_sponsors _sponsor_v_version_sponsors_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._sponsor_v_version_sponsors
    ADD CONSTRAINT _sponsor_v_version_sponsors_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._sponsor_v(id) ON DELETE CASCADE;


--
-- Name: club_tags club_tags_category_id_club_tag_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.club_tags
    ADD CONSTRAINT club_tags_category_id_club_tag_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.club_tag_categories(id) ON DELETE SET NULL;


--
-- Name: clubs clubs_graphic_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_graphic_id_media_id_fk FOREIGN KEY (graphic_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: clubs_other_socials clubs_other_socials_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_other_socials
    ADD CONSTRAINT clubs_other_socials_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: clubs_rels clubs_rels_club_tags_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_rels
    ADD CONSTRAINT clubs_rels_club_tags_fk FOREIGN KEY (club_tags_id) REFERENCES public.club_tags(id) ON DELETE CASCADE;


--
-- Name: clubs_rels clubs_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clubs_rels
    ADD CONSTRAINT clubs_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: events_date_ranges events_date_ranges_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events_date_ranges
    ADD CONSTRAINT events_date_ranges_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: events events_graphic_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_graphic_id_media_id_fk FOREIGN KEY (graphic_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: holistic_wellness holistic_wellness_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness
    ADD CONSTRAINT holistic_wellness_page_id_pages_id_fk FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: holistic_wellness_sections holistic_wellness_sections_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness_sections
    ADD CONSTRAINT holistic_wellness_sections_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.holistic_wellness(id) ON DELETE CASCADE;


--
-- Name: holistic_wellness_wellness_wheel_dimensions holistic_wellness_wellness_wheel_dimensions_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.holistic_wellness_wellness_wheel_dimensions
    ADD CONSTRAINT holistic_wellness_wellness_wheel_dimensions_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.holistic_wellness(id) ON DELETE CASCADE;


--
-- Name: legal legal_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.legal
    ADD CONSTRAINT legal_page_id_pages_id_fk FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_club_tag_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_club_tag_categories_fk FOREIGN KEY (club_tag_categories_id) REFERENCES public.club_tag_categories(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_club_tags_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_club_tags_fk FOREIGN KEY (club_tags_id) REFERENCES public.club_tags(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_clubs_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_clubs_fk FOREIGN KEY (clubs_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_events_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_events_fk FOREIGN KEY (events_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_legal_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_legal_fk FOREIGN KEY (legal_id) REFERENCES public.legal(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pages_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pages_fk FOREIGN KEY (pages_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_resource_tag_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_resource_tag_categories_fk FOREIGN KEY (resource_tag_categories_id) REFERENCES public.resource_tag_categories(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_resource_tags_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_resource_tags_fk FOREIGN KEY (resource_tags_id) REFERENCES public.resource_tags(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_resources_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_resources_fk FOREIGN KEY (resources_id) REFERENCES public.resources(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: resource_tags resource_tags_category_id_resource_tag_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resource_tags
    ADD CONSTRAINT resource_tags_category_id_resource_tag_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.resource_tag_categories(id) ON DELETE SET NULL;


--
-- Name: resources resources_graphic_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_graphic_id_media_id_fk FOREIGN KEY (graphic_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: resources_insurance_providers_insurance_provider resources_insurance_providers_insurance_provider_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_insurance_providers_insurance_provider
    ADD CONSTRAINT resources_insurance_providers_insurance_provider_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.resources_insurance_providers(id) ON DELETE CASCADE;


--
-- Name: resources_insurance_providers resources_insurance_providers_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_insurance_providers
    ADD CONSTRAINT resources_insurance_providers_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.resources(id) ON DELETE CASCADE;


--
-- Name: resources_rels resources_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_rels
    ADD CONSTRAINT resources_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.resources(id) ON DELETE CASCADE;


--
-- Name: resources_rels resources_rels_resource_tags_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.resources_rels
    ADD CONSTRAINT resources_rels_resource_tags_fk FOREIGN KEY (resource_tags_id) REFERENCES public.resource_tags(id) ON DELETE CASCADE;


--
-- Name: sponsor sponsor_page_id_pages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor
    ADD CONSTRAINT sponsor_page_id_pages_id_fk FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: sponsor_sponsors sponsor_sponsors_logo_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor_sponsors
    ADD CONSTRAINT sponsor_sponsors_logo_id_media_id_fk FOREIGN KEY (logo_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: sponsor_sponsors sponsor_sponsors_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sponsor_sponsors
    ADD CONSTRAINT sponsor_sponsors_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.sponsor(id) ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

